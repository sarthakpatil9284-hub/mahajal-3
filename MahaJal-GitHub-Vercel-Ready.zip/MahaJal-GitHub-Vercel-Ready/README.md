# MahaJal – Maharashtra Drought & Agriculture Intelligence Platform

A full-stack decision-support web platform to monitor drought, rainfall, water availability and farmer/crop conditions across Maharashtra.

> **All data is synthetic DEMO data.** It is not official government data. The score is labelled **"MahaJal Analytical Drought Risk Score – Demo/Decision Support"** and is **not** an official drought declaration.

## Features
- Public site: Home, About, Drought Map (Leaflet + OpenStreetMap), Rainfall, Water Resources, Crop Advisory, Login, Register, Forgot/Reset Password
- Village dashboard with a "Why is this village at risk?" breakdown, charts, water sources, needs and support gap
- Farmer portal: dashboard, profile, crops, crop details + advisory, damage reports, tanker requests, SOS, notifications
- Rule-based crop advisory with "Why this advisory?"
- Government portal: dashboard, map, districts, villages, farmers, damage / SOS / tanker status workflow, analytics (with observation entry and risk recalculation), CSV reports
- NGO and CSR portals: village needs, support offers / commitments
- Support gap: `Total Need − Government − NGO − CSR = Remaining Gap`
- JWT + BCrypt, role-based access, CORS, validation, consistent API responses

## Technology stack
React 18 (JavaScript, Vite), React Router, Axios, Leaflet, Recharts, CSS · Java 21, Spring Boot 3.3, Spring Security, JWT (jjwt), JPA/Hibernate, Bean Validation, Maven · MySQL 8

## Architecture
See `docs/ARCHITECTURE.md`. Layers: controller → service → repository → entity, with DTOs, `security` and `config` packages. Frontend: components, pages, layouts, services, context, routes, hooks, utils, styles.

## Requirements
JDK 21, Maven 3.9+, Node 18+, MySQL 8 (or Docker).

## Database setup
Tables are created automatically by Hibernate (`ddl-auto=update`) and demo data is seeded on first start when `SEED_DEMO=true` and the database is empty. The database is created automatically (`createDatabaseIfNotExist=true`); `database/init.sql` is also provided.

## Backend setup
```bash
cd backend
# defaults: MySQL at localhost:3306, user root / password root
export DB_PASSWORD=your_mysql_password
mvn spring-boot:run          # http://localhost:8080
```

## Frontend setup
```bash
cd frontend
npm install
npm run dev                  # http://localhost:5173 (proxies /api to localhost:8080)
```

## Run with Docker
```bash
docker compose up --build    # frontend http://localhost:3000, API http://localhost:8080
```

## Environment variables
See `.env.example`: `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `DDL_AUTO`, `JWT_SECRET`, `JWT_EXPIRATION_MS`, `CORS_ORIGINS`, `SEED_DEMO`, `DEMO_RESET_TOKEN`, `SERVER_PORT`, and frontend `VITE_API_URL` (default `/api`). Change `JWT_SECRET` outside demos.

## Demo accounts (password for all: `Demo@12345`)
| Role | Email |
|---|---|
| Government | gov@mahajal.demo |
| Farmer (Ramesh Patil, Vairag, Solapur) | farmer@mahajal.demo |
| NGO | ngo@mahajal.demo (also ngo2@mahajal.demo) |
| CSR | csr@mahajal.demo (also csr2@mahajal.demo) |
| Citizen | citizen@mahajal.demo |

Government accounts cannot be self-registered; an existing government user creates them from the Government Dashboard (`POST /api/gov/users`).

## API overview
See `docs/API.md`. Groups: `/api/auth`, public (`/locations`, `/map`, `/villages`, `/rainfall`, `/water`, `/advisory`), `/api/farmer`, `/api/notifications`, `/api/gov`, `/api/partner`, `/api/ngo`, `/api/csr`.

## Notes and limitations
- Forgot password has no email service: in demo mode (`DEMO_RESET_TOKEN=true`) the reset link is shown on screen.
- Advisory rules are illustrative, not agronomic recommendations.
- Reports export CSV; PDF/Excel is planned.

## Future enhancements
Python FastAPI ML service (drought, crop-loss and water-demand prediction), AI assistant, satellite/NDVI data, advanced GIS, GPS tanker tracking, Marathi language, PDF/Excel reports, government API integrations.
