import { Link } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import { farmerApi } from '../../services/services';
import Async from '../../components/Async';
import StatCard from '../../components/StatCard';
import RiskBadge from '../../components/RiskBadge';
import FactorList from '../../components/FactorList';
import ScoreNote from '../../components/ScoreNote';
import { num } from '../../utils/format';

export default function FarmerDashboard() {
  const state = useFetch(() => farmerApi.dashboard(), []);
  return (
    <Async state={state} isEmpty={(d) => !d}>
      {(d) => (
        <div>
          <h1>Welcome, {d.profile.fullName}</h1>
          <p className="muted">{d.profile.village}, {d.profile.taluka}, {d.profile.district}</p>
          <section className="grid-4">
            <StatCard label="My crops" value={d.cropCount} hint={`${num(d.totalAcres)} acres`} />
            <StatCard label="Damage reports" value={d.damageReports} />
            <StatCard label="Tanker requests" value={d.tankerRequests} />
            <StatCard label="Unread notifications" value={d.unreadNotifications} />
          </section>
          {d.villageRisk && (
            <div className="card">
              <h3>Your village risk <RiskBadge level={d.villageRisk.riskLevel} /> <small>({num(d.villageRisk.riskScore, 0)}/100)</small></h3>
              <ScoreNote />
              <h4>Why is my village at risk?</h4>
              <FactorList factors={d.whyAtRisk} />
              <Link to={`/village/${d.villageRisk.id}`}>Open village dashboard →</Link>
            </div>
          )}
          <div className="quick-links">
            <Link className="btn" to="/farmer/crops">My crops</Link><Link className="btn" to="/farmer/advisory">Crop advisory</Link>
            <Link className="btn btn-outline" to="/farmer/tanker">Request tanker</Link><Link className="btn btn-danger" to="/farmer/sos">Send SOS</Link>
          </div>
        </div>
      )}
    </Async>
  );
}
