import { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { farmerApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import DataTable from '../../components/DataTable';
import { errorMessage, dt, pretty } from '../../utils/format';

export default function TankerRequest() {
  const list = useFetch(() => farmerApi.tankers(), []);
  const [f, setF] = useState({ peopleCount: 5, livestockCount: 2, litersRequired: 5000, urgency: 'MEDIUM', remarks: '' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      await farmerApi.requestTanker({ ...f, peopleCount: Number(f.peopleCount), livestockCount: Number(f.livestockCount), litersRequired: Number(f.litersRequired) });
      setMsg({ t: 'success', m: 'Tanker request submitted.' }); list.reload();
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };

  return (
    <div>
      <h1>Water / Tanker Request</h1>
      <form className="card form" onSubmit={submit}>
        <div className="grid-3">
          <label>People<input type="number" min="1" required value={f.peopleCount} onChange={set('peopleCount')} /></label>
          <label>Livestock<input type="number" min="0" required value={f.livestockCount} onChange={set('livestockCount')} /></label>
          <label>Litres required (min 500)<input type="number" min="500" step="500" required value={f.litersRequired} onChange={set('litersRequired')} /></label>
          <label>Urgency<select value={f.urgency} onChange={set('urgency')}><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>CRITICAL</option></select></label>
        </div>
        <label>Remarks<textarea maxLength={500} rows={2} value={f.remarks} onChange={set('remarks')} /></label>
        {msg && <Alert type={msg.t}>{msg.m}</Alert>}
        <button className="btn" disabled={busy}>{busy ? 'Submitting...' : 'Request tanker'}</button>
      </form>
      <h3 className="section-title">My requests</h3>
      <Async state={list} emptyTitle="No tanker requests yet">
        {(rows) => <DataTable columns={[
          { header: 'Date', render: (r) => dt(r.createdAt) }, { header: 'Litres', key: 'litersRequired' }, { header: 'People', key: 'peopleCount' },
          { header: 'Urgency', key: 'urgency' }, { header: 'Status', render: (r) => pretty(r.status) },
        ]} rows={rows} />}
      </Async>
    </div>
  );
}
