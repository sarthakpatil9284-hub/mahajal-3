import { useState } from 'react';
import { farmerApi, publicApi } from '../../services/services';
import useFetch from '../../hooks/useFetch';
import Alert from '../../components/Alert';
import AdvisoryView from '../../components/AdvisoryView';
import { errorMessage, pretty } from '../../utils/format';

/** Fetches a crop advisory for a saved crop; inputs from village data + chosen weather. */
export default function FarmerAdvisoryPanel({ cropId }) {
  const opts = useFetch(() => publicApi.advisoryOptions(), []);
  const [weather, setWeather] = useState('CLEAR');
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const run = async () => {
    setBusy(true); setErr('');
    try { setData(await farmerApi.cropAdvisory(cropId, weather)); } catch (x) { setErr(errorMessage(x)); } finally { setBusy(false); }
  };

  return (
    <div>
      <h3 className="section-title">Crop advisory</h3>
      <div className="toolbar">
        <label>Current weather
          <select value={weather} onChange={(e) => setWeather(e.target.value)}>
            {(opts.data?.weather || ['CLEAR', 'CLOUDY', 'RAIN_FORECAST', 'HEATWAVE']).map((w) => <option key={w} value={w}>{pretty(w)}</option>)}
          </select>
        </label>
        <button className="btn" onClick={run} disabled={busy}>{busy ? 'Generating...' : 'Get advisory'}</button>
      </div>
      <Alert type="error">{err}</Alert>
      {data && (
        <>
          <p className="muted">Inputs used (from your village's latest data): rainfall {data.inputs.rainfallMm} mm, soil moisture {data.inputs.soilMoisturePct}%, water availability {data.inputs.waterAvailabilityPct}%, soil {pretty(data.inputs.soilType)}, stage {pretty(data.inputs.stage)}, weather {pretty(data.inputs.weather)}.</p>
          <AdvisoryView result={data.result} />
        </>
      )}
    </div>
  );
}
