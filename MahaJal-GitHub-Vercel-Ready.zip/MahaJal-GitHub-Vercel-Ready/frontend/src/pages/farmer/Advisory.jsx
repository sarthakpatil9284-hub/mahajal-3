import { Link } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import { farmerApi } from '../../services/services';
import Async from '../../components/Async';
import FarmerAdvisoryPanel from './FarmerAdvisoryPanel';
import { useState } from 'react';
import { pretty } from '../../utils/format';

export default function FarmerAdvisory() {
  const crops = useFetch(() => farmerApi.crops(), []);
  const [cropId, setCropId] = useState('');
  return (
    <div>
      <h1>Crop Advisory</h1>
      <Async state={crops} emptyTitle="No crops yet" emptyText="Add a crop first to get a personalised advisory.">
        {(list) => (
          <>
            <label className="inline">Select crop
              <select value={cropId} onChange={(e) => setCropId(e.target.value)}>
                <option value="">Choose…</option>
                {list.map((c) => <option key={c.id} value={c.id}>{c.cropName} ({pretty(c.stage)})</option>)}
              </select>
            </label>
            {cropId ? <FarmerAdvisoryPanel key={cropId} cropId={cropId} /> : <p className="muted">Or try the <Link to="/advisory">manual advisory tool</Link>.</p>}
          </>
        )}
      </Async>
    </div>
  );
}
