import { useParams, Link } from 'react-router-dom';
import FarmerAdvisoryPanel from './FarmerAdvisoryPanel';
import useFetch from '../../hooks/useFetch';
import { farmerApi } from '../../services/services';
import Async from '../../components/Async';
import { pretty } from '../../utils/format';

export default function CropDetails() {
  const { id } = useParams();
  const state = useFetch(() => farmerApi.crop(id), [id]);
  return (
    <div>
      <Link to="/farmer/crops">← My crops</Link>
      <Async state={state} isEmpty={(d) => !d}>
        {(c) => (
          <>
            <h1>{c.cropName}</h1>
            <div className="card"><ul className="kv">
              <li><span>Season</span><b>{c.season}</b></li><li><span>Stage</span><b>{pretty(c.stage)}</b></li>
              <li><span>Area</span><b>{c.areaAcres} acres</b></li><li><span>Sowing date</span><b>{c.sowingDate || '–'}</b></li>
              <li><span>Soil</span><b>{pretty(c.soilType)}</b></li><li><span>Irrigation</span><b>{c.irrigationType}</b></li>
            </ul></div>
            <FarmerAdvisoryPanel cropId={c.id} />
          </>
        )}
      </Async>
    </div>
  );
}
