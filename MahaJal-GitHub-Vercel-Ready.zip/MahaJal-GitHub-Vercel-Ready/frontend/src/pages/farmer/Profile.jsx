import { useEffect, useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { farmerApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import LocationSelect from '../../components/LocationSelect';
import { errorMessage } from '../../utils/format';

function ProfileForm({ p }) {
  const [f, setF] = useState({ fullName: p.fullName, phone: p.phone || '', landAcres: p.landAcres });
  const [loc, setLoc] = useState({ districtId: String(p.districtId), talukaId: String(p.talukaId), villageId: String(p.villageId) });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      await farmerApi.updateProfile({ ...f, landAcres: Number(f.landAcres), villageId: Number(loc.villageId) });
      setMsg({ t: 'success', m: 'Profile updated.' });
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };
  return (
    <form className="card form" onSubmit={submit}>
      <div className="grid-2">
        <label>Full name<input required value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} /></label>
        <label>Email<input disabled value={p.email} /></label>
        <label>Phone<input pattern="[0-9]{10}" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></label>
        <label>Land (acres)<input type="number" min="0" step="0.1" required value={f.landAcres} onChange={(e) => setF({ ...f, landAcres: e.target.value })} /></label>
      </div>
      <LocationSelect value={loc} onChange={setLoc} villageRequired />
      {msg && <Alert type={msg.t}>{msg.m}</Alert>}
      <button className="btn" disabled={busy || !loc.villageId}>{busy ? 'Saving...' : 'Save profile'}</button>
    </form>
  );
}

export default function Profile() {
  const state = useFetch(() => farmerApi.profile(), []);
  return <div><h1>My Profile</h1><Async state={state} isEmpty={(d) => !d}>{(p) => <ProfileForm p={p} />}</Async></div>;
}
