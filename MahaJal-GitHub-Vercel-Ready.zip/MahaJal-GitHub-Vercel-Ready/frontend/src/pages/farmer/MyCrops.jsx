import { useState } from 'react';
import { Link } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import { farmerApi, publicApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import DataTable from '../../components/DataTable';
import { errorMessage, pretty } from '../../utils/format';

const SEASONS = ['KHARIF', 'RABI', 'SUMMER', 'PERENNIAL'];
const IRRIGATION = ['RAINFED', 'DRIP', 'SPRINKLER', 'FLOOD', 'WELL', 'CANAL'];

export default function MyCrops() {
  const crops = useFetch(() => farmerApi.crops(), []);
  const opts = useFetch(() => publicApi.advisoryOptions(), []);
  const [f, setF] = useState({ cropName: '', season: 'KHARIF', stage: 'SOWING', areaAcres: 1, sowingDate: '', soilType: 'BLACK', irrigationType: 'RAINFED' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const o = opts.data;

  const add = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      await farmerApi.addCrop({ ...f, areaAcres: Number(f.areaAcres), sowingDate: f.sowingDate || null });
      setMsg({ t: 'success', m: 'Crop added.' }); crops.reload();
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };
  const remove = async (id) => {
    if (!window.confirm('Delete this crop?')) return;
    try { await farmerApi.deleteCrop(id); setMsg({ t: 'success', m: 'Crop deleted.' }); crops.reload(); } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); }
  };

  return (
    <div>
      <h1>My Crops</h1>
      {msg && <Alert type={msg.t} onClose={() => setMsg(null)}>{msg.m}</Alert>}
      <Async state={crops} emptyTitle="No crops yet" emptyText="Add your first crop using the form below.">
        {(rows) => <DataTable columns={[
          { header: 'Crop', render: (r) => <Link to={`/farmer/crops/${r.id}`}>{r.cropName}</Link> }, { header: 'Season', key: 'season' },
          { header: 'Stage', render: (r) => pretty(r.stage) }, { header: 'Acres', key: 'areaAcres' }, { header: 'Irrigation', key: 'irrigationType' },
          { header: '', render: (r) => <button className="btn btn-sm btn-danger" onClick={() => remove(r.id)}>Delete</button> },
        ]} rows={rows} />}
      </Async>
      <h3 className="section-title">Add crop</h3>
      <form className="card form" onSubmit={add}>
        <div className="grid-3">
          <label>Crop<select required value={f.cropName} onChange={set('cropName')}><option value="">Select</option>{(o?.crops || []).map((c) => <option key={c}>{c}</option>)}</select></label>
          <label>Season<select value={f.season} onChange={set('season')}>{SEASONS.map((s) => <option key={s}>{s}</option>)}</select></label>
          <label>Stage<select value={f.stage} onChange={set('stage')}>{(o?.stages || []).map((s) => <option key={s} value={s}>{pretty(s)}</option>)}</select></label>
          <label>Area (acres)<input type="number" min="0.1" step="0.1" required value={f.areaAcres} onChange={set('areaAcres')} /></label>
          <label>Sowing date<input type="date" value={f.sowingDate} onChange={set('sowingDate')} /></label>
          <label>Soil type<select value={f.soilType} onChange={set('soilType')}>{(o?.soilTypes || []).map((s) => <option key={s} value={s}>{pretty(s)}</option>)}</select></label>
          <label>Irrigation<select value={f.irrigationType} onChange={set('irrigationType')}>{IRRIGATION.map((s) => <option key={s}>{s}</option>)}</select></label>
        </div>
        <button className="btn" disabled={busy || !o}>{busy ? 'Adding...' : 'Add crop'}</button>
      </form>
    </div>
  );
}
