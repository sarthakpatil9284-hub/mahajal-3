import { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { farmerApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import DataTable from '../../components/DataTable';
import { errorMessage, dt, pretty } from '../../utils/format';

const CAUSES = ['DROUGHT', 'FLOOD', 'HAILSTORM', 'PEST', 'DISEASE', 'HEATWAVE', 'OTHER'];

export default function ReportDamage() {
  const reports = useFetch(() => farmerApi.damage(), []);
  const crops = useFetch(() => farmerApi.crops(), []);
  const [f, setF] = useState({ cropId: '', cause: 'DROUGHT', damagePercent: 30, areaAffectedAcres: 1, description: '' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      await farmerApi.reportDamage({ ...f, cropId: f.cropId ? Number(f.cropId) : null, damagePercent: Number(f.damagePercent), areaAffectedAcres: Number(f.areaAffectedAcres) });
      setMsg({ t: 'success', m: 'Damage report submitted. The government team has been notified.' }); setF({ ...f, description: '' }); reports.reload();
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };

  return (
    <div>
      <h1>Report Crop Damage</h1>
      <form className="card form" onSubmit={submit}>
        <div className="grid-3">
          <label>Crop<select value={f.cropId} onChange={set('cropId')}><option value="">Not specified</option>{(crops.data || []).map((c) => <option key={c.id} value={c.id}>{c.cropName}</option>)}</select></label>
          <label>Cause<select value={f.cause} onChange={set('cause')}>{CAUSES.map((c) => <option key={c}>{c}</option>)}</select></label>
          <label>Damage (%)<input type="number" min="1" max="100" required value={f.damagePercent} onChange={set('damagePercent')} /></label>
          <label>Area affected (acres)<input type="number" min="0.1" step="0.1" required value={f.areaAffectedAcres} onChange={set('areaAffectedAcres')} /></label>
        </div>
        <label>Description<textarea maxLength={1000} rows={3} value={f.description} onChange={set('description')} /></label>
        {msg && <Alert type={msg.t}>{msg.m}</Alert>}
        <button className="btn" disabled={busy}>{busy ? 'Submitting...' : 'Submit report'}</button>
      </form>
      <h3 className="section-title">My reports</h3>
      <Async state={reports} emptyTitle="No damage reports yet">
        {(rows) => <DataTable columns={[
          { header: 'Date', render: (r) => dt(r.createdAt) }, { header: 'Crop', key: 'crop' }, { header: 'Cause', key: 'cause' },
          { header: 'Damage %', key: 'damagePercent' }, { header: 'Status', render: (r) => pretty(r.status) }, { header: 'Remarks', key: 'remarks' },
        ]} rows={rows} />}
      </Async>
    </div>
  );
}
