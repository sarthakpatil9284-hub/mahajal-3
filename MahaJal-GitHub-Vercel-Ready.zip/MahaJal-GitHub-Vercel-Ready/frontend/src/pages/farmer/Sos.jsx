import { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { farmerApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import DataTable from '../../components/DataTable';
import { errorMessage, dt, pretty } from '../../utils/format';

const CATS = ['DRINKING_WATER', 'FODDER', 'MEDICAL', 'CROP_LOSS', 'LIVESTOCK', 'OTHER'];

export default function Sos() {
  const list = useFetch(() => farmerApi.sos(), []);
  const [f, setF] = useState({ category: 'DRINKING_WATER', message: '' });
  const [coords, setCoords] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const locate = () => {
    if (!navigator.geolocation) return setMsg({ t: 'error', m: 'Geolocation is not supported by this browser.' });
    navigator.geolocation.getCurrentPosition(
      (p) => setCoords({ latitude: p.coords.latitude, longitude: p.coords.longitude }),
      () => setMsg({ t: 'error', m: 'Could not read your location. You can still send the SOS.' }),
    );
  };
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      await farmerApi.sendSos({ ...f, ...(coords || {}) });
      setMsg({ t: 'success', m: 'SOS sent to the government team.' }); setF({ ...f, message: '' }); list.reload();
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };

  return (
    <div>
      <h1>SOS</h1>
      <p className="muted">For urgent help only. In a real emergency also call 112.</p>
      <form className="card form" onSubmit={submit}>
        <label>Category<select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{CATS.map((c) => <option key={c} value={c}>{pretty(c)}</option>)}</select></label>
        <label>Message<textarea required maxLength={1000} rows={3} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></label>
        <div><button type="button" className="btn btn-outline" onClick={locate}>📍 Attach my location</button> {coords && <small>Attached ({coords.latitude.toFixed(3)}, {coords.longitude.toFixed(3)})</small>}</div>
        {msg && <Alert type={msg.t}>{msg.m}</Alert>}
        <button className="btn btn-danger" disabled={busy}>{busy ? 'Sending...' : 'Send SOS'}</button>
      </form>
      <h3 className="section-title">My SOS reports</h3>
      <Async state={list} emptyTitle="No SOS reports">
        {(rows) => <DataTable columns={[{ header: 'Date', render: (r) => dt(r.createdAt) }, { header: 'Category', render: (r) => pretty(r.category) }, { header: 'Message', key: 'message' }, { header: 'Status', render: (r) => pretty(r.status) }]} rows={rows} />}
      </Async>
    </div>
  );
}
