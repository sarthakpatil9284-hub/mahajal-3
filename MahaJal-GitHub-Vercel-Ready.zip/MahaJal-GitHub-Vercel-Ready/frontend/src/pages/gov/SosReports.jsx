import CaseList from '../../components/CaseList';
import { govApi } from '../../services/services';
import { dt, pretty } from '../../utils/format';

export default function SosReports() {
  return (
    <div><h1>SOS Reports</h1>
      <CaseList fetcher={govApi.sos} updater={govApi.updateSos} statuses={['OPEN', 'ACKNOWLEDGED', 'RESOLVED']} emptyTitle="No SOS reports"
        columns={[{ header: 'Date', render: (r) => dt(r.createdAt) }, { header: 'Farmer', key: 'farmer' }, { header: 'Phone', key: 'phone' }, { header: 'Village', key: 'village' },
          { header: 'Category', render: (r) => pretty(r.category) }, { header: 'Message', key: 'message' }]} />
    </div>
  );
}
