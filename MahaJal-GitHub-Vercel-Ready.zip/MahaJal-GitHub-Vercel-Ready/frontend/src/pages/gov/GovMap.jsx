import DroughtMap from '../public/DroughtMap';
export default function GovMap() { return <DroughtMap embedded />; }
