import CaseList from '../../components/CaseList';
import { govApi } from '../../services/services';
import { dt } from '../../utils/format';

export default function Tankers() {
  return (
    <div><h1>Tanker Requests</h1>
      <CaseList fetcher={govApi.tankers} updater={govApi.updateTanker} statuses={['REQUESTED', 'APPROVED', 'DISPATCHED', 'DELIVERED', 'REJECTED']} emptyTitle="No tanker requests"
        columns={[{ header: 'Date', render: (r) => dt(r.createdAt) }, { header: 'Farmer', key: 'farmer' }, { header: 'Village', key: 'village' }, { header: 'District', key: 'district' },
          { header: 'Litres', key: 'litersRequired' }, { header: 'People', key: 'peopleCount' }, { header: 'Urgency', key: 'urgency' }]} />
    </div>
  );
}
