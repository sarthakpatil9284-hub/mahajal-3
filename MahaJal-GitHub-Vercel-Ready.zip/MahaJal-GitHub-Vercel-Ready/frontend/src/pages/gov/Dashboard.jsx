import { useState } from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import useFetch from '../../hooks/useFetch';
import { govApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import StatCard from '../../components/StatCard';
import DataTable from '../../components/DataTable';
import RiskBadge from '../../components/RiskBadge';
import ScoreNote from '../../components/ScoreNote';
import { RISK_COLORS, errorMessage, num } from '../../utils/format';

function CreateGovUser() {
  const [f, setF] = useState({ fullName: '', email: '', password: '', phone: '' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try { await govApi.createUser(f); setMsg({ t: 'success', m: `Government account created for ${f.email}.` }); setF({ fullName: '', email: '', password: '', phone: '' }); }
    catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };
  return (
    <details className="card">
      <summary><strong>Create another government account</strong></summary>
      <form className="form" onSubmit={submit}>
        <div className="grid-2">
          <label>Full name<input required value={f.fullName} onChange={set('fullName')} /></label>
          <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
          <label>Password (min 8)<input type="password" minLength={8} required value={f.password} onChange={set('password')} /></label>
          <label>Phone<input pattern="[0-9]{10}" value={f.phone} onChange={set('phone')} /></label>
        </div>
        {msg && <Alert type={msg.t}>{msg.m}</Alert>}
        <button className="btn" disabled={busy}>{busy ? 'Creating...' : 'Create account'}</button>
      </form>
    </details>
  );
}

export default function GovDashboard() {
  const state = useFetch(() => govApi.dashboard(), []);
  return (
    <div>
      <h1>Government Dashboard</h1>
      <ScoreNote />
      <Async state={state} isEmpty={(d) => !d}>
        {(d) => (
          <>
            <section className="grid-3">
              <StatCard label="Total districts" value={d.totalDistricts} />
              <StatCard label="Villages assessed" value={d.villagesAssessed} />
              <StatCard label="Critical villages" value={d.criticalVillages} tone="critical" />
              <StatCard label="Affected farmers" value={d.affectedFarmers.toLocaleString('en-IN')} hint="In High/Critical villages" tone="high" />
              <StatCard label="SOS requests" value={d.sosRequests} hint="Open" />
              <StatCard label="Tanker requests" value={d.tankerRequests} hint="Pending" />
            </section>
            <div className="grid-2">
              <div className="card"><h3>Risk distribution</h3>
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart><Pie data={d.riskDistribution} dataKey="value" nameKey="name" outerRadius={90} label>{d.riskDistribution.map((r) => <Cell key={r.name} fill={RISK_COLORS[r.name]} />)}</Pie><Tooltip /><Legend /></PieChart>
                </ResponsiveContainer></div>
              <div className="card"><h3>Highest-risk villages</h3>
                <DataTable columns={[{ header: 'Village', key: 'name' }, { header: 'District', key: 'district' }, { header: 'Score', render: (r) => num(r.riskScore, 0) }, { header: 'Level', render: (r) => <RiskBadge level={r.riskLevel} /> }]} rows={d.topVillages} />
              </div>
            </div>
            <CreateGovUser />
          </>
        )}
      </Async>
    </div>
  );
}
