import { useState } from 'react';
import { govApi } from '../../services/services';
import Alert from '../../components/Alert';
import { downloadCsv, errorMessage } from '../../utils/format';

const REPORTS = [
  { key: 'villages', title: 'Village risk & support gap', fetch: govApi.villages, file: 'mahajal_villages_demo.csv' },
  { key: 'districts', title: 'District risk summary', fetch: govApi.districts, file: 'mahajal_districts_demo.csv' },
  { key: 'farmers', title: 'Farmers', fetch: govApi.farmers, file: 'mahajal_farmers_demo.csv' },
  { key: 'damage', title: 'Crop damage reports', fetch: govApi.damage, file: 'mahajal_damage_demo.csv' },
  { key: 'sos', title: 'SOS reports', fetch: govApi.sos, file: 'mahajal_sos_demo.csv' },
  { key: 'tankers', title: 'Tanker requests', fetch: govApi.tankers, file: 'mahajal_tankers_demo.csv' },
];

export default function Reports() {
  const [busy, setBusy] = useState(null);
  const [msg, setMsg] = useState(null);
  const run = async (r) => {
    setBusy(r.key); setMsg(null);
    try {
      const rows = await r.fetch();
      if (!rows.length) return setMsg({ t: 'error', m: 'No data available for this report.' });
      downloadCsv(r.file, rows); setMsg({ t: 'success', m: `${r.file} downloaded (${rows.length} rows).` });
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(null); }
  };
  return (
    <div>
      <h1>Reports</h1>
      <p className="muted">Export current data as CSV. Contents are synthetic demo data. PDF/Excel export is planned.</p>
      {msg && <Alert type={msg.t} onClose={() => setMsg(null)}>{msg.m}</Alert>}
      <div className="grid-3">
        {REPORTS.map((r) => (
          <div className="card" key={r.key}><h4>{r.title}</h4><button className="btn" disabled={busy === r.key} onClick={() => run(r)}>{busy === r.key ? 'Preparing...' : 'Download CSV'}</button></div>
        ))}
      </div>
    </div>
  );
}
