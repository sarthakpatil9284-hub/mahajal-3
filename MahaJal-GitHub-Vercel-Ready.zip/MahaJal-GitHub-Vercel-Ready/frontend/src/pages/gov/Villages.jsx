import { useState } from 'react';
import { Link } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import { govApi, locationApi } from '../../services/services';
import Async from '../../components/Async';
import DataTable from '../../components/DataTable';
import RiskBadge from '../../components/RiskBadge';
import { num, inr } from '../../utils/format';

export default function Villages() {
  const [districtId, setDistrictId] = useState('');
  const districts = useFetch(() => locationApi.districts(), []);
  const state = useFetch(() => govApi.villages(districtId), [districtId]);
  return (
    <div><h1>Villages</h1>
      <label className="inline">District
        <select value={districtId} onChange={(e) => setDistrictId(e.target.value)}><option value="">All</option>{(districts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
      </label>
      <Async state={state} emptyTitle="No villages">
        {(rows) => <DataTable columns={[
          { header: 'Village', render: (r) => <Link to={`/village/${r.id}`}>{r.name}</Link> }, { header: 'Taluka', key: 'taluka' }, { header: 'District', key: 'district' },
          { header: 'Pop.', key: 'population' }, { header: 'Farmers', key: 'farmers' }, { header: 'Deficit %', render: (r) => num(r.rainfallDeficitPct) },
          { header: 'GW (m)', render: (r) => num(r.groundwaterDepthM) }, { header: 'Score', render: (r) => num(r.riskScore, 0) }, { header: 'Risk', render: (r) => <RiskBadge level={r.riskLevel} /> },
          { header: 'Need', render: (r) => inr(r.totalNeed) }, { header: 'Remaining gap', render: (r) => inr(r.remainingGap) },
        ]} rows={rows} />}
      </Async>
    </div>
  );
}
