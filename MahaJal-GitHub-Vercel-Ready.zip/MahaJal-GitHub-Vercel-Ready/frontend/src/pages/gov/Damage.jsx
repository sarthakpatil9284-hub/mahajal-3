import CaseList from '../../components/CaseList';
import { govApi } from '../../services/services';
import { dt } from '../../utils/format';

export default function Damage() {
  return (
    <div><h1>Crop Damage Reports</h1>
      <CaseList fetcher={govApi.damage} updater={govApi.updateDamage} statuses={['SUBMITTED', 'UNDER_REVIEW', 'VERIFIED', 'RESOLVED', 'REJECTED']} emptyTitle="No damage reports"
        columns={[{ header: 'Date', render: (r) => dt(r.createdAt) }, { header: 'Farmer', key: 'farmer' }, { header: 'Village', key: 'village' }, { header: 'District', key: 'district' },
          { header: 'Crop', key: 'crop' }, { header: 'Cause', key: 'cause' }, { header: 'Damage %', key: 'damagePercent' }]} />
    </div>
  );
}
