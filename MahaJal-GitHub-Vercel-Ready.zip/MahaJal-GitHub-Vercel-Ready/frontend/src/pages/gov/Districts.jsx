import useFetch from '../../hooks/useFetch';
import { govApi } from '../../services/services';
import Async from '../../components/Async';
import DataTable from '../../components/DataTable';
import RiskBadge from '../../components/RiskBadge';
import { num } from '../../utils/format';

export default function Districts() {
  const state = useFetch(() => govApi.districts(), []);
  return (
    <div><h1>Districts</h1>
      <Async state={state} emptyTitle="No districts">
        {(rows) => <DataTable columns={[{ header: 'District', key: 'name' }, { header: 'Villages assessed', key: 'villages' }, { header: 'Critical villages', key: 'criticalVillages' },
          { header: 'Avg score', render: (r) => (r.avgRiskScore == null ? '–' : num(r.avgRiskScore, 0)) }, { header: 'Level', render: (r) => <RiskBadge level={r.riskLevel} /> }]} rows={rows} />}
      </Async>
    </div>
  );
}
