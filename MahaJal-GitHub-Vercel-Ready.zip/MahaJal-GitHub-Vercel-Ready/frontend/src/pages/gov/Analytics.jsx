import { useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ScatterChart, Scatter, ZAxis } from 'recharts';
import useFetch from '../../hooks/useFetch';
import { govApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import LocationSelect from '../../components/LocationSelect';
import ScoreNote from '../../components/ScoreNote';
import { errorMessage } from '../../utils/format';

function ObservationForm({ onSaved }) {
  const [loc, setLoc] = useState({});
  const [f, setF] = useState({ month: new Date().toISOString().slice(0, 7) + '-01', actualMm: '', normalMm: '', groundwaterDepthM: '' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const num = (v) => (v === '' ? null : Number(v));

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      await govApi.addObservation({ villageId: Number(loc.villageId), month: f.month, actualMm: num(f.actualMm), normalMm: num(f.normalMm), groundwaterDepthM: num(f.groundwaterDepthM) });
      setMsg({ t: 'success', m: 'Observation saved and the village risk was recalculated.' }); onSaved();
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };
  return (
    <form className="card form" onSubmit={submit}>
      <h3>Record a monthly observation</h3>
      <LocationSelect value={loc} onChange={setLoc} villageRequired />
      <div className="grid-4">
        <label>Month (1st)<input type="date" required value={f.month} onChange={set('month')} /></label>
        <label>Actual rainfall (mm)<input type="number" min="0" step="0.1" value={f.actualMm} onChange={set('actualMm')} /></label>
        <label>Normal rainfall (mm)<input type="number" min="0" step="0.1" value={f.normalMm} onChange={set('normalMm')} /></label>
        <label>Groundwater depth (m)<input type="number" min="0" step="0.1" value={f.groundwaterDepthM} onChange={set('groundwaterDepthM')} /></label>
      </div>
      {msg && <Alert type={msg.t}>{msg.m}</Alert>}
      <button className="btn" disabled={busy || !loc.villageId}>{busy ? 'Saving...' : 'Save observation'}</button>
    </form>
  );
}

export default function Analytics() {
  const state = useFetch(() => govApi.analytics(), []);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const recalc = async () => {
    setBusy(true); setMsg(null);
    try { const r = await govApi.recalculate(); setMsg({ t: 'success', m: r.message || 'Risk scores recalculated.' }); state.reload(); }
    catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };
  const bar = (title, data, color) => (
    <div className="card"><h3>{title}</h3>
      <ResponsiveContainer width="100%" height={240}><BarChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="value" fill={color} /></BarChart></ResponsiveContainer></div>
  );
  return (
    <div>
      <div className="row-between"><h1>Drought Analytics</h1><button className="btn" onClick={recalc} disabled={busy}>{busy ? 'Recalculating...' : 'Recalculate all risk scores'}</button></div>
      <ScoreNote />
      {msg && <Alert type={msg.t} onClose={() => setMsg(null)}>{msg.m}</Alert>}
      <Async state={state} isEmpty={(d) => !d}>
        {(d) => (
          <>
            <div className="card"><h3>Average risk score by district</h3>
              <ResponsiveContainer width="100%" height={320}><BarChart data={d.districtRisk}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" interval={0} angle={-35} textAnchor="end" height={80} /><YAxis domain={[0, 100]} /><Tooltip /><Bar dataKey="avgRiskScore" name="Avg score" fill="#c62828" /></BarChart></ResponsiveContainer></div>
            <div className="card"><h3>Rainfall deficit vs groundwater depth (each dot = village)</h3>
              <ResponsiveContainer width="100%" height={300}><ScatterChart><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" dataKey="deficitPct" name="Deficit %" /><YAxis type="number" dataKey="groundwaterDepthM" name="GW depth (m)" /><ZAxis dataKey="riskScore" range={[40, 160]} /><Tooltip cursor={{ strokeDasharray: '3 3' }} /><Scatter data={d.scatter} fill="#1565c0" /></ScatterChart></ResponsiveContainer></div>
            <div className="grid-3">
              {bar('Damage reports by status', d.damageByStatus, '#ef6c00')}
              {bar('SOS by category', d.sosByCategory, '#c62828')}
              {bar('Tankers by status', d.tankerByStatus, '#00838f')}
            </div>
          </>
        )}
      </Async>
      <ObservationForm onSaved={state.reload} />
    </div>
  );
}
