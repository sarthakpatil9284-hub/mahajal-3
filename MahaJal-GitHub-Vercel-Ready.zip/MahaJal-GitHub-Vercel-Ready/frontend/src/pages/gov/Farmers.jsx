import useFetch from '../../hooks/useFetch';
import { govApi } from '../../services/services';
import Async from '../../components/Async';
import DataTable from '../../components/DataTable';

export default function Farmers() {
  const state = useFetch(() => govApi.farmers(), []);
  return (
    <div><h1>Farmers</h1>
      <Async state={state} emptyTitle="No farmers registered">
        {(rows) => <DataTable columns={[{ header: 'Name', key: 'fullName' }, { header: 'Phone', key: 'phone' }, { header: 'Land (acres)', key: 'landAcres' },
          { header: 'Village', key: 'village' }, { header: 'Taluka', key: 'taluka' }, { header: 'District', key: 'district' }, { header: 'Crops', key: 'crops' }]} rows={rows} />}
      </Async>
    </div>
  );
}
