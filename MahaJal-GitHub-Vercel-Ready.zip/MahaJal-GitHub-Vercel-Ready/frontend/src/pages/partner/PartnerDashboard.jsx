import { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { partnerApi, locationApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import DataTable from '../../components/DataTable';
import RiskBadge from '../../components/RiskBadge';
import StatCard from '../../components/StatCard';
import { errorMessage, inr, num, pretty, dt } from '../../utils/format';

/** Shared dashboard for NGO (type="NGO") and CSR (type="CSR"). */
export default function PartnerDashboard({ type }) {
  const isNgo = type === 'NGO';
  const [districtId, setDistrictId] = useState('');
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({ needId: '', supportType: '', amountInr: 50000, description: '' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const districts = useFetch(() => locationApi.districts(), []);
  const villages = useFetch(() => partnerApi.villages(districtId), [districtId]);
  const needs = useFetch(() => (selected ? partnerApi.needs(selected.id) : Promise.resolve([])), [selected?.id]);
  const mine = useFetch(() => (isNgo ? partnerApi.ngoList() : partnerApi.csrList()), []);

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      const body = { villageId: selected.id, needId: form.needId ? Number(form.needId) : null, supportType: form.supportType, amountInr: Number(form.amountInr), description: form.description };
      await (isNgo ? partnerApi.ngoOffer(body) : partnerApi.csrCommit(body));
      setMsg({ t: 'success', m: isNgo ? 'Support offer recorded.' : 'CSR commitment recorded.' });
      mine.reload(); villages.reload();
      setForm({ ...form, description: '' });
    } catch (x) { setMsg({ t: 'error', m: errorMessage(x) }); } finally { setBusy(false); }
  };

  return (
    <div>
      <h1>{isNgo ? 'NGO' : 'CSR'}: Village Needs &amp; {isNgo ? 'Support Offers' : 'Commitments'}</h1>
      <p className="muted">Remaining gap = Total need − Government − NGO − CSR support (demo figures).</p>
      <label className="inline">District
        <select value={districtId} onChange={(e) => { setDistrictId(e.target.value); setSelected(null); }}>
          <option value="">All</option>{(districts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </label>
      <Async state={villages} emptyTitle="No villages">
        {(rows) => (
          <DataTable onRowClick={setSelected} columns={[
            { header: 'Village', key: 'name' }, { header: 'District', key: 'district' }, { header: 'Risk', render: (r) => <RiskBadge level={r.riskLevel} /> },
            { header: 'Total need', render: (r) => inr(r.totalNeed) }, { header: 'Govt', render: (r) => inr(r.governmentSupport) }, { header: 'NGO', render: (r) => inr(r.ngoSupport) },
            { header: 'CSR', render: (r) => inr(r.csrSupport) }, { header: 'Remaining gap', render: (r) => <b>{inr(r.remainingGap)}</b> },
          ]} rows={rows} />
        )}
      </Async>
      <p className="muted">Click a village row to view needs and {isNgo ? 'offer support' : 'record a commitment'}.</p>
      {selected && (
        <div className="card">
          <h3>{selected.name}, {selected.district} <span className="tag-demo">DEMO</span></h3>
          <section className="grid-4">
            <StatCard label="Total need" value={inr(selected.totalNeed)} /><StatCard label="Government" value={inr(selected.governmentSupport)} />
            <StatCard label="NGO" value={inr(selected.ngoSupport)} /><StatCard label="CSR" value={inr(selected.csrSupport)} />
          </section>
          <Async state={needs} emptyTitle="No needs recorded for this village">
            {(rows) => <DataTable columns={[{ header: 'Need', render: (r) => pretty(r.needType) }, { header: 'Description', key: 'description' }, { header: 'Est. cost', render: (r) => inr(r.estimatedCostInr) }, { header: 'Priority', key: 'priority' }]} rows={rows} />}
          </Async>
          <form className="form" onSubmit={submit}>
            <h4>{isNgo ? 'Offer support' : 'Record CSR commitment'}</h4>
            <div className="grid-3">
              <label>Related need<select value={form.needId} onChange={(e) => setForm({ ...form, needId: e.target.value })}><option value="">General</option>{(needs.data || []).map((n) => <option key={n.id} value={n.id}>{pretty(n.needType)}</option>)}</select></label>
              <label>Support type<input required value={form.supportType} placeholder="e.g. Water tanker, Fodder" onChange={(e) => setForm({ ...form, supportType: e.target.value })} /></label>
              <label>Amount (₹)<input type="number" min="1" required value={form.amountInr} onChange={(e) => setForm({ ...form, amountInr: e.target.value })} /></label>
            </div>
            <label>Description<textarea rows={2} maxLength={500} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
            {msg && <Alert type={msg.t}>{msg.m}</Alert>}
            <button className="btn" disabled={busy}>{busy ? 'Saving...' : isNgo ? 'Offer support' : 'Record commitment'}</button>
          </form>
        </div>
      )}
      <h3 className="section-title">My {isNgo ? 'support offers' : 'commitments'}</h3>
      <Async state={mine} emptyTitle="Nothing recorded yet">
        {(rows) => <DataTable columns={[{ header: 'Date', render: (r) => dt(r.createdAt) }, { header: 'Village', key: 'village' }, { header: 'Type', key: 'supportType' }, { header: 'Amount', render: (r) => inr(r.amountInr) }, { header: 'Status', render: (r) => pretty(r.status) }]} rows={rows} />}
      </Async>
    </div>
  );
}
