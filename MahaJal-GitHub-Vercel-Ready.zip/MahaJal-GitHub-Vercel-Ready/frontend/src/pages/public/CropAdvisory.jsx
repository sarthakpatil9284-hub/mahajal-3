import { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { publicApi } from '../../services/services';
import Async from '../../components/Async';
import Alert from '../../components/Alert';
import AdvisoryView from '../../components/AdvisoryView';
import { errorMessage, pretty } from '../../utils/format';

export default function CropAdvisory() {
  const opts = useFetch(() => publicApi.advisoryOptions(), []);
  const [form, setForm] = useState({ crop: '', stage: '', weather: '', soilType: '', rainfallMm: 20, soilMoisturePct: 40, waterAvailabilityPct: 50 });
  const [result, setResult] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr(''); setResult(null);
    try {
      const res = await publicApi.advisory({ ...form, rainfallMm: Number(form.rainfallMm), soilMoisturePct: Number(form.soilMoisturePct), waterAvailabilityPct: Number(form.waterAvailabilityPct) });
      setResult(res.data);
    } catch (x) { setErr(errorMessage(x)); } finally { setBusy(false); }
  };

  return (
    <div>
      <h1>Crop Advisory</h1>
      <p className="muted">Rule-based demo advisory – illustrative guidance only, no ML.</p>
      <Async state={opts} isEmpty={(d) => !d}>
        {(o) => (
          <form className="card form" onSubmit={submit}>
            <div className="grid-2">
              <label>Crop<select required value={form.crop} onChange={set('crop')}><option value="">Select</option>{o.crops.map((c) => <option key={c}>{c}</option>)}</select></label>
              <label>Crop stage<select required value={form.stage} onChange={set('stage')}><option value="">Select</option>{o.stages.map((c) => <option key={c} value={c}>{pretty(c)}</option>)}</select></label>
              <label>Weather<select required value={form.weather} onChange={set('weather')}><option value="">Select</option>{o.weather.map((c) => <option key={c} value={c}>{pretty(c)}</option>)}</select></label>
              <label>Soil type<select required value={form.soilType} onChange={set('soilType')}><option value="">Select</option>{o.soilTypes.map((c) => <option key={c} value={c}>{pretty(c)}</option>)}</select></label>
              <label>Recent rainfall (mm)<input type="number" min="0" step="0.1" required value={form.rainfallMm} onChange={set('rainfallMm')} /></label>
              <label>Soil moisture (%)<input type="number" min="0" max="100" required value={form.soilMoisturePct} onChange={set('soilMoisturePct')} /></label>
              <label>Water availability (%)<input type="number" min="0" max="100" required value={form.waterAvailabilityPct} onChange={set('waterAvailabilityPct')} /></label>
            </div>
            <Alert type="error">{err}</Alert>
            <button className="btn" disabled={busy}>{busy ? 'Generating...' : 'Get advisory'}</button>
          </form>
        )}
      </Async>
      <AdvisoryView result={result} />
    </div>
  );
}
