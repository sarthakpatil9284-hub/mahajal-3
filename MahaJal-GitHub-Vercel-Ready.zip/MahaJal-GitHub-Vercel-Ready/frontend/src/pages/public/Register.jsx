import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Alert from '../../components/Alert';
import LocationSelect from '../../components/LocationSelect';
import { errorMessage, roleHome } from '../../utils/format';

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ fullName: '', email: '', password: '', phone: '', role: 'FARMER', organization: '' });
  const [loc, setLoc] = useState({});
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    if (f.role === 'FARMER' && !loc.villageId) return setErr('Please select your district, taluka and village.');
    if ((f.role === 'NGO' || f.role === 'CSR') && !f.organization.trim()) return setErr('Organization name is required.');
    setBusy(true);
    try {
      const body = { ...f, phone: f.phone || '', villageId: f.role === 'FARMER' ? Number(loc.villageId) : null, organization: f.organization || null };
      const u = await register(body);
      nav(roleHome(u.role), { replace: true });
    } catch (x) { setErr(errorMessage(x)); } finally { setBusy(false); }
  };

  return (
    <div className="auth-card card wide">
      <h1>Create account</h1>
      <p className="muted">Government accounts cannot be self-registered; they are created by an existing government administrator.</p>
      <form className="form" onSubmit={submit}>
        <div className="grid-2">
          <label>Full name<input required value={f.fullName} onChange={set('fullName')} /></label>
          <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
          <label>Password (min 8)<input type="password" minLength={8} required value={f.password} onChange={set('password')} /></label>
          <label>Phone (10 digits)<input pattern="[0-9]{10}" value={f.phone} onChange={set('phone')} /></label>
          <label>I am a<select value={f.role} onChange={set('role')}>
            <option value="FARMER">Farmer</option><option value="CITIZEN">Citizen</option>
            <option value="NGO">NGO</option><option value="CSR">CSR organization</option></select></label>
          {(f.role === 'NGO' || f.role === 'CSR') && <label>Organization<input value={f.organization} onChange={set('organization')} /></label>}
        </div>
        {f.role === 'FARMER' && <LocationSelect value={loc} onChange={setLoc} villageRequired />}
        <Alert type="error">{err}</Alert>
        <button className="btn btn-block" disabled={busy}>{busy ? 'Creating...' : 'Register'}</button>
      </form>
      <p>Already registered? <Link to="/login">Login</Link></p>
    </div>
  );
}
