import { useState } from 'react';
import { Link, useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Alert from '../../components/Alert';
import { errorMessage, roleHome } from '../../utils/format';

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [params] = useSearchParams();
  const [form, setForm] = useState({ email: '', password: '' });
  const [err, setErr] = useState(params.get('expired') ? 'Your session expired. Please log in again.' : '');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    try {
      const u = await login(form.email.trim(), form.password);
      nav(loc.state?.from || roleHome(u.role), { replace: true });
    } catch (x) { setErr(errorMessage(x)); } finally { setBusy(false); }
  };

  return (
    <div className="auth-card card">
      <h1>Login</h1>
      <form className="form" onSubmit={submit}>
        <label>Email<input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
        <label>Password<input type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></label>
        <Alert type="error">{err}</Alert>
        <button className="btn btn-block" disabled={busy}>{busy ? 'Signing in...' : 'Login'}</button>
      </form>
      <p><Link to="/forgot-password">Forgot password?</Link> · <Link to="/register">Create account</Link></p>
      <details className="demo-accounts"><summary>Demo accounts (password: Demo@12345)</summary>
        <ul>
          <li>Government: gov@mahajal.demo</li><li>Farmer: farmer@mahajal.demo</li>
          <li>NGO: ngo@mahajal.demo</li><li>CSR: csr@mahajal.demo</li><li>Citizen: citizen@mahajal.demo</li>
        </ul>
        <div className="quick">
          {['gov', 'farmer', 'ngo', 'csr', 'citizen'].map((r) => (
            <button type="button" key={r} className="btn btn-sm btn-outline" onClick={() => setForm({ email: `${r}@mahajal.demo`, password: 'Demo@12345' })}>{r}</button>
          ))}
        </div>
      </details>
    </div>
  );
}
