import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import useFetch from '../../hooks/useFetch';
import { publicApi, locationApi } from '../../services/services';
import Async from '../../components/Async';
import DataTable from '../../components/DataTable';
import RiskBadge from '../../components/RiskBadge';
import { num } from '../../utils/format';

export default function Rainfall() {
  const [districtId, setDistrictId] = useState('');
  const districts = useFetch(() => locationApi.districts(), []);
  const state = useFetch(() => publicApi.rainfall(districtId), [districtId]);
  return (
    <div>
      <h1>Rainfall</h1>
      <p className="muted">Monthly actual vs normal rainfall (synthetic demo data).</p>
      <label className="inline">District
        <select value={districtId} onChange={(e) => setDistrictId(e.target.value)}>
          <option value="">All Maharashtra</option>
          {(districts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </label>
      <Async state={state} isEmpty={(d) => !d || !d.series?.length} emptyTitle="No rainfall records">
        {(d) => (
          <>
            <div className="card">
              <h3>Average rainfall per month (mm)</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={d.series}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="label" /><YAxis /><Tooltip /><Legend />
                  <Bar dataKey="actual" name="Actual" fill="#1976d2" /><Bar dataKey="normal" name="Normal" fill="#9e9e9e" /></BarChart>
              </ResponsiveContainer>
            </div>
            <h3 className="section-title">Villages – latest month</h3>
            <DataTable rowKey="villageId" columns={[
              { header: 'Village', render: (r) => <Link to={`/village/${r.villageId}`}>{r.village}</Link> },
              { header: 'Taluka', key: 'taluka' }, { header: 'District', key: 'district' },
              { header: 'Actual (mm)', render: (r) => num(r.latestMm) }, { header: 'Normal (mm)', render: (r) => num(r.normalMm) },
              { header: 'Deficit %', render: (r) => num(r.deficitPct) }, { header: 'Risk', render: (r) => <RiskBadge level={r.riskLevel} /> },
            ]} rows={d.villages} />
          </>
        )}
      </Async>
    </div>
  );
}
