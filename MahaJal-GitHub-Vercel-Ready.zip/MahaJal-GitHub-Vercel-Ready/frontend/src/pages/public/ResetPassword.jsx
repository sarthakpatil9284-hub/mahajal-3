import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { authApi } from '../../services/services';
import Alert from '../../components/Alert';
import { errorMessage } from '../../utils/format';

export default function ResetPassword() {
  const [params] = useSearchParams();
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const token = params.get('token') || '';

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr(''); setMsg('');
    try { const r = await authApi.reset({ token, newPassword: pw }); setMsg(r.message); } catch (x) { setErr(errorMessage(x)); } finally { setBusy(false); }
  };

  return (
    <div className="auth-card card">
      <h1>Reset password</h1>
      {!token && <Alert type="error">Missing reset token. Use the forgot-password page first.</Alert>}
      <form className="form" onSubmit={submit}>
        <label>New password (min 8)<input type="password" minLength={8} required value={pw} onChange={(e) => setPw(e.target.value)} /></label>
        <Alert type="error">{err}</Alert>
        <Alert type="success">{msg}</Alert>
        <button className="btn btn-block" disabled={busy || !token}>{busy ? 'Saving...' : 'Update password'}</button>
      </form>
      <p><Link to="/login">Go to login</Link></p>
    </div>
  );
}
