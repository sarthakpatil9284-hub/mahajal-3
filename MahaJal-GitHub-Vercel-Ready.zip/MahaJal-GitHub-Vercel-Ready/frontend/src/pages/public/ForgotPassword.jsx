import { useState } from 'react';
import { Link } from 'react-router-dom';
import { authApi } from '../../services/services';
import Alert from '../../components/Alert';
import { errorMessage } from '../../utils/format';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [res, setRes] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr(''); setRes(null);
    try { const r = await authApi.forgot({ email: email.trim() }); setRes(r.data); } catch (x) { setErr(errorMessage(x)); } finally { setBusy(false); }
  };

  return (
    <div className="auth-card card">
      <h1>Forgot password</h1>
      <form className="form" onSubmit={submit}>
        <label>Email<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <Alert type="error">{err}</Alert>
        <button className="btn btn-block" disabled={busy}>{busy ? 'Sending...' : 'Send reset link'}</button>
      </form>
      {res && (
        <div>
          <Alert type="success">{res.message}</Alert>
          {res.demoResetToken && (
            <p className="muted">Demo mode (no email service): <Link to={`/reset-password?token=${encodeURIComponent(res.demoResetToken)}`}>open reset page</Link></p>
          )}
        </div>
      )}
      <p><Link to="/login">Back to login</Link></p>
    </div>
  );
}
