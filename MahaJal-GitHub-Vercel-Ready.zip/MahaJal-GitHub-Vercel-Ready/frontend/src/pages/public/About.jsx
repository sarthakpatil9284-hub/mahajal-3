import ScoreNote from '../../components/ScoreNote';

export default function About() {
  return (
    <div className="prose">
      <h1>About MahaJal</h1>
      <p>MahaJal is an academic decision-support platform that brings drought, rainfall, groundwater, water-source and crop information together for Maharashtra. It connects farmers, government officers, NGOs and CSR partners in one workflow.</p>
      <h3>How the risk score works</h3>
      <ScoreNote />
      <p>The score (0–100) combines four weighted factors: rainfall deficit (35%), groundwater depth (25%), water availability (20%) and crop stress (20%). Levels: Low &lt; 30, Moderate &lt; 55, High &lt; 75, Critical ≥ 75.</p>
      <h3>Support gap</h3>
      <p><code>Total Need − Government Support − NGO Support − CSR Support = Remaining Gap</code></p>
      <h3>Data disclaimer</h3>
      <p>All rainfall, groundwater, farmer, damage, need and support figures in this build are <strong>synthetic demo data</strong> generated for demonstration. They are not official government data. Advisory rules are illustrative; consult your local agriculture officer or Krishi Vigyan Kendra before acting.</p>
      <h3>Roadmap</h3>
      <p>The architecture is ready for ML drought and crop-loss prediction, satellite NDVI, GPS tanker tracking, Marathi language, PDF/Excel reports and government API integrations.</p>
    </div>
  );
}
