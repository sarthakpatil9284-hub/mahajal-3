import { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { publicApi, locationApi } from '../../services/services';
import Async from '../../components/Async';
import RiskMap from '../../components/RiskMap';
import ScoreNote from '../../components/ScoreNote';
import { RISK_COLORS } from '../../utils/format';
import VillagePanel from './VillagePanel';

export default function DroughtMap({ embedded = false }) {
  const [districtId, setDistrictId] = useState('');
  const [selected, setSelected] = useState(null);
  const districts = useFetch(() => locationApi.districts(), []);
  const state = useFetch(() => publicApi.mapVillages(districtId), [districtId]);
  return (
    <div>
      <h1>{embedded ? 'Maharashtra Map' : 'Maharashtra Drought Map'}</h1>
      <ScoreNote />
      <div className="toolbar">
        <label>District
          <select value={districtId} onChange={(e) => { setDistrictId(e.target.value); setSelected(null); }}>
            <option value="">All districts</option>
            {(districts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </label>
        <div className="legend">
          {Object.entries(RISK_COLORS).map(([k, c]) => <span key={k}><i style={{ background: c }} />{k}</span>)}
        </div>
      </div>
      <Async state={state} emptyTitle="No villages found" emptyText="No assessed villages for this selection.">
        {(list) => (
          <div className={`map-layout ${selected ? 'with-panel' : ''}`}>
            <RiskMap villages={list} onSelect={(v) => setSelected(v.id)} />
            {selected && <VillagePanel villageId={selected} onClose={() => setSelected(null)} />}
          </div>
        )}
      </Async>
      <p className="muted">Click a village marker for details. Demo data – not an official declaration.</p>
    </div>
  );
}
