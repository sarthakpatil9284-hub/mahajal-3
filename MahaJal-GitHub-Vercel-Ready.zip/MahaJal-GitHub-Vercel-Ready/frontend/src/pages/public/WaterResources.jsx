import { useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import useFetch from '../../hooks/useFetch';
import { publicApi, locationApi } from '../../services/services';
import Async from '../../components/Async';
import DataTable from '../../components/DataTable';
import { num, pretty } from '../../utils/format';

export default function WaterResources() {
  const [districtId, setDistrictId] = useState('');
  const districts = useFetch(() => locationApi.districts(), []);
  const state = useFetch(() => publicApi.water(districtId), [districtId]);
  return (
    <div>
      <h1>Water Resources</h1>
      <p className="muted">Water sources and groundwater depth (synthetic demo data).</p>
      <label className="inline">District
        <select value={districtId} onChange={(e) => setDistrictId(e.target.value)}>
          <option value="">All Maharashtra</option>
          {(districts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </label>
      <Async state={state} isEmpty={(d) => !d || (!d.sources?.length && !d.groundwater?.length)} emptyTitle="No water data">
        {(d) => (
          <>
            <div className="card">
              <h3>Deepest groundwater levels (m below ground)</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={[...d.groundwater].sort((a, b) => b.depthM - a.depthM).slice(0, 15)}>
                  <CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="village" interval={0} angle={-30} textAnchor="end" height={70} /><YAxis /><Tooltip />
                  <Bar dataKey="depthM" name="Depth (m)" fill="#00838f" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <h3 className="section-title">Water sources</h3>
            <DataTable columns={[
              { header: 'Source', key: 'name' }, { header: 'Type', render: (r) => pretty(r.type) }, { header: 'Village', key: 'village' },
              { header: 'District', key: 'district' }, { header: 'Storage', render: (r) => <div className="bar"><div className="bar-fill" style={{ width: `${r.storagePct}%` }} /><small>{num(r.storagePct, 0)}%</small></div> },
              { header: 'Functional', render: (r) => (r.functional ? 'Yes' : 'No') },
            ]} rows={d.sources} />
          </>
        )}
      </Async>
    </div>
  );
}
