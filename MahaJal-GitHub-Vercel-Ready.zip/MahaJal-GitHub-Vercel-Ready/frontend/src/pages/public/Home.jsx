import { Link } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import { publicApi } from '../../services/services';
import StatCard from '../../components/StatCard';
import ScoreNote from '../../components/ScoreNote';

export default function Home() {
  const s = useFetch(() => publicApi.mapVillages(), []);
  const list = s.data || [];
  const count = (l) => list.filter((v) => v.riskLevel === l).length;
  return (
    <>
      <section className="hero">
        <h1>MahaJal</h1>
        <h2>Maharashtra Drought &amp; Agriculture Intelligence Platform</h2>
        <p>Monitor rainfall, groundwater, water availability and crop stress across Maharashtra, give farmers rule-based advisories, and help government, NGOs and CSR partners target relief where the gap is largest.</p>
        <div className="hero-actions">
          <Link className="btn" to="/map">Open Drought Map</Link>
          <Link className="btn btn-outline-light" to="/advisory">Try Crop Advisory</Link>
        </div>
      </section>
      <ScoreNote />
      <section className="grid-4">
        <StatCard label="Villages assessed (demo)" value={s.loading ? '…' : list.length} />
        <StatCard label="Critical" value={s.loading ? '…' : count('CRITICAL')} tone="critical" />
        <StatCard label="High risk" value={s.loading ? '…' : count('HIGH')} tone="high" />
        <StatCard label="Low / Moderate" value={s.loading ? '…' : count('LOW') + count('MODERATE')} tone="low" />
      </section>
      {s.error && <p className="error-text">{s.error}</p>}
      <h3 className="section-title">What you can do</h3>
      <section className="grid-3">
        <div className="card"><h4>🗺️ Drought Map</h4><p>Explore village risk on an OpenStreetMap-based map and read why a village is at risk.</p><Link to="/map">Open map →</Link></div>
        <div className="card"><h4>🌧️ Rainfall &amp; Water</h4><p>Compare actual vs normal rainfall and view groundwater depth and water source storage.</p><Link to="/rainfall">Rainfall →</Link> · <Link to="/water">Water →</Link></div>
        <div className="card"><h4>🧭 Crop Advisory</h4><p>Rule-based irrigation, fertilizer and conservation advice with a clear explanation.</p><Link to="/advisory">Get advisory →</Link></div>
        <div className="card"><h4>🧑‍🌾 For Farmers</h4><p>Manage crops, report damage, request tankers and send SOS alerts.</p><Link to="/register">Register →</Link></div>
        <div className="card"><h4>🏛️ For Government</h4><p>Monitor districts, act on SOS, damage and tanker requests, and export reports. Accounts are issued by administrators.</p><Link to="/login">Login →</Link></div>
        <div className="card"><h4>🤝 NGO &amp; CSR</h4><p>See village needs and the remaining support gap, then record your support.</p><Link to="/register">Join →</Link></div>
      </section>
    </>
  );
}
