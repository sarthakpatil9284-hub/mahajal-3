import { useParams } from 'react-router-dom';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import useFetch from '../../hooks/useFetch';
import { publicApi } from '../../services/services';
import Async from '../../components/Async';
import StatCard from '../../components/StatCard';
import RiskBadge from '../../components/RiskBadge';
import FactorList from '../../components/FactorList';
import ScoreNote from '../../components/ScoreNote';
import DataTable from '../../components/DataTable';
import { num, inr, pretty } from '../../utils/format';

export default function VillageDashboard() {
  const { id } = useParams();
  const state = useFetch(() => publicApi.village(id), [id]);
  return (
    <Async state={state} isEmpty={(d) => !d}>
      {(v) => (
        <div>
          <h1>{v.name} <RiskBadge level={v.riskLevel} /></h1>
          <p className="muted">{v.taluka} taluka, {v.district} district · Assessed on {v.assessedOn}</p>
          <ScoreNote />
          <section className="grid-4">
            <StatCard label="Population" value={v.population.toLocaleString('en-IN')} />
            <StatCard label="Farmers" value={v.farmers.toLocaleString('en-IN')} />
            <StatCard label="Rainfall (latest)" value={`${num(v.latestRainfallMm)} mm`} hint={`Normal ${num(v.latestNormalMm)} mm`} />
            <StatCard label="Rainfall deficit" value={`${num(v.rainfallDeficitPct)}%`} />
            <StatCard label="Groundwater depth" value={`${num(v.groundwaterDepthM)} m`} />
            <StatCard label="Water availability" value={`${num(v.waterAvailabilityPct)}%`} />
            <StatCard label="Crop stress" value={`${num(v.cropStressIndex, 0)}/100`} />
            <StatCard label="Risk score" value={`${num(v.riskScore, 0)}/100`} tone={v.riskLevel.toLowerCase()} />
          </section>
          <div className="card"><h3>Why is this village at risk?</h3><FactorList factors={v.whyAtRisk} /></div>
          <div className="grid-2">
            <div className="card"><h3>Rainfall: actual vs normal (mm)</h3>
              <ResponsiveContainer width="100%" height={260}><LineChart data={v.rainfallSeries}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="label" /><YAxis /><Tooltip /><Legend />
                <Line dataKey="actual" name="Actual" stroke="#1976d2" strokeWidth={2} /><Line dataKey="normal" name="Normal" stroke="#9e9e9e" strokeDasharray="5 5" /></LineChart></ResponsiveContainer></div>
            <div className="card"><h3>Groundwater depth (m)</h3>
              <ResponsiveContainer width="100%" height={260}><LineChart data={v.groundwaterSeries}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="label" /><YAxis reversed /><Tooltip /><Legend />
                <Line dataKey="actual" name="Depth" stroke="#00838f" strokeWidth={2} /><Line dataKey="normal" name="Normal depth" stroke="#9e9e9e" strokeDasharray="5 5" /></LineChart></ResponsiveContainer></div>
          </div>
          <div className="card">
            <h3>Support gap <span className="tag-demo">DEMO</span></h3>
            <p className="formula">Total Need − Government − NGO − CSR = Remaining Gap</p>
            <section className="grid-4">
              <StatCard label="Total need" value={inr(v.supportGap.totalNeed)} />
              <StatCard label="Government" value={inr(v.supportGap.governmentSupport)} />
              <StatCard label="NGO" value={inr(v.supportGap.ngoSupport)} />
              <StatCard label="CSR" value={inr(v.supportGap.csrSupport)} />
            </section>
            <StatCard label="Remaining gap" value={inr(v.supportGap.remainingGap)} tone={v.supportGap.remainingGap > 0 ? 'high' : 'low'} />
          </div>
          <h3 className="section-title">Water sources</h3>
          {v.waterSources.length ? <DataTable columns={[{ header: 'Name', key: 'name' }, { header: 'Type', render: (r) => pretty(r.type) }, { header: 'Storage', render: (r) => `${num(r.storagePct, 0)}%` }, { header: 'Functional', render: (r) => (r.functional ? 'Yes' : 'No') }]} rows={v.waterSources} /> : <p className="muted">No water sources recorded.</p>}
          <h3 className="section-title">Village needs <span className="tag-demo">DEMO</span></h3>
          {v.needs.length ? <DataTable columns={[{ header: 'Need', render: (r) => pretty(r.needType) }, { header: 'Description', key: 'description' }, { header: 'Est. cost', render: (r) => inr(r.estimatedCostInr) }, { header: 'Priority', key: 'priority' }]} rows={v.needs} /> : <p className="muted">No needs recorded.</p>}
        </div>
      )}
    </Async>
  );
}
