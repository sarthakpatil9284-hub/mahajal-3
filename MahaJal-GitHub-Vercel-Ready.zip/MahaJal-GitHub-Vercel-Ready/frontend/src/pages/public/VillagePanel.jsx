import { Link } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import { publicApi } from '../../services/services';
import Async from '../../components/Async';
import RiskBadge from '../../components/RiskBadge';
import FactorList from '../../components/FactorList';
import { num } from '../../utils/format';

export default function VillagePanel({ villageId, onClose }) {
  const state = useFetch(() => publicApi.village(villageId), [villageId]);
  return (
    <div className="card side-panel">
      <button className="alert-x" onClick={onClose} aria-label="Close">×</button>
      <Async state={state} isEmpty={(d) => !d}>
        {(v) => (
          <>
            <h3>{v.name}</h3>
            <p className="muted">{v.taluka}, {v.district} <RiskBadge level={v.riskLevel} /></p>
            <ul className="kv">
              <li><span>Risk score</span><b>{num(v.riskScore, 0)} / 100</b></li>
              <li><span>Rainfall</span><b>{num(v.latestRainfallMm)} mm</b></li>
              <li><span>Rainfall deficit</span><b>{num(v.rainfallDeficitPct)}%</b></li>
              <li><span>Groundwater depth</span><b>{num(v.groundwaterDepthM)} m</b></li>
              <li><span>Water availability</span><b>{num(v.waterAvailabilityPct)}%</b></li>
              <li><span>Crop stress</span><b>{num(v.cropStressIndex, 0)} / 100</b></li>
            </ul>
            <small className="muted">{v.scoreLabel}</small>
            <h4>Why at risk?</h4>
            <FactorList factors={v.whyAtRisk} />
            <Link className="btn btn-block" to={`/village/${v.id}`}>Full village dashboard</Link>
          </>
        )}
      </Async>
    </div>
  );
}
