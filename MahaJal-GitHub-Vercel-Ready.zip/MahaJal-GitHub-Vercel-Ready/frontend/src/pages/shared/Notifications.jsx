import { useOutletContext } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import { notificationApi } from '../../services/services';
import Async from '../../components/Async';
import { dt } from '../../utils/format';

export default function Notifications() {
  const ctx = useOutletContext() || {};
  const state = useFetch(() => notificationApi.list(), []);
  const markAll = async () => { await notificationApi.readAll(); ctx.setUnread?.(0); state.reload(); };
  const markOne = async (n) => { if (n.seen) return; await notificationApi.read(n.id); ctx.setUnread?.((u) => Math.max(0, (u || 0) - 1)); state.reload(); };
  return (
    <div>
      <div className="row-between"><h1>Notifications</h1><button className="btn btn-outline" onClick={markAll}>Mark all read</button></div>
      <Async state={state} emptyTitle="No notifications" emptyText="You are all caught up.">
        {(list) => (
          <div className="notif-list">
            {list.map((n) => (
              <div key={n.id} className={`notif ${n.seen ? '' : 'unseen'} notif-${(n.type || 'INFO').toLowerCase()}`} onClick={() => markOne(n)}>
                <strong>{n.title}</strong><p>{n.message}</p><small>{dt(n.createdAt)}</small>
              </div>
            ))}
          </div>
        )}
      </Async>
    </div>
  );
}
