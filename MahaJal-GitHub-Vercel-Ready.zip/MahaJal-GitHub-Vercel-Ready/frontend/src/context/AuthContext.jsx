import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { authApi } from '../services/services';
import { TOKEN_KEY, USER_KEY } from '../services/api';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch { return null; }
  });
  const [loading, setLoading] = useState(!!localStorage.getItem(TOKEN_KEY));

  const persist = (res) => {
    localStorage.setItem(TOKEN_KEY, res.data.token);
    localStorage.setItem(USER_KEY, JSON.stringify(res.data.user));
    setUser(res.data.user);
    return res.data.user;
  };

  // Validate the stored token on page load.
  useEffect(() => {
    if (!localStorage.getItem(TOKEN_KEY)) return;
    authApi.me()
      .then((u) => { localStorage.setItem(USER_KEY, JSON.stringify(u)); setUser(u); })
      .catch(() => { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); setUser(null); })
      .finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (email, password) => persist(await authApi.login({ email, password })), []);
  const register = useCallback(async (body) => persist(await authApi.register(body)), []);
  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    setUser(null);
  }, []);

  return <AuthContext.Provider value={{ user, loading, login, register, logout }}>{children}</AuthContext.Provider>;
}
