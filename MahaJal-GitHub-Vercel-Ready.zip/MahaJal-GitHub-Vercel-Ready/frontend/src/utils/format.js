export const SCORE_LABEL = 'MahaJal Analytical Drought Risk Score – Demo/Decision Support';
export const DEMO_NOTE = 'All data shown is synthetic DEMO data for decision-support demonstration. It is not official government data and not an official drought declaration.';

export const RISK_COLORS = { LOW: '#2e9d57', MODERATE: '#e0b400', HIGH: '#ef7d1a', CRITICAL: '#c62828' };

export function errorMessage(e) {
  if (!e) return 'Something went wrong';
  if (e.response?.data?.message) return e.response.data.message;
  if (e.code === 'ECONNABORTED') return 'The server took too long to respond. Please try again.';
  if (e.message === 'Network Error') return 'Cannot reach the server. Is the backend running?';
  return e.message || 'Something went wrong';
}

export const inr = (n) => '₹ ' + Number(n || 0).toLocaleString('en-IN');
export const num = (n, d = 1) => (n === null || n === undefined ? '–' : Number(n).toFixed(d));
export const dt = (s) => (s ? new Date(s).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '–');
export const pretty = (s) => (s ? s.replaceAll('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase()).replace(/(\w)(\w*)/g, (m, a, b) => a + b.toLowerCase()) : '');

export function roleHome(role) {
  switch (role) {
    case 'FARMER': return '/farmer';
    case 'GOVERNMENT': return '/gov';
    case 'NGO': return '/ngo';
    case 'CSR': return '/csr';
    default: return '/map';
  }
}

export function downloadCsv(filename, rows) {
  if (!rows?.length) return;
  const keys = Object.keys(rows[0]);
  const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const csv = [keys.join(','), ...rows.map((r) => keys.map((k) => esc(r[k])).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}
