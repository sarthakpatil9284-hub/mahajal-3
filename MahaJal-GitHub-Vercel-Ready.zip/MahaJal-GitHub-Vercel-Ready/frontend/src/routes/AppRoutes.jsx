import { Routes, Route } from 'react-router-dom';
import ProtectedRoute from './ProtectedRoute';
import PublicLayout from '../layouts/PublicLayout';
import FarmerLayout from '../layouts/FarmerLayout';
import GovLayout from '../layouts/GovLayout';
import NgoLayout from '../layouts/NgoLayout';
import CsrLayout from '../layouts/CsrLayout';

import Home from '../pages/public/Home';
import About from '../pages/public/About';
import DroughtMap from '../pages/public/DroughtMap';
import Rainfall from '../pages/public/Rainfall';
import WaterResources from '../pages/public/WaterResources';
import CropAdvisory from '../pages/public/CropAdvisory';
import Login from '../pages/public/Login';
import Register from '../pages/public/Register';
import ForgotPassword from '../pages/public/ForgotPassword';
import ResetPassword from '../pages/public/ResetPassword';
import VillageDashboard from '../pages/public/VillageDashboard';
import NotFound from '../pages/public/NotFound';

import FarmerDashboard from '../pages/farmer/Dashboard';
import Profile from '../pages/farmer/Profile';
import MyCrops from '../pages/farmer/MyCrops';
import CropDetails from '../pages/farmer/CropDetails';
import FarmerAdvisory from '../pages/farmer/Advisory';
import ReportDamage from '../pages/farmer/ReportDamage';
import TankerRequest from '../pages/farmer/TankerRequest';
import Sos from '../pages/farmer/Sos';
import Notifications from '../pages/shared/Notifications';

import GovDashboard from '../pages/gov/Dashboard';
import GovMap from '../pages/gov/GovMap';
import Districts from '../pages/gov/Districts';
import Villages from '../pages/gov/Villages';
import Farmers from '../pages/gov/Farmers';
import Damage from '../pages/gov/Damage';
import SosReports from '../pages/gov/SosReports';
import Tankers from '../pages/gov/Tankers';
import Analytics from '../pages/gov/Analytics';
import Reports from '../pages/gov/Reports';

import PartnerDashboard from '../pages/partner/PartnerDashboard';

export default function AppRoutes() {
  return (
    <Routes>
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/map" element={<DroughtMap />} />
        <Route path="/rainfall" element={<Rainfall />} />
        <Route path="/water" element={<WaterResources />} />
        <Route path="/advisory" element={<CropAdvisory />} />
        <Route path="/village/:id" element={<VillageDashboard />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="*" element={<NotFound />} />
      </Route>

      <Route path="/farmer" element={<ProtectedRoute roles={['FARMER']}><FarmerLayout /></ProtectedRoute>}>
        <Route index element={<FarmerDashboard />} />
        <Route path="profile" element={<Profile />} />
        <Route path="crops" element={<MyCrops />} />
        <Route path="crops/:id" element={<CropDetails />} />
        <Route path="advisory" element={<FarmerAdvisory />} />
        <Route path="damage" element={<ReportDamage />} />
        <Route path="tanker" element={<TankerRequest />} />
        <Route path="sos" element={<Sos />} />
        <Route path="notifications" element={<Notifications />} />
      </Route>

      <Route path="/gov" element={<ProtectedRoute roles={['GOVERNMENT']}><GovLayout /></ProtectedRoute>}>
        <Route index element={<GovDashboard />} />
        <Route path="map" element={<GovMap />} />
        <Route path="districts" element={<Districts />} />
        <Route path="villages" element={<Villages />} />
        <Route path="farmers" element={<Farmers />} />
        <Route path="damage" element={<Damage />} />
        <Route path="sos" element={<SosReports />} />
        <Route path="tankers" element={<Tankers />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="reports" element={<Reports />} />
        <Route path="notifications" element={<Notifications />} />
      </Route>

      <Route path="/ngo" element={<ProtectedRoute roles={['NGO']}><NgoLayout /></ProtectedRoute>}>
        <Route index element={<PartnerDashboard type="NGO" />} />
        <Route path="notifications" element={<Notifications />} />
      </Route>

      <Route path="/csr" element={<ProtectedRoute roles={['CSR']}><CsrLayout /></ProtectedRoute>}>
        <Route index element={<PartnerDashboard type="CSR" />} />
        <Route path="notifications" element={<Notifications />} />
      </Route>
    </Routes>
  );
}
