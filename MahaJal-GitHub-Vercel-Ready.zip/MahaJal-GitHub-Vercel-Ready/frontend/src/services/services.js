import { get, post, put, patch, del } from './api';

export const authApi = {
  login: (b) => post('/auth/login', b),
  register: (b) => post('/auth/register', b),
  forgot: (b) => post('/auth/forgot-password', b),
  reset: (b) => post('/auth/reset-password', b),
  me: () => get('/auth/me'),
};

export const locationApi = {
  districts: () => get('/locations/districts'),
  talukas: (id) => get(`/locations/districts/${id}/talukas`),
  villages: (id) => get(`/locations/talukas/${id}/villages`),
};

export const publicApi = {
  mapVillages: (districtId) => get('/map/villages', { districtId: districtId || undefined }),
  mapDistricts: () => get('/map/districts'),
  village: (id) => get(`/villages/${id}/dashboard`),
  rainfall: (districtId) => get('/rainfall', { districtId: districtId || undefined }),
  water: (districtId) => get('/water', { districtId: districtId || undefined }),
  advisoryOptions: () => get('/advisory/options'),
  advisory: (b) => post('/advisory', b),
};

export const farmerApi = {
  dashboard: () => get('/farmer/dashboard'),
  profile: () => get('/farmer/profile'),
  updateProfile: (b) => put('/farmer/profile', b),
  crops: () => get('/farmer/crops'),
  crop: (id) => get(`/farmer/crops/${id}`),
  addCrop: (b) => post('/farmer/crops', b),
  deleteCrop: (id) => del(`/farmer/crops/${id}`),
  cropAdvisory: (id, weather) => get(`/farmer/crops/${id}/advisory`, { weather }),
  damage: () => get('/farmer/damage-reports'),
  reportDamage: (b) => post('/farmer/damage-reports', b),
  tankers: () => get('/farmer/tanker-requests'),
  requestTanker: (b) => post('/farmer/tanker-requests', b),
  sos: () => get('/farmer/sos'),
  sendSos: (b) => post('/farmer/sos', b),
};

export const notificationApi = {
  list: () => get('/notifications'),
  unread: () => get('/notifications/unread-count'),
  read: (id) => post(`/notifications/${id}/read`),
  readAll: () => post('/notifications/read-all'),
};

export const govApi = {
  dashboard: () => get('/gov/dashboard'),
  districts: () => get('/gov/districts'),
  villages: (districtId) => get('/gov/villages', { districtId: districtId || undefined }),
  farmers: () => get('/gov/farmers'),
  damage: () => get('/gov/damage-reports'),
  updateDamage: (id, b) => patch(`/gov/damage-reports/${id}/status`, b),
  sos: () => get('/gov/sos'),
  updateSos: (id, b) => patch(`/gov/sos/${id}/status`, b),
  tankers: () => get('/gov/tanker-requests'),
  updateTanker: (id, b) => patch(`/gov/tanker-requests/${id}/status`, b),
  analytics: () => get('/gov/analytics'),
  addObservation: (b) => post('/gov/observations', b),
  recalculate: () => post('/gov/recalculate'),
  createUser: (b) => post('/gov/users', b),
};

export const partnerApi = {
  villages: (districtId) => get('/partner/villages', { districtId: districtId || undefined }),
  needs: (villageId) => get(`/partner/villages/${villageId}/needs`),
  ngoList: () => get('/ngo/support'),
  ngoOffer: (b) => post('/ngo/support', b),
  csrList: () => get('/csr/support'),
  csrCommit: (b) => post('/csr/support', b),
};
