import axios from 'axios';

export const TOKEN_KEY = 'mahajal_token';
export const USER_KEY = 'mahajal_user';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || '/api', timeout: 20000 });

api.interceptors.request.use((cfg) => {
  const t = localStorage.getItem(TOKEN_KEY);
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    const url = err.config?.url || '';
    if (err.response?.status === 401 && localStorage.getItem(TOKEN_KEY) && !url.includes('/auth/login')) {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      window.location.href = '/login?expired=1';
    }
    return Promise.reject(err);
  }
);

// Every backend response is { success, message, data, timestamp }; helpers return `data`.
export const get = (u, params) => api.get(u, { params }).then((r) => r.data.data);
export const post = (u, body) => api.post(u, body).then((r) => r.data);
export const put = (u, body) => api.put(u, body).then((r) => r.data);
export const patch = (u, body) => api.patch(u, body).then((r) => r.data);
export const del = (u) => api.delete(u).then((r) => r.data);
export default api;
