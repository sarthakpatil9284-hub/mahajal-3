import DashboardShell from '../components/DashboardShell';

const links = [
  { to: '/farmer', label: '🏠 Dashboard', end: true }, { to: '/farmer/profile', label: '👤 Profile' },
  { to: '/farmer/crops', label: '🌾 My Crops' }, { to: '/farmer/advisory', label: '🧭 Crop Advisory' },
  { to: '/farmer/damage', label: '⚠️ Report Damage' }, { to: '/farmer/tanker', label: '🚚 Water / Tanker' },
  { to: '/farmer/sos', label: '🆘 SOS' }, { to: '/farmer/notifications', label: '🔔 Notifications', notif: true },
  { to: '/map', label: '🗺️ Drought Map' },
];
export default function FarmerLayout() { return <DashboardShell title="Farmer Portal" links={links} accent="#2e7d32" />; }
