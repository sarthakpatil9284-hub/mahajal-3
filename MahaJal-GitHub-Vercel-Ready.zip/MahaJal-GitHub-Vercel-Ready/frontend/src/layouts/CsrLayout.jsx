import DashboardShell from '../components/DashboardShell';

const links = [
  { to: '/csr', label: '🏢 Village Needs & Commitments', end: true }, { to: '/map', label: '🗺️ Drought Map' },
  { to: '/csr/notifications', label: '🔔 Notifications', notif: true },
];
export default function CsrLayout() { return <DashboardShell title="CSR Portal" links={links} accent="#ef6c00" />; }
