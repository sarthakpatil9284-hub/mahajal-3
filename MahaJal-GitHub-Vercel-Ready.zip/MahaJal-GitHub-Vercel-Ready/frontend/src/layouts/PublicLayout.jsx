import { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { roleHome } from '../utils/format';
import DemoBanner from '../components/DemoBanner';

const links = [
  ['/', 'Home', true], ['/about', 'About'], ['/map', 'Drought Map'], ['/rainfall', 'Rainfall'],
  ['/water', 'Water Resources'], ['/advisory', 'Crop Advisory'],
];

export default function PublicLayout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  return (
    <div className="public">
      <header className="navbar">
        <div className="container nav-inner">
          <Link to="/" className="brand">💧 MahaJal</Link>
          <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Menu">☰</button>
          <nav className={open ? 'open' : ''} onClick={() => setOpen(false)}>
            {links.map(([to, label, end]) => <NavLink key={to} to={to} end={end}>{label}</NavLink>)}
            {user ? (
              <>
                <Link className="btn btn-sm" to={roleHome(user.role)}>My Dashboard</Link>
                <button className="btn btn-sm btn-outline-light" onClick={() => { logout(); nav('/'); }}>Logout</button>
              </>
            ) : (
              <>
                <Link className="btn btn-sm btn-outline-light" to="/login">Login</Link>
                <Link className="btn btn-sm" to="/register">Register</Link>
              </>
            )}
          </nav>
        </div>
      </header>
      <DemoBanner />
      <main className="container page"><Outlet /></main>
      <footer className="footer">
        <div className="container">
          <strong>MahaJal</strong> – Maharashtra Drought &amp; Agriculture Intelligence Platform · Academic demo project.
          <br /><small>Synthetic demo data. Not an official government source or drought declaration.</small>
        </div>
      </footer>
    </div>
  );
}
