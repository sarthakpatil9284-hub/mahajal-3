import DashboardShell from '../components/DashboardShell';

const links = [
  { to: '/gov', label: '📊 Dashboard', end: true }, { to: '/gov/map', label: '🗺️ Maharashtra Map' },
  { to: '/gov/districts', label: '🏛️ Districts' }, { to: '/gov/villages', label: '🏘️ Villages' },
  { to: '/gov/farmers', label: '🧑‍🌾 Farmers' }, { to: '/gov/damage', label: '⚠️ Crop Damage' },
  { to: '/gov/sos', label: '🆘 SOS Reports' }, { to: '/gov/tankers', label: '🚚 Tanker Requests' },
  { to: '/gov/analytics', label: '📈 Drought Analytics' }, { to: '/gov/reports', label: '📄 Reports' },
  { to: '/gov/notifications', label: '🔔 Notifications', notif: true },
];
export default function GovLayout() { return <DashboardShell title="Government Portal" links={links} accent="#1565c0" />; }
