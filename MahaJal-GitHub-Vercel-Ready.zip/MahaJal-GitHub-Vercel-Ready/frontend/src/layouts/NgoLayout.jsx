import DashboardShell from '../components/DashboardShell';

const links = [
  { to: '/ngo', label: '🤝 Village Needs & Support', end: true }, { to: '/map', label: '🗺️ Drought Map' },
  { to: '/ngo/notifications', label: '🔔 Notifications', notif: true },
];
export default function NgoLayout() { return <DashboardShell title="NGO Portal" links={links} accent="#6a1b9a" />; }
