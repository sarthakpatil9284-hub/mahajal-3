import RiskBadge from './RiskBadge';

export default function FactorList({ factors = [] }) {
  if (!factors.length) return <p className="muted">No factor breakdown available.</p>;
  return (
    <div className="factors">
      {factors.map((f) => (
        <div className="factor" key={f.name}>
          <div className="factor-head">
            <strong>{f.name}</strong>
            <span>{f.value}</span>
            <RiskBadge level={f.level} />
          </div>
          <div className="bar"><div className="bar-fill" style={{ width: `${f.maxPoints ? (f.points / f.maxPoints) * 100 : 0}%` }} /></div>
          <small>{f.points.toFixed(1)} / {f.maxPoints} pts — {f.explanation}</small>
        </div>
      ))}
    </div>
  );
}
