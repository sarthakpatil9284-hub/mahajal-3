import { SCORE_LABEL } from '../utils/format';

export default function ScoreNote() {
  return (
    <p className="score-note">
      <strong>{SCORE_LABEL}</strong>. This is an analytical indicator for decision support only and is not an official drought declaration.
    </p>
  );
}
