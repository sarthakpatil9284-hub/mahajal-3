import { MapContainer, TileLayer, CircleMarker, Tooltip } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { RISK_COLORS } from '../utils/format';

export default function RiskMap({ villages = [], onSelect, height = 520 }) {
  return (
    <MapContainer center={[19, 76]} zoom={7} style={{ height, width: '100%', borderRadius: 10 }} scrollWheelZoom>
      <TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {villages.map((v) => (
        <CircleMarker
          key={v.id}
          center={[v.latitude, v.longitude]}
          radius={8}
          pathOptions={{ color: '#fff', weight: 1.5, fillColor: RISK_COLORS[v.riskLevel] || '#777', fillOpacity: 0.9 }}
          eventHandlers={{ click: () => onSelect && onSelect(v) }}
        >
          <Tooltip>{v.name} ({v.district}) – {v.riskLevel} ({Number(v.riskScore).toFixed(0)})</Tooltip>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
