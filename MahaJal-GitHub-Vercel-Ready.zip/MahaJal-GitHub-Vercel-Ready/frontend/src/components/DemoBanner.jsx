import { DEMO_NOTE } from '../utils/format';

export default function DemoBanner() {
  return <div className="demo-banner"><strong>DEMO DATA</strong> — {DEMO_NOTE}</div>;
}
