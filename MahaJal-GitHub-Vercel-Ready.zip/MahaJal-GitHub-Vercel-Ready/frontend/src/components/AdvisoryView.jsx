import RiskBadge from './RiskBadge';

const stressTone = { LOW: 'LOW', MODERATE: 'MODERATE', HIGH: 'HIGH', CRITICAL: 'CRITICAL' };

export default function AdvisoryView({ result }) {
  if (!result) return null;
  return (
    <div className="card advisory">
      <h3>Advisory result <RiskBadge level={stressTone[result.cropStressLevel]} /></h3>
      <p><strong>Crop stress:</strong> {result.cropStressLevel} ({result.cropStressScore.toFixed(0)}/100)</p>
      <div className="grid-2">
        <div><h4>💧 Irrigation advice</h4><p>{result.irrigationAdvice}</p></div>
        <div><h4>🌧️ Rainfall advice</h4><p>{result.rainfallAdvice}</p></div>
        <div><h4>🌱 Fertilizer timing</h4><p>{result.fertilizerAdvice}</p></div>
        <div><h4>♻️ Water conservation</h4><p>{result.conservationAdvice}</p></div>
      </div>
      <details open className="why">
        <summary>Why this advisory?</summary>
        <ul>{result.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
        <small className="muted">{result.ruleSet}</small>
      </details>
    </div>
  );
}
