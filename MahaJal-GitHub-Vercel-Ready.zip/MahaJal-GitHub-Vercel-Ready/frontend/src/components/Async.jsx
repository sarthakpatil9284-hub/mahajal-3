import Loader from './Loader';
import Alert from './Alert';
import EmptyState from './EmptyState';

/** Wraps a useFetch result: loading -> error -> empty -> children(data). */
export default function Async({ state, children, emptyTitle, emptyText, isEmpty }) {
  const { data, loading, error, reload } = state;
  if (loading) return <Loader />;
  if (error) {
    return (
      <div>
        <Alert type="error">{error}</Alert>
        <button className="btn btn-outline" onClick={reload}>Retry</button>
      </div>
    );
  }
  const empty = isEmpty ? isEmpty(data) : Array.isArray(data) && data.length === 0;
  if (empty) return <EmptyState title={emptyTitle} text={emptyText} />;
  return children(data);
}
