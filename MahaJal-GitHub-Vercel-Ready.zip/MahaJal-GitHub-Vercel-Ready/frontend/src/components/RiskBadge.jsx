import { RISK_COLORS } from '../utils/format';

export default function RiskBadge({ level }) {
  if (!level) return null;
  return <span className="badge" style={{ background: RISK_COLORS[level] || '#777' }}>{level}</span>;
}
