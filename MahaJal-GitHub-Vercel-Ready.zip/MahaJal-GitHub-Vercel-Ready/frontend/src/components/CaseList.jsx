import { useState } from 'react';
import Alert from './Alert';
import Async from './Async';
import DataTable from './DataTable';
import useFetch from '../hooks/useFetch';
import { errorMessage } from '../utils/format';

/** Generic government table with an inline status-update control. */
export default function CaseList({ fetcher, updater, statuses, columns, emptyTitle }) {
  const state = useFetch(fetcher, []);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(null);

  const change = async (row, status) => {
    setBusy(row.id); setMsg(null);
    try {
      await updater(row.id, { status, remarks: `Updated by government user to ${status}` });
      setMsg({ t: 'success', m: `Status updated to ${status}` });
      state.reload();
    } catch (e) { setMsg({ t: 'error', m: errorMessage(e) }); } finally { setBusy(null); }
  };

  const cols = [...columns, {
    header: 'Action',
    render: (r) => (
      <select value={r.status} disabled={busy === r.id} onChange={(e) => change(r, e.target.value)}>
        {statuses.map((s) => <option key={s} value={s}>{s.replaceAll('_', ' ')}</option>)}
      </select>
    ),
  }];

  return (
    <>
      {msg && <Alert type={msg.t} onClose={() => setMsg(null)}>{msg.m}</Alert>}
      <Async state={state} emptyTitle={emptyTitle}>{(rows) => <DataTable columns={cols} rows={rows} />}</Async>
    </>
  );
}
