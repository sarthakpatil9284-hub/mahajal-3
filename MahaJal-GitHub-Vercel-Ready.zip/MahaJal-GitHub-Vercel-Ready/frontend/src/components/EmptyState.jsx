export default function EmptyState({ title = 'Nothing to show', text, children }) {
  return (
    <div className="empty">
      <div className="empty-icon">🗂️</div>
      <h4>{title}</h4>
      {text && <p>{text}</p>}
      {children}
    </div>
  );
}
