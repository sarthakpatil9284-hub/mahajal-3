import { useEffect, useState } from 'react';
import { NavLink, Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { notificationApi } from '../services/services';
import DemoBanner from './DemoBanner';

/** Shared sidebar shell used by the Farmer/Government/NGO/CSR layouts. */
export default function DashboardShell({ title, links, accent }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = () => notificationApi.unread().then((n) => alive && setUnread(typeof n === 'object' ? n.count ?? 0 : n)).catch(() => {});
    load();
    const t = setInterval(load, 30000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  return (
    <div className="shell" style={{ '--accent': accent }}>
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <Link to="/" className="brand">💧 MahaJal</Link>
        <div className="side-title">{title}</div>
        <nav onClick={() => setOpen(false)}>
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={({ isActive }) => (isActive ? 'active' : '')}>
              {l.label}{l.notif && unread > 0 && <span className="pill">{unread}</span>}
            </NavLink>
          ))}
        </nav>
        <div className="side-foot">
          <div className="who"><strong>{user?.fullName}</strong><small>{user?.role}{user?.organization ? ` · ${user.organization}` : ''}</small></div>
          <button className="btn btn-outline btn-block" onClick={() => { logout(); nav('/login'); }}>Logout</button>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Menu">☰</button>
          <span className="topbar-title">{title}</span>
        </header>
        <DemoBanner />
        <div className="content"><Outlet context={{ unread, setUnread }} /></div>
      </div>
    </div>
  );
}
