export default function Alert({ type = 'info', children, onClose }) {
  if (!children) return null;
  return (
    <div className={`alert alert-${type}`} role={type === 'error' ? 'alert' : 'status'}>
      <span>{children}</span>
      {onClose && <button className="alert-x" onClick={onClose} aria-label="Dismiss">×</button>}
    </div>
  );
}
