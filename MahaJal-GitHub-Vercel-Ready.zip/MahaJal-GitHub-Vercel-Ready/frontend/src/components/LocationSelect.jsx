import { useEffect, useState } from 'react';
import { locationApi } from '../services/services';

/** District -> Taluka -> Village cascade. Calls onChange({districtId, talukaId, villageId}). */
export default function LocationSelect({ value = {}, onChange, villageRequired = false, showVillage = true, disabled }) {
  const [districts, setDistricts] = useState([]);
  const [talukas, setTalukas] = useState([]);
  const [villages, setVillages] = useState([]);
  const [err, setErr] = useState('');
  const { districtId = '', talukaId = '', villageId = '' } = value;

  useEffect(() => { locationApi.districts().then(setDistricts).catch(() => setErr('Could not load districts')); }, []);
  useEffect(() => {
    if (!districtId) { setTalukas([]); return; }
    locationApi.talukas(districtId).then(setTalukas).catch(() => setErr('Could not load talukas'));
  }, [districtId]);
  useEffect(() => {
    if (!talukaId) { setVillages([]); return; }
    locationApi.villages(talukaId).then(setVillages).catch(() => setErr('Could not load villages'));
  }, [talukaId]);

  return (
    <div className="grid-3">
      <label>District
        <select disabled={disabled} value={districtId} onChange={(e) => onChange({ districtId: e.target.value, talukaId: '', villageId: '' })}>
          <option value="">Select district</option>
          {districts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </label>
      <label>Taluka
        <select disabled={disabled || !districtId} value={talukaId} onChange={(e) => onChange({ districtId, talukaId: e.target.value, villageId: '' })}>
          <option value="">{districtId ? 'Select taluka' : 'Select district first'}</option>
          {talukas.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </label>
      {showVillage && (
        <label>Village
          <select disabled={disabled || !talukaId} required={villageRequired} value={villageId} onChange={(e) => onChange({ districtId, talukaId, villageId: e.target.value })}>
            <option value="">{talukaId ? 'Select village' : 'Select taluka first'}</option>
            {villages.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
        </label>
      )}
      {err && <small className="error-text">{err}</small>}
    </div>
  );
}
