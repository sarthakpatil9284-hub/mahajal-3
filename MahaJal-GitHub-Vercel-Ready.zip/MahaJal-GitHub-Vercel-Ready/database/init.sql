-- MahaJal database bootstrap (MySQL 8+).
-- Tables are created automatically by Hibernate (spring.jpa.hibernate.ddl-auto=update).
-- Demo data is inserted on first start by the backend's DemoDataSeeder (SEED_DEMO=true).
CREATE DATABASE IF NOT EXISTS mahajal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Optional dedicated user (then set DB_USERNAME=mahajal / DB_PASSWORD=mahajal_pass):
-- CREATE USER IF NOT EXISTS 'mahajal'@'%' IDENTIFIED BY 'mahajal_pass';
-- GRANT ALL PRIVILEGES ON mahajal.* TO 'mahajal'@'%';
-- FLUSH PRIVILEGES;
