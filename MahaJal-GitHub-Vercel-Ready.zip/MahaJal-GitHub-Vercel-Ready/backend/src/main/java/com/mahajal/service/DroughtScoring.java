package com.mahajal.service;

import com.mahajal.dto.Dtos.Factor;
import com.mahajal.entity.Enums.RiskLevel;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;

/**
 * Transparent, rule-based analytical score (0-100). NOT an official drought declaration.
 * Weights: rainfall deficit 35%, groundwater depth 25%, water availability 20%, crop stress 20%.
 * Designed so an ML model (e.g. a Python FastAPI service) can later replace or complement it.
 */
@Component
public class DroughtScoring {
    public static final String LABEL = "MahaJal Analytical Drought Risk Score – Demo/Decision Support";
    static final double W_RAIN = 0.35, W_GW = 0.25, W_WATER = 0.20, W_STRESS = 0.20;

    static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    double rainSub(double deficitPct) { return clamp(deficitPct / 60.0 * 100.0, 0, 100); }
    double gwSub(double depthM) { return clamp((depthM - 5.0) / 30.0 * 100.0, 0, 100); }
    double waterSub(double availPct) { return clamp(100.0 - availPct, 0, 100); }

    public double cropStress(double deficitPct, double soilMoisturePct) {
        return Mappers.round1(clamp(0.7 * rainSub(deficitPct) + 0.3 * (100.0 - soilMoisturePct), 0, 100));
    }

    public double score(double deficitPct, double gwDepthM, double waterAvailPct, double cropStress) {
        double s = W_RAIN * rainSub(deficitPct) + W_GW * gwSub(gwDepthM) + W_WATER * waterSub(waterAvailPct)
                + W_STRESS * clamp(cropStress, 0, 100);
        return Mappers.round1(s);
    }

    public static RiskLevel level(double score) {
        if (score < 30) return RiskLevel.LOW;
        if (score < 55) return RiskLevel.MODERATE;
        if (score < 75) return RiskLevel.HIGH;
        return RiskLevel.CRITICAL;
    }

    private String subLevel(double sub) { return level(sub).name(); }

    public List<Factor> explain(double deficitPct, double gwDepthM, double waterAvailPct, double cropStress) {
        double r = rainSub(deficitPct), g = gwSub(gwDepthM), w = waterSub(waterAvailPct), c = clamp(cropStress, 0, 100);
        String rainTxt = deficitPct >= 0
                ? String.format(Locale.ROOT, "Seasonal rainfall is %.1f%% below the (demo) normal, so soil and surface water are not being replenished.", deficitPct)
                : String.format(Locale.ROOT, "Seasonal rainfall is %.1f%% above the (demo) normal, which reduces risk.", -deficitPct);
        return List.of(
            new Factor("Rainfall deficit", String.format(Locale.ROOT, "%.1f%%", deficitPct), Mappers.round1(W_RAIN * r),
                    W_RAIN * 100, subLevel(r), rainTxt),
            new Factor("Groundwater depth", String.format(Locale.ROOT, "%.1f m", gwDepthM), Mappers.round1(W_GW * g),
                    W_GW * 100, subLevel(g), String.format(Locale.ROOT,
                    "Water table is about %.1f m below ground; deeper water makes wells and borewells harder to sustain.", gwDepthM)),
            new Factor("Water availability", String.format(Locale.ROOT, "%.1f%%", waterAvailPct), Mappers.round1(W_WATER * w),
                    W_WATER * 100, subLevel(w), String.format(Locale.ROOT,
                    "Local sources (tanks, wells, dams) hold roughly %.1f%% of their usable storage.", waterAvailPct)),
            new Factor("Crop stress", String.format(Locale.ROOT, "%.1f / 100", cropStress), Mappers.round1(W_STRESS * c),
                    W_STRESS * 100, subLevel(c),
                    "Crop stress index combines the rainfall shortfall with low soil moisture; high values indicate likely yield loss.")
        );
    }
}
