package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "crop_damage_reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CropDamageReport {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "farmer_id") private Farmer farmer;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "crop_id") private Crop crop;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id") private Village village;
    @Column(length = 80) private String cause;
    private int damagePercent;
    private double areaAffectedAcres;
    @Column(length = 1000) private String description;
    @Enumerated(EnumType.STRING) @Column(length = 20) @Builder.Default private ReportStatus status = ReportStatus.SUBMITTED;
    @Column(length = 500) private String remarks;
    @Builder.Default private LocalDateTime createdAt = LocalDateTime.now();
    @Builder.Default private boolean demoData = false;
}
