package com.mahajal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MahaJalApplication {
    public static void main(String[] args) {
        SpringApplication.run(MahaJalApplication.class, args);
    }
}
