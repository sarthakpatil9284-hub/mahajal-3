package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "village_needs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class VillageNeed {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id") private Village village;
    @Enumerated(EnumType.STRING) @Column(length = 30) private NeedType needType;
    @Column(length = 300) private String description;
    private long estimatedCostInr;
    @Enumerated(EnumType.STRING) @Column(length = 10) private Priority priority;
    @Builder.Default private boolean demoData = false;
}
