package com.mahajal.controller;

import com.mahajal.dto.ApiResponse;
import com.mahajal.dto.Dtos.*;
import com.mahajal.security.AppUserDetails;
import com.mahajal.service.AuthService;
import com.mahajal.service.Mappers;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth) { this.auth = auth; }

    @PostMapping("/register") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<AuthResponse> register(@Valid @RequestBody RegisterRequest r) {
        return ApiResponse.ok("Registration successful", auth.register(r));
    }

    @PostMapping("/login")
    public ApiResponse<AuthResponse> login(@Valid @RequestBody LoginRequest r) {
        return ApiResponse.ok("Login successful", auth.login(r));
    }

    @PostMapping("/forgot-password")
    public ApiResponse<ForgotResponse> forgot(@Valid @RequestBody ForgotRequest r) {
        ForgotResponse res = auth.forgotPassword(r);
        return ApiResponse.ok(res.message(), res);
    }

    @PostMapping("/reset-password")
    public ApiResponse<Void> reset(@Valid @RequestBody ResetRequest r) {
        auth.resetPassword(r);
        return ApiResponse.ok("Password updated. You can now log in.", null);
    }

    @GetMapping("/me")
    public ApiResponse<UserDto> me(@AuthenticationPrincipal AppUserDetails me) {
        return ApiResponse.ok(Mappers.user(me.getUser()));
    }
}
