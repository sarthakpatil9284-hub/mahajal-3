package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "rainfall_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RainfallRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id") private Village village;
    private LocalDate recordMonth;
    private double actualMm;
    private double normalMm;
}
