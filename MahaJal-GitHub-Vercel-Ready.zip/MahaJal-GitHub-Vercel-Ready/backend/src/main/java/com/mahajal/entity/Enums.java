package com.mahajal.entity;

public final class Enums {
    private Enums() {}
    public enum RoleName { FARMER, GOVERNMENT, NGO, CSR, CITIZEN }
    public enum RiskLevel { LOW, MODERATE, HIGH, CRITICAL }
    public enum ReportStatus { SUBMITTED, UNDER_REVIEW, VERIFIED, RESOLVED, REJECTED }
    public enum TankerStatus { REQUESTED, APPROVED, DISPATCHED, DELIVERED, REJECTED }
    public enum SosStatus { OPEN, ACKNOWLEDGED, RESOLVED }
    public enum SupportStatus { OFFERED, COMMITTED, ACCEPTED, DELIVERED }
    public enum WaterSourceType { WELL, BOREWELL, TANK, DAM, HANDPUMP, CANAL }
    public enum NeedType { DRINKING_WATER_TANKER, FODDER, IRRIGATION_SUPPORT, SEED_SUPPORT, RELIEF_KITS }
    public enum Priority { HIGH, MEDIUM, LOW }
}
