package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "ngo_support")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class NgoSupport {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "ngo_user_id") private User ngoUser;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id") private Village village;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "need_id") private VillageNeed need;
    @Column(length = 100) private String supportType;
    private long amountInr;
    @Column(length = 500) private String description;
    @Enumerated(EnumType.STRING) @Column(length = 20) @Builder.Default private SupportStatus status = SupportStatus.OFFERED;
    @Builder.Default private LocalDateTime createdAt = LocalDateTime.now();
    @Builder.Default private boolean demoData = false;
}
