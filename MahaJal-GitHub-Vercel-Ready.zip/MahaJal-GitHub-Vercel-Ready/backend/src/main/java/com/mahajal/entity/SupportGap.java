package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "support_gap")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SupportGap {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id", unique = true) private Village village;
    private long totalNeed;
    private long governmentSupport;
    private long ngoSupport;
    private long csrSupport;
    private long remainingGap;
    private LocalDateTime updatedAt;
    @Builder.Default private boolean demoData = false;
}
