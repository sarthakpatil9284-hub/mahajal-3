package com.mahajal.service;

import com.mahajal.dto.Dtos.NotificationDto;
import com.mahajal.entity.Enums.RoleName;
import com.mahajal.entity.Notification;
import com.mahajal.entity.User;
import com.mahajal.exception.ApiException;
import com.mahajal.repository.NotificationRepository;
import com.mahajal.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class NotificationService {
    private final NotificationRepository repo;
    private final UserRepository users;

    public NotificationService(NotificationRepository repo, UserRepository users) {
        this.repo = repo; this.users = users;
    }

    public void notify(User user, String title, String message, String type) {
        if (user == null) return;
        repo.save(Notification.builder().user(user).title(title).message(message).type(type).build());
    }

    public void notifyGovernment(String title, String message, String type) {
        users.findByRoleName(RoleName.GOVERNMENT).forEach(u -> notify(u, title, message, type));
    }

    @Transactional(readOnly = true)
    public List<NotificationDto> list(Long userId) {
        return repo.findByUserIdOrderByCreatedAtDesc(userId).stream().map(Mappers::notification).toList();
    }

    @Transactional(readOnly = true)
    public long unread(Long userId) { return repo.countByUserIdAndSeenFalse(userId); }

    public void markSeen(Long userId, Long id) {
        Notification n = repo.findByIdAndUserId(id, userId).orElseThrow(() -> ApiException.notFound("Notification not found"));
        n.setSeen(true);
        repo.save(n);
    }

    public void markAllSeen(Long userId) {
        List<Notification> list = repo.findByUserIdOrderByCreatedAtDesc(userId);
        list.forEach(n -> n.setSeen(true));
        repo.saveAll(list);
    }
}
