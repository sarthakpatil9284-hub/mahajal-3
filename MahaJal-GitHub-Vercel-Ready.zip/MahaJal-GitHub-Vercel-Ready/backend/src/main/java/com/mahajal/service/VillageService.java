package com.mahajal.service;

import com.mahajal.dto.Dtos.*;
import com.mahajal.entity.*;
import com.mahajal.entity.Enums.RiskLevel;
import com.mahajal.exception.ApiException;
import com.mahajal.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class VillageService {
    private static final DateTimeFormatter MONTH = DateTimeFormatter.ofPattern("MMM yy", Locale.ENGLISH);
    private final DistrictRepository districts;
    private final TalukaRepository talukas;
    private final VillageRepository villages;
    private final DroughtAssessmentRepository assessments;
    private final RainfallRecordRepository rainfall;
    private final GroundwaterRecordRepository groundwater;
    private final WaterSourceRepository waterSources;
    private final VillageNeedRepository needs;
    private final SupportGapRepository gaps;
    private final NgoSupportRepository ngo;
    private final CsrSupportRepository csr;
    private final DroughtScoring scoring;

    public VillageService(DistrictRepository districts, TalukaRepository talukas, VillageRepository villages,
                          DroughtAssessmentRepository assessments, RainfallRecordRepository rainfall,
                          GroundwaterRecordRepository groundwater, WaterSourceRepository waterSources,
                          VillageNeedRepository needs, SupportGapRepository gaps, NgoSupportRepository ngo,
                          CsrSupportRepository csr, DroughtScoring scoring) {
        this.districts = districts; this.talukas = talukas; this.villages = villages; this.assessments = assessments;
        this.rainfall = rainfall; this.groundwater = groundwater; this.waterSources = waterSources; this.needs = needs;
        this.gaps = gaps; this.ngo = ngo; this.csr = csr; this.scoring = scoring;
    }

    // ---------- location hierarchy ----------
    public List<LocationDto> districts() {
        return districts.findAllByOrderByNameAsc().stream().map(d -> new LocationDto(d.getId(), d.getName())).toList();
    }
    public List<LocationDto> talukas(Long districtId) {
        return talukas.findByDistrictIdOrderByNameAsc(districtId).stream().map(t -> new LocationDto(t.getId(), t.getName())).toList();
    }
    public List<LocationDto> villages(Long talukaId) {
        return villages.findByTalukaIdOrderByNameAsc(talukaId).stream().map(v -> new LocationDto(v.getId(), v.getName())).toList();
    }

    // ---------- map ----------
    public List<VillageMapDto> mapVillages(Long districtId) {
        List<DroughtAssessment> list = districtId == null ? assessments.findAll() : assessments.findByVillageTalukaDistrictId(districtId);
        return list.stream().map(Mappers::mapPoint).toList();
    }

    public List<DistrictMapDto> mapDistricts() {
        Map<Long, List<DroughtAssessment>> byDistrict = assessments.findAll().stream()
                .collect(Collectors.groupingBy(a -> a.getVillage().getTaluka().getDistrict().getId()));
        List<DistrictMapDto> out = new ArrayList<>();
        for (District d : districts.findAllByOrderByNameAsc()) {
            List<DroughtAssessment> list = byDistrict.getOrDefault(d.getId(), List.of());
            Double avg = list.isEmpty() ? null : Mappers.round1(list.stream().mapToDouble(DroughtAssessment::getRiskScore).average().orElse(0));
            out.add(new DistrictMapDto(d.getId(), d.getName(), d.getLatitude(), d.getLongitude(), avg,
                    avg == null ? null : scoring.level(avg).name(), list.size()));
        }
        return out;
    }

    // ---------- village dashboard ----------
    public VillageDashboardDto dashboard(Long id) {
        Village v = villages.findById(id).orElseThrow(() -> ApiException.notFound("Village not found"));
        DroughtAssessment a = assessments.findByVillageId(id)
                .orElseThrow(() -> ApiException.notFound("No drought assessment available for this village yet"));
        Optional<RainfallRecord> latest = rainfall.findTopByVillageIdOrderByRecordMonthDesc(id);
        List<SeriesPoint> rain = rainfall.findByVillageIdOrderByRecordMonthAsc(id).stream()
                .map(r -> new SeriesPoint(r.getRecordMonth().format(MONTH), r.getActualMm(), r.getNormalMm())).toList();
        List<SeriesPoint> gw = groundwater.findByVillageIdOrderByRecordMonthAsc(id).stream()
                .map(g -> new SeriesPoint(g.getRecordMonth().format(MONTH), g.getDepthM(), 0)).toList();
        SupportGapDto gap = gaps.findByVillageId(id).map(g -> new SupportGapDto(g.getTotalNeed(), g.getGovernmentSupport(),
                g.getNgoSupport(), g.getCsrSupport(), g.getRemainingGap(), g.isDemoData())).orElse(new SupportGapDto(0, 0, 0, 0, 0, true));
        Taluka t = v.getTaluka();
        return new VillageDashboardDto(v.getId(), v.getName(), t.getName(), t.getDistrict().getName(), t.getDistrict().getId(),
                v.getPopulation(), v.getFarmerCount(), v.isDemoData(),
                latest.map(RainfallRecord::getActualMm).orElse(null), latest.map(RainfallRecord::getNormalMm).orElse(null),
                a.getRainfallDeficitPct(), a.getGroundwaterDepthM(), a.getWaterAvailabilityPct(), a.getSoilMoisturePct(),
                a.getCropStressIndex(), a.getRiskScore(), a.getRiskLevel().name(), DroughtScoring.LABEL, a.getAssessedOn(),
                scoring.explain(a.getRainfallDeficitPct(), a.getGroundwaterDepthM(), a.getWaterAvailabilityPct(), a.getCropStressIndex()),
                rain, gw, waterSources.findByVillageId(id).stream().map(Mappers::water).toList(), gap,
                needs.findByVillageId(id).stream().map(Mappers::need).toList());
    }

    // ---------- tabular village rows (government / partner / reports) ----------
    public List<VillageRow> villageRows(Long districtId) {
        List<DroughtAssessment> list = districtId == null ? assessments.findAll() : assessments.findByVillageTalukaDistrictId(districtId);
        return list.stream().map(a -> {
            Village v = a.getVillage();
            SupportGap g = gaps.findByVillageId(v.getId()).orElse(null);
            return new VillageRow(v.getId(), v.getName(), v.getTaluka().getName(), v.getTaluka().getDistrict().getName(),
                    v.getPopulation(), v.getFarmerCount(), a.getRainfallDeficitPct(), a.getGroundwaterDepthM(),
                    a.getWaterAvailabilityPct(), a.getCropStressIndex(), a.getRiskScore(), a.getRiskLevel().name(),
                    g == null ? 0 : g.getTotalNeed(), g == null ? 0 : g.getGovernmentSupport(), g == null ? 0 : g.getNgoSupport(),
                    g == null ? 0 : g.getCsrSupport(), g == null ? 0 : g.getRemainingGap());
        }).sorted(Comparator.comparingDouble(VillageRow::riskScore).reversed()).toList();
    }

    public List<NeedDto> needsOf(Long villageId) {
        return needs.findByVillageId(villageId).stream().map(Mappers::need).toList();
    }

    // ---------- rainfall / water ----------
    public RainfallSummaryDto rainfallSummary(Long districtId) {
        List<Object[]> rows = districtId == null ? rainfall.seriesAll() : rainfall.seriesByDistrict(districtId);
        List<SeriesPoint> series = rows.stream().map(o -> new SeriesPoint(((java.time.LocalDate) o[0]).format(MONTH),
                Mappers.round1(((Number) o[1]).doubleValue()), Mappers.round1(((Number) o[2]).doubleValue()))).toList();
        List<DroughtAssessment> list = districtId == null ? assessments.findAll() : assessments.findByVillageTalukaDistrictId(districtId);
        List<VillageRainfallRow> villageRows = list.stream().map(a -> {
            Village v = a.getVillage();
            Optional<RainfallRecord> r = rainfall.findTopByVillageIdOrderByRecordMonthDesc(v.getId());
            return new VillageRainfallRow(v.getId(), v.getName(), v.getTaluka().getName(), v.getTaluka().getDistrict().getName(),
                    r.map(RainfallRecord::getActualMm).orElse(0.0), r.map(RainfallRecord::getNormalMm).orElse(0.0),
                    a.getRainfallDeficitPct(), a.getRiskLevel().name());
        }).sorted(Comparator.comparingDouble(VillageRainfallRow::deficitPct).reversed()).toList();
        return new RainfallSummaryDto(series, villageRows);
    }

    public WaterSummaryDto waterSummary(Long districtId) {
        List<WaterSource> sources = districtId == null ? waterSources.findAll() : waterSources.findByVillageTalukaDistrictId(districtId);
        List<DroughtAssessment> list = districtId == null ? assessments.findAll() : assessments.findByVillageTalukaDistrictId(districtId);
        List<GroundwaterRow> gw = list.stream().map(a -> new GroundwaterRow(a.getVillage().getId(), a.getVillage().getName(),
                a.getVillage().getTaluka().getDistrict().getName(), a.getGroundwaterDepthM()))
                .sorted(Comparator.comparingDouble(GroundwaterRow::depthM).reversed()).toList();
        return new WaterSummaryDto(sources.stream().map(Mappers::water).toList(), gw);
    }

    // ---------- support gap: Total Need - Government - NGO - CSR = Remaining Gap ----------
    @Transactional
    public SupportGap recalcGap(Village v) {
        SupportGap g = gaps.findByVillageId(v.getId()).orElseGet(() -> SupportGap.builder().village(v).build());
        long total = needs.findByVillageId(v.getId()).stream().mapToLong(VillageNeed::getEstimatedCostInr).sum();
        long n = ngo.findByVillageId(v.getId()).stream().mapToLong(NgoSupport::getAmountInr).sum();
        long c = csr.findByVillageId(v.getId()).stream().mapToLong(CsrSupport::getAmountInr).sum();
        g.setTotalNeed(total);
        g.setNgoSupport(n);
        g.setCsrSupport(c);
        g.setRemainingGap(Math.max(0, total - g.getGovernmentSupport() - n - c));
        g.setUpdatedAt(LocalDateTime.now());
        return gaps.save(g);
    }
}
