package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "villages")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Village {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, length = 80) private String name;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "taluka_id") private Taluka taluka;
    private double latitude;
    private double longitude;
    private int population;
    private int farmerCount;
    @Builder.Default private boolean demoData = false;
}
