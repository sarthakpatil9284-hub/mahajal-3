package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "drought_assessments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class DroughtAssessment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id", unique = true) private Village village;
    private LocalDate assessedOn;
    private double rainfallDeficitPct;
    private double groundwaterDepthM;
    private double waterAvailabilityPct;
    private double soilMoisturePct;
    private double cropStressIndex;
    private double riskScore;
    @Enumerated(EnumType.STRING) @Column(length = 20) private RiskLevel riskLevel;
    @Builder.Default private boolean demoData = false;
}
