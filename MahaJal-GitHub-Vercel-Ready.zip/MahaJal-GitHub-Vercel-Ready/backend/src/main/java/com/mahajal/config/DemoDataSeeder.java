package com.mahajal.config;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import com.mahajal.repository.*;
import com.mahajal.service.DroughtService;
import com.mahajal.service.VillageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;

/**
 * Seeds roles (always) and DEMO data (when mahajal.seed-demo=true and the database is empty).
 * ALL seeded villages, farmers, rainfall, groundwater, scores, needs and support amounts are
 * synthetic demo data generated for this project. They are NOT official government data.
 */
@Component
public class DemoDataSeeder implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DemoDataSeeder.class);
    public static final String DEMO_PASSWORD = "Demo@12345";

    /** Name|lat|lng[|dryness 0..1|Taluka:Village,Village;Taluka:Village,Village] */
    private static final String[] DISTRICTS = {
        "Solapur|17.66|75.91|0.85|Barshi:Vairag,Pangri;Pandharpur:Karkamb,Tungat",
        "Beed|18.99|75.76|0.90|Georai:Rajapur,Takalsinga;Ashti:Dhamangaon,Kada",
        "Latur|18.40|76.58|0.80|Ausa:Lamjana,Killari;Nilanga:Hadga,Kasar Shirshi",
        "Dharashiv|18.18|76.04|0.85|Tuljapur:Sindphal,Kati;Paranda:Anala,Sonari",
        "Jalna|19.84|75.88|0.80|Ambad:Rohilagad,Shahagad;Bhokardan:Anvi,Pimpalgaon Renukai",
        "Chhatrapati Sambhajinagar|19.88|75.34|0.70|Paithan:Pachod,Bidkin;Gangapur:Waluj,Lasur",
        "Nashik|19.99|73.79|0.50|Sinnar:Nandur Shingote,Pangri Sinnar;Malegaon:Zodge,Dabhadi",
        "Pune|18.52|73.86|0.30|Baramati:Supa,Morgaon;Indapur:Bhigwan,Nimgaon Ketki",
        "Ahilyanagar|19.09|74.74|0.65|Parner:Alkuti,Pimpalgaon Roth;Karjat:Rashin,Mirajgaon",
        "Satara|17.68|74.00|0.55|Man:Dahiwadi,Mhaswad;Khatav:Vaduj,Pusegaon",
        "Sangli|16.85|74.58|0.60|Jat:Umadi,Dafalapur;Atpadi:Nimbavade,Kharsundi",
        "Kolhapur|16.70|74.24|0.20|Karveer:Kalamba,Shiye;Shirol:Jaysingpur,Nrusinhwadi",
        "Nagpur|21.15|79.09|0.40|Katol:Kondhali,Metpanjra;Ramtek:Mansar,Navegaon",
        "Yavatmal|20.39|78.13|0.60|Ner:Pahur,Sawargaon;Darwha:Lohara,Tiwsa",
        "Buldhana|20.53|76.18|0.70|Khamgaon:Pimpalgaon Raja,Lakhanwada;Chikhli:Deulgaon Ghat,Amdapur",
        "Akola|20.71|77.00|0.65|Balapur:Paras,Ural;Telhara:Hiwarkhed,Adsul",
        "Mumbai City|18.97|72.83", "Mumbai Suburban|19.12|72.87", "Thane|19.22|72.98", "Palghar|19.70|72.77",
        "Raigad|18.52|73.18", "Ratnagiri|16.99|73.30", "Sindhudurg|16.35|73.75", "Dhule|20.90|74.78",
        "Nandurbar|21.37|74.24", "Jalgaon|21.00|75.56", "Chandrapur|19.96|79.30", "Gadchiroli|20.18|80.00",
        "Gondia|21.46|80.19", "Bhandara|21.17|79.65", "Wardha|20.75|78.60", "Amravati|20.93|77.75",
        "Washim|20.11|77.13", "Hingoli|19.72|77.15", "Parbhani|19.27|76.77", "Nanded|19.16|77.32"
    };
    private static final double[] NORMALS = {3, 3, 5, 12, 25, 150, 200, 180, 150, 80, 20, 5};
    private static final String[] FIRST = {"Ramesh", "Suresh", "Ganesh", "Dattatray", "Sachin", "Vijay", "Sunita", "Anita", "Sandeep", "Prakash", "Bhimrao", "Shivaji", "Meena", "Kavita", "Ashok", "Santosh"};
    private static final String[] LAST = {"Patil", "Jadhav", "Shinde", "Pawar", "More", "Kale", "Gaikwad", "Deshmukh", "Chavan", "Kulkarni", "Bhosale", "Salunkhe"};
    private static final String[] CROPS = {"Jowar", "Cotton", "Soybean", "Tur (Pigeon pea)", "Sugarcane", "Onion", "Gram (Chickpea)", "Bajra", "Wheat", "Pomegranate"};
    private static final String[] STAGES = {"SOWING", "VEGETATIVE", "FLOWERING", "GRAIN_FILLING"};
    private static final String[] SOILS = {"BLACK", "RED", "LOAMY", "SANDY", "ALLUVIAL"};
    private static final String[] IRRIG = {"RAINFED", "DRIP", "BOREWELL", "CANAL"};
    private static final String[] NGO_TYPES = {"Water tanker sponsorship", "Fodder camp", "Drip irrigation kits", "Relief kits", "Farm pond digging"};
    private static final String[] CSR_PROGRAMS = {"CSR Jal Sanvardhan", "CSR Fodder Bank", "CSR Farm Pond Programme", "CSR Village Water Tanks"};

    private final boolean seed;
    private final RoleRepository roles;
    private final UserRepository users;
    private final DistrictRepository districts;
    private final TalukaRepository talukas;
    private final VillageRepository villages;
    private final FarmerRepository farmers;
    private final CropRepository crops;
    private final RainfallRecordRepository rainfall;
    private final GroundwaterRecordRepository groundwater;
    private final WaterSourceRepository waterSources;
    private final CropDamageReportRepository damage;
    private final TankerRequestRepository tankers;
    private final SosReportRepository sos;
    private final VillageNeedRepository needs;
    private final SupportGapRepository gaps;
    private final NgoSupportRepository ngo;
    private final CsrSupportRepository csr;
    private final NotificationRepository notifications;
    private final DroughtService drought;
    private final VillageService villageService;
    private final PasswordEncoder encoder;

    public DemoDataSeeder(@Value("${mahajal.seed-demo}") boolean seed, RoleRepository roles, UserRepository users,
                          DistrictRepository districts, TalukaRepository talukas, VillageRepository villages,
                          FarmerRepository farmers, CropRepository crops, RainfallRecordRepository rainfall,
                          GroundwaterRecordRepository groundwater, WaterSourceRepository waterSources,
                          CropDamageReportRepository damage, TankerRequestRepository tankers, SosReportRepository sos,
                          VillageNeedRepository needs, SupportGapRepository gaps, NgoSupportRepository ngo,
                          CsrSupportRepository csr, NotificationRepository notifications, DroughtService drought,
                          VillageService villageService, PasswordEncoder encoder) {
        this.seed = seed; this.roles = roles; this.users = users; this.districts = districts; this.talukas = talukas;
        this.villages = villages; this.farmers = farmers; this.crops = crops; this.rainfall = rainfall;
        this.groundwater = groundwater; this.waterSources = waterSources; this.damage = damage; this.tankers = tankers;
        this.sos = sos; this.needs = needs; this.gaps = gaps; this.ngo = ngo; this.csr = csr;
        this.notifications = notifications; this.drought = drought; this.villageService = villageService; this.encoder = encoder;
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static double r1(double v) { return Math.round(v * 10.0) / 10.0; }
    private static <T> T pick(Random r, T[] a) { return a[r.nextInt(a.length)]; }

    @Override
    @Transactional
    public void run(String... args) {
        for (RoleName n : RoleName.values()) {
            if (roles.findByName(n).isEmpty()) roles.save(Role.builder().name(n).build());
        }
        if (!seed || districts.count() > 0) return;
        log.info("Seeding MahaJal DEMO data (synthetic, not official)...");
        Random rnd = new Random(42);

        User gov = user("Demo Government Officer", "gov@mahajal.demo", RoleName.GOVERNMENT, "Government of Maharashtra (Demo)", "9000000001");
        User farmerUser = user("Ramesh Patil (Demo Farmer)", "farmer@mahajal.demo", RoleName.FARMER, null, "9000000002");
        User ngo1 = user("Demo NGO Coordinator", "ngo@mahajal.demo", RoleName.NGO, "Jal Seva Foundation (Demo NGO)", "9000000003");
        User csr1 = user("Demo CSR Manager", "csr@mahajal.demo", RoleName.CSR, "Demo Infra Ltd CSR (Demo)", "9000000004");
        user("Demo Citizen", "citizen@mahajal.demo", RoleName.CITIZEN, null, "9000000005");
        User ngo2 = user("Second Demo NGO", "ngo2@mahajal.demo", RoleName.NGO, "Gram Vikas Trust (Demo NGO)", "9000000006");
        User csr2 = user("Second Demo CSR", "csr2@mahajal.demo", RoleName.CSR, "Demo Energy Corp CSR (Demo)", "9000000007");
        List<User> ngoUsers = List.of(ngo1, ngo2), csrUsers = List.of(csr1, csr2);

        boolean firstFarmerDone = false;
        for (String row : DISTRICTS) {
            String[] p = row.split("\\|");
            District d = districts.save(District.builder().name(p[0]).latitude(Double.parseDouble(p[1])).longitude(Double.parseDouble(p[2])).build());
            if (p.length < 5) continue;
            double dry = Double.parseDouble(p[3]);
            for (String tv : p[4].split(";")) {
                String[] t = tv.split(":");
                Taluka taluka = talukas.save(Taluka.builder().name(t[0]).district(d).build());
                for (String vn : t[1].split(",")) {
                    double dv = clamp(dry + (rnd.nextDouble() - 0.5) * 0.2, 0.05, 0.98);
                    int pop = 800 + rnd.nextInt(4200);
                    Village v = villages.save(Village.builder().name(vn).taluka(taluka)
                            .latitude(r1((d.getLatitude() + (rnd.nextDouble() - 0.5) * 0.5) * 1000) / 1000)
                            .longitude(r1((d.getLongitude() + (rnd.nextDouble() - 0.5) * 0.5) * 1000) / 1000)
                            .population(pop).farmerCount((int) (pop * 0.28)).demoData(true).build());
                    seedClimate(v, dv, rnd);
                    seedPeople(v, dv, rnd, !firstFarmerDone ? farmerUser : null);
                    firstFarmerDone = true;
                    seedNeedsAndSupport(v, dv, rnd, ngoUsers, csrUsers);
                }
            }
        }
        // demo notifications
        note(farmerUser, "Welcome to MahaJal (demo)", "This account uses synthetic demo data. Explore your crops and advisory.", "INFO");
        note(farmerUser, "Dry spell alert (demo)", "Rainfall in your village is below the demo seasonal normal. Check your crop advisory.", "ALERT");
        note(farmerUser, "Tanker request approved (demo)", "Your demo tanker request has been approved by the taluka office.", "SUCCESS");
        note(gov, "Welcome, Government Officer (demo)", "Review critical villages, SOS alerts and tanker requests from the dashboard.", "INFO");
        note(ngo1, "Welcome, NGO partner (demo)", "Browse village needs and offer support to reduce the remaining gap.", "INFO");
        note(csr1, "Welcome, CSR partner (demo)", "Record support commitments against village needs.", "INFO");
        log.info("Demo data ready. Demo password for all demo accounts: {}", DEMO_PASSWORD);
    }

    private User user(String name, String email, RoleName role, String org, String phone) {
        return users.save(User.builder().fullName(name).email(email).passwordHash(encoder.encode(DEMO_PASSWORD))
                .organization(org).phone(phone).role(roles.findByName(role).orElseThrow()).build());
    }

    private void note(User u, String title, String msg, String type) {
        notifications.save(Notification.builder().user(u).title(title).message(msg).type(type).build());
    }

    private void seedClimate(Village v, double dv, Random rnd) {
        YearMonth now = YearMonth.now();
        double gwBase = 6 + dv * 26 + (rnd.nextDouble() - 0.5) * 4;
        for (int i = 5; i >= 0; i--) {
            YearMonth ym = now.minusMonths(i);
            double normal = NORMALS[ym.getMonthValue() - 1];
            double actual = Math.max(0, normal * (1.05 - dv * 0.75 + (rnd.nextDouble() - 0.5) * 0.2));
            rainfall.save(RainfallRecord.builder().village(v).recordMonth(ym.atDay(1)).actualMm(r1(actual)).normalMm(normal).build());
            groundwater.save(GroundwaterRecord.builder().village(v).recordMonth(ym.atDay(1)).depthM(r1(gwBase + (5 - i) * 0.35 * dv)).build());
        }
        WaterSourceType[] types = WaterSourceType.values();
        for (int k = 1; k <= 3; k++) {
            WaterSourceType t = pick(rnd, types);
            double st = clamp(88 - dv * 72 + (rnd.nextDouble() - 0.5) * 20, 3, 98);
            waterSources.save(WaterSource.builder().village(v).name(v.getName() + " " + t.name().charAt(0) + t.name().substring(1).toLowerCase() + " " + k)
                    .type(t).storagePct(r1(st)).functional(st > 10).build());
        }
        double soil = clamp(62 - dv * 48 + (rnd.nextDouble() - 0.5) * 10, 8, 85);
        drought.assess(v, soil, true);
    }

    private void seedPeople(Village v, double dv, Random rnd, User farmerAccount) {
        List<Farmer> list = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            boolean account = i == 0 && farmerAccount != null;
            String name = account ? "Ramesh Patil" : pick(rnd, FIRST) + " " + pick(rnd, LAST);
            Farmer f = farmers.save(Farmer.builder().user(account ? farmerAccount : null).fullName(name)
                    .phone("98" + (10000000 + rnd.nextInt(89999999))).landAcres(r1(1 + rnd.nextDouble() * 9)).village(v).demoData(true).build());
            list.add(f);
            if (account) {
                crop(f, "Cotton", "KHARIF", "FLOWERING", 2.5, "BLACK", "RAINFED");
                crop(f, "Jowar", "RABI", "VEGETATIVE", 1.5, "BLACK", "RAINFED");
                crop(f, "Tur (Pigeon pea)", "KHARIF", "GRAIN_FILLING", 1.0, "RED", "RAINFED");
            } else {
                int n = 1 + rnd.nextInt(2);
                for (int c = 0; c < n; c++) {
                    String cn = pick(rnd, CROPS);
                    crop(f, cn, cn.equals("Wheat") || cn.startsWith("Gram") ? "RABI" : "KHARIF", pick(rnd, STAGES),
                            r1(0.5 + rnd.nextDouble() * 4), pick(rnd, SOILS), pick(rnd, IRRIG));
                }
            }
        }
        Farmer first = list.get(0);
        if (farmerAccount != null) {
            damage.save(CropDamageReport.builder().farmer(first).crop(crops.findByFarmerIdOrderByIdDesc(first.getId()).get(0)).village(v)
                    .cause("DROUGHT / DRY SPELL").damagePercent(45).areaAffectedAcres(1.2).description("Demo report: leaves wilting after long dry spell.")
                    .status(ReportStatus.UNDER_REVIEW).demoData(true).build());
            tankers.save(TankerRequest.builder().farmer(first).village(v).peopleCount(6).livestockCount(4).litersRequired(5000)
                    .urgency("URGENT").remarks("Demo request: village well dried up.").status(TankerStatus.APPROVED).build());
            return;
        }
        if (dv > 0.6 && rnd.nextDouble() < 0.6) {
            damage.save(CropDamageReport.builder().farmer(first).village(v)
                    .cause(pick(rnd, new String[]{"DROUGHT / DRY SPELL", "LOW SOIL MOISTURE", "PEST ATTACK", "HAIL"}))
                    .damagePercent(20 + rnd.nextInt(60)).areaAffectedAcres(r1(0.5 + rnd.nextDouble() * 3))
                    .description("Demo damage report (synthetic).").status(pick(rnd, new ReportStatus[]{ReportStatus.SUBMITTED, ReportStatus.UNDER_REVIEW, ReportStatus.VERIFIED}))
                    .demoData(true).build());
        }
        if (dv > 0.75 && rnd.nextDouble() < 0.5) {
            tankers.save(TankerRequest.builder().farmer(first).village(v).peopleCount(3 + rnd.nextInt(10)).livestockCount(rnd.nextInt(10))
                    .litersRequired(2000 + rnd.nextInt(8) * 1000).urgency(rnd.nextBoolean() ? "URGENT" : "NORMAL")
                    .remarks("Demo request (synthetic).").status(pick(rnd, TankerStatus.values())).build());
        }
        if (dv > 0.85 && rnd.nextDouble() < 0.4) {
            sos.save(SosReport.builder().farmer(first).village(v).category(pick(rnd, new String[]{"WATER", "FODDER", "HEALTH"}))
                    .message("Demo SOS (synthetic): urgent help needed.").status(pick(rnd, SosStatus.values())).build());
        }
    }

    private void crop(Farmer f, String name, String season, String stage, double area, String soil, String irrigation) {
        crops.save(Crop.builder().farmer(f).cropName(name).season(season).stage(stage).areaAcres(area)
                .sowingDate(LocalDate.now().minusDays(40 + Math.abs(name.hashCode() % 50))).soilType(soil).irrigationType(irrigation).demoData(true).build());
    }

    private void seedNeedsAndSupport(Village v, double dv, Random rnd, List<User> ngoUsers, List<User> csrUsers) {
        if (dv <= 0.35) { villageService.recalcGap(v); return; }
        List<VillageNeed> list = new ArrayList<>();
        list.add(need(v, NeedType.DRINKING_WATER_TANKER, "Water tankers for drinking water", round(v.getPopulation() * dv * 400.0), dv));
        list.add(need(v, NeedType.FODDER, "Fodder for livestock", round(v.getFarmerCount() * dv * 900.0), dv));
        list.add(need(v, NeedType.IRRIGATION_SUPPORT, "Protective irrigation / drip kits", round(v.getPopulation() * dv * 150.0), dv));
        if (dv > 0.6) list.add(need(v, NeedType.SEED_SUPPORT, "Seed support for re-sowing", round(v.getFarmerCount() * dv * 400.0), dv));
        long total = list.stream().mapToLong(VillageNeed::getEstimatedCostInr).sum();
        gaps.save(SupportGap.builder().village(v).governmentSupport(round(total * (0.25 + 0.30 * rnd.nextDouble()))).demoData(true).build());
        if (rnd.nextDouble() < 0.45) {
            ngo.save(NgoSupport.builder().ngoUser(pick(rnd, ngoUsers.toArray(new User[0]))).village(v).need(list.get(0)).supportType(pick(rnd, NGO_TYPES))
                    .amountInr(round(total * (0.05 + 0.15 * rnd.nextDouble()))).description("Demo support entry (synthetic)")
                    .status(SupportStatus.ACCEPTED).demoData(true).build());
        }
        if (rnd.nextDouble() < 0.35) {
            csr.save(CsrSupport.builder().csrUser(pick(rnd, csrUsers.toArray(new User[0]))).village(v).need(list.get(1)).programName(pick(rnd, CSR_PROGRAMS))
                    .amountInr(round(total * (0.05 + 0.15 * rnd.nextDouble()))).description("Demo commitment (synthetic)")
                    .status(SupportStatus.COMMITTED).demoData(true).build());
        }
        villageService.recalcGap(v);
    }

    private VillageNeed need(Village v, NeedType type, String desc, long cost, double dv) {
        return needs.save(VillageNeed.builder().village(v).needType(type).description(desc).estimatedCostInr(cost)
                .priority(dv > 0.75 ? Priority.HIGH : dv > 0.55 ? Priority.MEDIUM : Priority.LOW).demoData(true).build());
    }

    private static long round(double v) { return Math.round(v / 1000.0) * 1000L; }
}
