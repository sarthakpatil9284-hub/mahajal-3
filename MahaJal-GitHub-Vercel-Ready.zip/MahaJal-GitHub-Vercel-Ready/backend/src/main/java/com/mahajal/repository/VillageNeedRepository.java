package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface VillageNeedRepository extends JpaRepository<VillageNeed, Long> {
    List<VillageNeed> findByVillageId(Long villageId);
}
