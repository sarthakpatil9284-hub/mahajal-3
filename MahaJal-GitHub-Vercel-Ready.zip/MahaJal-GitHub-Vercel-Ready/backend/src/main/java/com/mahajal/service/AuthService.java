package com.mahajal.service;

import com.mahajal.dto.Dtos.*;
import com.mahajal.entity.*;
import com.mahajal.entity.Enums.RoleName;
import com.mahajal.exception.ApiException;
import com.mahajal.repository.*;
import com.mahajal.security.JwtService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@Transactional
public class AuthService {
    private final UserRepository users;
    private final RoleRepository roles;
    private final VillageRepository villages;
    private final FarmerRepository farmers;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final boolean demoResetToken;

    public AuthService(UserRepository users, RoleRepository roles, VillageRepository villages, FarmerRepository farmers,
                       PasswordEncoder encoder, JwtService jwt,
                       @Value("${mahajal.demo-reset-token-in-response}") boolean demoResetToken) {
        this.users = users; this.roles = roles; this.villages = villages; this.farmers = farmers;
        this.encoder = encoder; this.jwt = jwt; this.demoResetToken = demoResetToken;
    }

    public AuthResponse register(RegisterRequest r) {
        if (r.role() == RoleName.GOVERNMENT) {
            throw ApiException.forbidden("Government accounts cannot be self-registered. They are created by an existing government administrator.");
        }
        String email = r.email().trim().toLowerCase();
        if (users.existsByEmail(email)) throw ApiException.conflict("An account with this email already exists");
        if ((r.role() == RoleName.NGO || r.role() == RoleName.CSR) && (r.organization() == null || r.organization().isBlank())) {
            throw ApiException.badRequest("Organization name is required for NGO and CSR accounts");
        }
        Village village = null;
        if (r.role() == RoleName.FARMER) {
            if (r.villageId() == null) throw ApiException.badRequest("Please select your district, taluka and village");
            village = villages.findById(r.villageId()).orElseThrow(() -> ApiException.badRequest("Selected village does not exist"));
        }
        Role role = roles.findByName(r.role()).orElseThrow(() -> ApiException.badRequest("Unknown role"));
        User user = users.save(User.builder().fullName(r.fullName().trim()).email(email)
                .passwordHash(encoder.encode(r.password())).phone(blankToNull(r.phone()))
                .organization(blankToNull(r.organization())).role(role).build());
        if (village != null) {
            farmers.save(Farmer.builder().user(user).fullName(user.getFullName()).phone(user.getPhone()).village(village).build());
        }
        return new AuthResponse(jwt.generate(user), Mappers.user(user));
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest r) {
        User u = users.findByEmail(r.email().trim().toLowerCase()).orElse(null);
        if (u == null || !u.isEnabled() || !encoder.matches(r.password(), u.getPasswordHash())) {
            throw ApiException.unauthorized("Invalid email or password");
        }
        return new AuthResponse(jwt.generate(u), Mappers.user(u));
    }

    public ForgotResponse forgotPassword(ForgotRequest r) {
        String msg = "If an account exists for this email, a password reset link has been generated.";
        User u = users.findByEmail(r.email().trim().toLowerCase()).orElse(null);
        if (u == null) return new ForgotResponse(msg, null);
        u.setResetToken(UUID.randomUUID().toString());
        u.setResetTokenExpiry(LocalDateTime.now().plusMinutes(30));
        users.save(u);
        // No e-mail service is configured in this demo; the token is returned only when demo mode is enabled.
        return new ForgotResponse(msg, demoResetToken ? u.getResetToken() : null);
    }

    public void resetPassword(ResetRequest r) {
        User u = users.findByResetToken(r.token()).orElseThrow(() -> ApiException.badRequest("Invalid or expired reset token"));
        if (u.getResetTokenExpiry() == null || u.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
            throw ApiException.badRequest("Invalid or expired reset token");
        }
        u.setPasswordHash(encoder.encode(r.newPassword()));
        u.setResetToken(null);
        u.setResetTokenExpiry(null);
        users.save(u);
    }

    public UserDto createGovernmentUser(GovUserRequest r) {
        String email = r.email().trim().toLowerCase();
        if (users.existsByEmail(email)) throw ApiException.conflict("An account with this email already exists");
        Role role = roles.findByName(RoleName.GOVERNMENT).orElseThrow();
        User u = users.save(User.builder().fullName(r.fullName().trim()).email(email).passwordHash(encoder.encode(r.password()))
                .phone(blankToNull(r.phone())).organization("Government of Maharashtra (Demo)").role(role).build());
        return Mappers.user(u);
    }

    private static String blankToNull(String s) { return s == null || s.isBlank() ? null : s.trim(); }
}
