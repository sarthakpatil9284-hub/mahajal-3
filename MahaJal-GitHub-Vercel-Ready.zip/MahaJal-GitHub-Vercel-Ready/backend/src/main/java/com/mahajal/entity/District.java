package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "districts")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class District {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, unique = true, length = 80) private String name;
    @Builder.Default private String state = "Maharashtra";
    private double latitude;
    private double longitude;
}
