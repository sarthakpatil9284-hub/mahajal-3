package com.mahajal.controller;

import com.mahajal.dto.ApiResponse;
import com.mahajal.dto.Dtos.*;
import com.mahajal.service.AuthService;
import com.mahajal.service.GovService;
import com.mahajal.service.VillageService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/gov")
public class GovController {
    private final GovService gov;
    private final VillageService villages;
    private final AuthService auth;

    public GovController(GovService gov, VillageService villages, AuthService auth) {
        this.gov = gov; this.villages = villages; this.auth = auth;
    }

    @GetMapping("/dashboard") public ApiResponse<GovDashboardDto> dashboard() { return ApiResponse.ok(gov.dashboard()); }
    @GetMapping("/districts") public ApiResponse<List<DistrictRow>> districts() { return ApiResponse.ok(gov.districtRows()); }
    @GetMapping("/villages")
    public ApiResponse<List<VillageRow>> villages(@RequestParam(required = false) Long districtId) { return ApiResponse.ok(villages.villageRows(districtId)); }
    @GetMapping("/farmers") public ApiResponse<List<FarmerRow>> farmers() { return ApiResponse.ok(gov.farmerRows()); }

    @GetMapping("/damage-reports") public ApiResponse<List<DamageDto>> damage() { return ApiResponse.ok(gov.damageReports()); }
    @PatchMapping("/damage-reports/{id}/status")
    public ApiResponse<DamageDto> updateDamage(@PathVariable Long id, @Valid @RequestBody StatusUpdate u) { return ApiResponse.ok("Status updated", gov.updateDamage(id, u)); }

    @GetMapping("/sos") public ApiResponse<List<SosDto>> sos() { return ApiResponse.ok(gov.sosReports()); }
    @PatchMapping("/sos/{id}/status")
    public ApiResponse<SosDto> updateSos(@PathVariable Long id, @Valid @RequestBody StatusUpdate u) { return ApiResponse.ok("Status updated", gov.updateSos(id, u)); }

    @GetMapping("/tanker-requests") public ApiResponse<List<TankerDto>> tankers() { return ApiResponse.ok(gov.tankerRequests()); }
    @PatchMapping("/tanker-requests/{id}/status")
    public ApiResponse<TankerDto> updateTanker(@PathVariable Long id, @Valid @RequestBody StatusUpdate u) { return ApiResponse.ok("Status updated", gov.updateTanker(id, u)); }

    @GetMapping("/analytics") public ApiResponse<AnalyticsDto> analytics() { return ApiResponse.ok(gov.analytics()); }

    @PostMapping("/observations") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<String> observation(@Valid @RequestBody ObservationRequest r) { String m = gov.addObservation(r); return ApiResponse.ok(m, m); }

    @PostMapping("/recalculate")
    public ApiResponse<Integer> recalc() { int n = gov.recalculateAll(); return ApiResponse.ok("Re-assessed " + n + " villages", n); }

    @PostMapping("/users") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<UserDto> createGovUser(@Valid @RequestBody GovUserRequest r) { return ApiResponse.ok("Government account created", auth.createGovernmentUser(r)); }
}
