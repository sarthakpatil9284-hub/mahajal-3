package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, length = 100) private String fullName;
    @Column(nullable = false, unique = true, length = 150) private String email;
    @Column(nullable = false) private String passwordHash;
    @Column(length = 15) private String phone;
    @Column(length = 120) private String organization;
    @ManyToOne(fetch = FetchType.EAGER, optional = false) @JoinColumn(name = "role_id") private Role role;
    @Builder.Default private boolean enabled = true;
    private String resetToken;
    private LocalDateTime resetTokenExpiry;
    @Builder.Default private LocalDateTime createdAt = LocalDateTime.now();
}
