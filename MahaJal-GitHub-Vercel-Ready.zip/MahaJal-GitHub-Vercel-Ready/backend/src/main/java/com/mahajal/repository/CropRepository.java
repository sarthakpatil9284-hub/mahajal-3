package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface CropRepository extends JpaRepository<Crop, Long> {
    List<Crop> findByFarmerIdOrderByIdDesc(Long farmerId);
    Optional<Crop> findByIdAndFarmerId(Long id, Long farmerId);
    long countByFarmerId(Long farmerId);
}
