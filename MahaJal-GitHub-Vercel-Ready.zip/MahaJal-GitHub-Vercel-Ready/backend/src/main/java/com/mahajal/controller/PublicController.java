package com.mahajal.controller;

import com.mahajal.dto.ApiResponse;
import com.mahajal.dto.Dtos.*;
import com.mahajal.service.AdvisoryService;
import com.mahajal.service.VillageService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Public (no login) read-only endpoints: locations, map, village dashboard, rainfall, water, advisory. */
@RestController
@RequestMapping("/api")
public class PublicController {
    private final VillageService villages;
    private final AdvisoryService advisory;

    public PublicController(VillageService villages, AdvisoryService advisory) {
        this.villages = villages; this.advisory = advisory;
    }

    @GetMapping("/locations/districts")
    public ApiResponse<List<LocationDto>> districts() { return ApiResponse.ok(villages.districts()); }

    @GetMapping("/locations/districts/{id}/talukas")
    public ApiResponse<List<LocationDto>> talukas(@PathVariable Long id) { return ApiResponse.ok(villages.talukas(id)); }

    @GetMapping("/locations/talukas/{id}/villages")
    public ApiResponse<List<LocationDto>> villages(@PathVariable Long id) { return ApiResponse.ok(villages.villages(id)); }

    @GetMapping("/map/villages")
    public ApiResponse<List<VillageMapDto>> mapVillages(@RequestParam(required = false) Long districtId) {
        return ApiResponse.ok(villages.mapVillages(districtId));
    }

    @GetMapping("/map/districts")
    public ApiResponse<List<DistrictMapDto>> mapDistricts() { return ApiResponse.ok(villages.mapDistricts()); }

    @GetMapping("/villages/{id}/dashboard")
    public ApiResponse<VillageDashboardDto> dashboard(@PathVariable Long id) { return ApiResponse.ok(villages.dashboard(id)); }

    @GetMapping("/rainfall")
    public ApiResponse<RainfallSummaryDto> rainfall(@RequestParam(required = false) Long districtId) {
        return ApiResponse.ok(villages.rainfallSummary(districtId));
    }

    @GetMapping("/water")
    public ApiResponse<WaterSummaryDto> water(@RequestParam(required = false) Long districtId) {
        return ApiResponse.ok(villages.waterSummary(districtId));
    }

    @GetMapping("/advisory/options")
    public ApiResponse<AdvisoryOptions> options() { return ApiResponse.ok(advisory.options()); }

    @PostMapping("/advisory")
    public ApiResponse<AdvisoryResult> advisory(@Valid @RequestBody AdvisoryRequest r) {
        return ApiResponse.ok(advisory.generate(r));
    }
}
