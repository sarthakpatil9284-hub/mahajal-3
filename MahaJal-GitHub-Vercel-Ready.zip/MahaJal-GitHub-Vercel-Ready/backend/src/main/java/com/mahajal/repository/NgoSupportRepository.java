package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface NgoSupportRepository extends JpaRepository<NgoSupport, Long> {
    List<NgoSupport> findByNgoUserIdOrderByCreatedAtDesc(Long userId);
    List<NgoSupport> findByVillageId(Long villageId);
}
