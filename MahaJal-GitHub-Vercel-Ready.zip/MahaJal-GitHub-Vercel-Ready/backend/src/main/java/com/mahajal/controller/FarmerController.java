package com.mahajal.controller;

import com.mahajal.dto.ApiResponse;
import com.mahajal.dto.Dtos.*;
import com.mahajal.security.AppUserDetails;
import com.mahajal.service.FarmerService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/farmer")
public class FarmerController {
    private final FarmerService svc;
    public FarmerController(FarmerService svc) { this.svc = svc; }

    private static Long uid(AppUserDetails me) { return me.getUser().getId(); }

    @GetMapping("/dashboard")
    public ApiResponse<FarmerDashboardDto> dashboard(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.dashboard(uid(me))); }

    @GetMapping("/profile")
    public ApiResponse<FarmerProfileDto> profile(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.profile(uid(me))); }

    @PutMapping("/profile")
    public ApiResponse<FarmerProfileDto> updateProfile(@AuthenticationPrincipal AppUserDetails me, @Valid @RequestBody ProfileUpdateRequest r) {
        return ApiResponse.ok("Profile updated", svc.updateProfile(uid(me), r));
    }

    @GetMapping("/crops")
    public ApiResponse<List<CropDto>> crops(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.crops(uid(me))); }

    @PostMapping("/crops") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<CropDto> addCrop(@AuthenticationPrincipal AppUserDetails me, @Valid @RequestBody CropRequest r) {
        return ApiResponse.ok("Crop added", svc.addCrop(uid(me), r));
    }

    @GetMapping("/crops/{id}")
    public ApiResponse<CropDto> crop(@AuthenticationPrincipal AppUserDetails me, @PathVariable Long id) { return ApiResponse.ok(svc.crop(uid(me), id)); }

    @DeleteMapping("/crops/{id}")
    public ApiResponse<Void> deleteCrop(@AuthenticationPrincipal AppUserDetails me, @PathVariable Long id) {
        svc.deleteCrop(uid(me), id);
        return ApiResponse.ok("Crop deleted", null);
    }

    @GetMapping("/crops/{id}/advisory")
    public ApiResponse<FarmerAdvisoryDto> advisory(@AuthenticationPrincipal AppUserDetails me, @PathVariable Long id,
                                                   @RequestParam(required = false) String weather) {
        return ApiResponse.ok(svc.cropAdvisory(uid(me), id, weather));
    }

    @GetMapping("/damage-reports")
    public ApiResponse<List<DamageDto>> damage(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.myDamage(uid(me))); }

    @PostMapping("/damage-reports") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<DamageDto> reportDamage(@AuthenticationPrincipal AppUserDetails me, @Valid @RequestBody DamageRequest r) {
        return ApiResponse.ok("Crop damage report submitted", svc.reportDamage(uid(me), r));
    }

    @GetMapping("/tanker-requests")
    public ApiResponse<List<TankerDto>> tankers(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.myTankers(uid(me))); }

    @PostMapping("/tanker-requests") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<TankerDto> tanker(@AuthenticationPrincipal AppUserDetails me, @Valid @RequestBody TankerReq r) {
        return ApiResponse.ok("Tanker request submitted", svc.requestTanker(uid(me), r));
    }

    @GetMapping("/sos")
    public ApiResponse<List<SosDto>> sosList(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.mySos(uid(me))); }

    @PostMapping("/sos") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<SosDto> sos(@AuthenticationPrincipal AppUserDetails me, @Valid @RequestBody SosRequest r) {
        return ApiResponse.ok("SOS sent to authorities", svc.sos(uid(me), r));
    }
}
