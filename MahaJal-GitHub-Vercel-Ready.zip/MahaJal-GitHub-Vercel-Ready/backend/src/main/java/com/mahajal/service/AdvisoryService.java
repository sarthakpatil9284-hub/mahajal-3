package com.mahajal.service;

import com.mahajal.dto.Dtos.AdvisoryOptions;
import com.mahajal.dto.Dtos.AdvisoryRequest;
import com.mahajal.dto.Dtos.AdvisoryResult;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Rule-based crop advisory (demo rules, no ML). Every output line is backed by a reason shown to the user. */
@Service
public class AdvisoryService {
    public static final String RULE_SET = "MahaJal demo rule set v1 – illustrative guidance only, not an official agronomic recommendation. "
            + "Confirm with your local Krishi Vigyan Kendra / agriculture officer.";
    static final List<String> CROPS = List.of("Jowar", "Bajra", "Soybean", "Cotton", "Tur (Pigeon pea)", "Gram (Chickpea)",
            "Wheat", "Maize", "Onion", "Sugarcane", "Pomegranate", "Grapes", "Rice (Paddy)");
    static final List<String> STAGES = List.of("SOWING", "VEGETATIVE", "FLOWERING", "GRAIN_FILLING", "HARVEST");
    static final List<String> WEATHER = List.of("CLEAR", "CLOUDY", "RAIN_FORECAST", "HEATWAVE");
    static final List<String> SOILS = List.of("BLACK", "RED", "ALLUVIAL", "SANDY", "LOAMY");
    private static final Set<String> HIGH_DEMAND = Set.of("Sugarcane", "Rice (Paddy)");
    private static final Set<String> LOW_DEMAND = Set.of("Jowar", "Bajra", "Tur (Pigeon pea)", "Gram (Chickpea)");

    public AdvisoryOptions options() { return new AdvisoryOptions(CROPS, STAGES, WEATHER, SOILS); }

    private static String f(String fmt, Object... a) { return String.format(Locale.ROOT, fmt, a); }

    public AdvisoryResult generate(AdvisoryRequest r) {
        String demand = HIGH_DEMAND.contains(r.crop()) ? "HIGH" : LOW_DEMAND.contains(r.crop()) ? "LOW" : "MEDIUM";
        double target = switch (demand) { case "HIGH" -> 60; case "LOW" -> 35; default -> 45; };
        String stage = r.stage().toUpperCase(Locale.ROOT);
        String weather = r.weather().toUpperCase(Locale.ROOT);
        String soil = r.soilType().toUpperCase(Locale.ROOT);
        boolean critical = stage.equals("FLOWERING") || stage.equals("GRAIN_FILLING");
        if (critical) target += 10;
        if (stage.equals("HARVEST")) target -= 15;
        double moisture = r.soilMoisturePct(), rain = r.rainfallMm(), water = r.waterAvailabilityPct();
        boolean rainComing = weather.equals("RAIN_FORECAST");

        List<String> why = new ArrayList<>();
        why.add(f("%s is a %s water-demand crop. Target soil moisture at the %s stage is about %.0f%% (current: %.0f%%).",
                r.crop(), demand.toLowerCase(Locale.ROOT), stage, target, moisture));
        double score = 0.6 * (Math.max(0, target - moisture) / target * 100.0);
        if (weather.equals("HEATWAVE")) { score += 15; why.add("Heatwave conditions increase evaporation and crop water demand (+15 stress)."); }
        if (rain < 10 && !rainComing) { score += 10; why.add(f("Only %.0f mm of rain in the last 7 days and none forecast (+10 stress).", rain)); }
        if (water < 30) { score += 10; why.add(f("Water availability is low (%.0f%%), limiting irrigation options (+10 stress).", water)); }
        if (critical && moisture < target) why.add("The crop is at a moisture-critical stage, so shortages cause larger yield loss.");
        score = Math.max(0, Math.min(100, score));
        String level = score < 25 ? "LOW" : score < 50 ? "MODERATE" : score < 75 ? "HIGH" : "SEVERE";

        String interval = soil.equals("SANDY") ? "light irrigation every 3–4 days (sandy soil drains fast)"
                : soil.equals("BLACK") ? "deeper irrigation every 7–10 days (black soil holds water longer)"
                : "irrigation every 5–7 days";
        String irrigation;
        if (rain >= 40 || (rainComing && moisture >= target * 0.8)) {
            irrigation = "Skip irrigation now. Recent or forecast rain should meet crop needs; re-check soil moisture after 2–3 days.";
            why.add("Recent/forecast rainfall is enough to keep soil moisture near target.");
        } else if (moisture < target) {
            irrigation = water < 30
                    ? "Water is scarce: give protective irrigation only (drip or one light application) and prioritise the most critical growth stage."
                    : "Irrigate within 1–2 days. For " + soil.toLowerCase(Locale.ROOT) + " soil use " + interval + ".";
            why.add(f("Soil moisture (%.0f%%) is below the target (%.0f%%).", moisture, target));
        } else {
            irrigation = "Soil moisture is adequate. No irrigation needed today; plan " + interval + " and re-check weekly.";
            why.add("Soil moisture is at or above target.");
        }

        String rainAdvice;
        if (rain >= 50) rainAdvice = f("Heavy recent rain (%.0f mm): ensure field drainage, avoid waterlogging, and delay fertilizer and pesticide application.", rain);
        else if (rain < 10 && rainComing) rainAdvice = "Dry week but rain is forecast: delay irrigation and fertilizer, and keep bunds/channels ready to capture runoff.";
        else if (rain < 10) rainAdvice = f("Dry spell (%.0f mm in 7 days): rely on stored soil moisture, mulch the field and use protective irrigation if available.", rain);
        else rainAdvice = f("Rainfall of %.0f mm is moderate. Continue normal practices and monitor the forecast.", rain);

        String fert = switch (stage) {
            case "SOWING" -> "Apply the basal dose (phosphorus, potash and part of the nitrogen) at sowing, based on a soil test.";
            case "VEGETATIVE" -> "Apply the first nitrogen top-dressing around 25–35 days after sowing, when the soil has adequate moisture.";
            case "FLOWERING" -> "Avoid heavy nitrogen now; consider a foliar potassium/micronutrient spray if the crop looks stressed.";
            case "GRAIN_FILLING" -> "Do not apply nitrogen; potash (as per soil test) supports grain/fruit filling.";
            default -> "No fertilizer at harvest. Take a soil sample to plan the next season's nutrient schedule.";
        };
        if (moisture < 25 && !stage.equals("SOWING") && !stage.equals("HARVEST")) fert += " Postpone soil-applied fertilizer until moisture improves; dry soil can burn roots.";
        if (rain >= 50 || rainComing) fert += " Hold off application for about 2 days to avoid nutrient wash-off.";

        List<String> cons = new ArrayList<>();
        cons.add("Mulch with crop residue to cut evaporation.");
        if (soil.equals("SANDY")) cons.add("Add farmyard manure or compost to improve water holding.");
        if (water < 40) cons.add("Prefer drip/sprinkler irrigation and irrigate early morning or evening.");
        if (demand.equals("HIGH")) cons.add("Use water-saving methods (trash mulching, alternate wetting and drying / SRI-type practices).");
        cons.add("Build field bunds or a farm pond to harvest runoff.");

        return new AdvisoryResult(irrigation, rainAdvice, level, Mappers.round1(score), fert, String.join(" ", cons), why, RULE_SET);
    }
}
