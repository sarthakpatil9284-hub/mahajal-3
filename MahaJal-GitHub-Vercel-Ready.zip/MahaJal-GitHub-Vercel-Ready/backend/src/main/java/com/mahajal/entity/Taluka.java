package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "talukas")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Taluka {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, length = 80) private String name;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "district_id") private District district;
}
