package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface DroughtAssessmentRepository extends JpaRepository<DroughtAssessment, Long> {
    Optional<DroughtAssessment> findByVillageId(Long villageId);
    List<DroughtAssessment> findByVillageTalukaDistrictId(Long districtId);
    List<DroughtAssessment> findByRiskLevelIn(Collection<RiskLevel> levels);
    long countByRiskLevel(RiskLevel level);
}
