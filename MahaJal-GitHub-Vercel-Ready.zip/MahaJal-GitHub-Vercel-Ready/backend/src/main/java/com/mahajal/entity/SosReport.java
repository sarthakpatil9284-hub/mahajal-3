package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "sos_reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SosReport {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "farmer_id") private Farmer farmer;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id") private Village village;
    @Column(length = 30) private String category;
    @Column(length = 1000) private String message;
    private Double latitude;
    private Double longitude;
    @Enumerated(EnumType.STRING) @Column(length = 20) @Builder.Default private SosStatus status = SosStatus.OPEN;
    @Builder.Default private LocalDateTime createdAt = LocalDateTime.now();
}
