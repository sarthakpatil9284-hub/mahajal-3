package com.mahajal.dto;

import com.mahajal.entity.Enums.RoleName;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** All request/response DTOs. Entities are never exposed directly. */
public final class Dtos {
    private Dtos() {}

    // ---------- auth ----------
    public record RegisterRequest(
            @NotBlank @Size(max = 100) String fullName,
            @NotBlank @Email String email,
            @NotBlank @Size(min = 8, max = 64) String password,
            @Pattern(regexp = "^$|^[0-9]{10}$", message = "Phone must be 10 digits") String phone,
            @NotNull RoleName role,
            Long villageId,
            @Size(max = 120) String organization) {}
    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}
    public record UserDto(Long id, String fullName, String email, String role, String phone, String organization) {}
    public record AuthResponse(String token, UserDto user) {}
    public record ForgotRequest(@NotBlank @Email String email) {}
    public record ForgotResponse(String message, String demoResetToken) {}
    public record ResetRequest(@NotBlank String token, @NotBlank @Size(min = 8, max = 64) String newPassword) {}
    public record GovUserRequest(@NotBlank String fullName, @NotBlank @Email String email,
                                 @NotBlank @Size(min = 8, max = 64) String password, String phone) {}

    // ---------- location / map ----------
    public record LocationDto(Long id, String name) {}
    public record VillageMapDto(Long id, String name, String taluka, String district,
                                double latitude, double longitude, double riskScore, String riskLevel) {}
    public record DistrictMapDto(Long id, String name, double latitude, double longitude,
                                 Double avgRiskScore, String riskLevel, int villagesAssessed) {}

    // ---------- village dashboard ----------
    public record Factor(String name, String value, double points, double maxPoints, String level, String explanation) {}
    public record SeriesPoint(String label, double actual, double normal) {}
    public record WaterSourceDto(Long id, String village, String district, String name, String type,
                                 double storagePct, boolean functional) {}
    public record NeedDto(Long id, Long villageId, String village, String needType, String description,
                          long estimatedCostInr, String priority) {}
    public record SupportGapDto(long totalNeed, long governmentSupport, long ngoSupport, long csrSupport,
                                long remainingGap, boolean demo) {}
    public record VillageDashboardDto(Long id, String name, String taluka, String district, Long districtId,
                                      int population, int farmers, boolean demo,
                                      Double latestRainfallMm, Double latestNormalMm, double rainfallDeficitPct,
                                      double groundwaterDepthM, double waterAvailabilityPct, double soilMoisturePct,
                                      double cropStressIndex, double riskScore, String riskLevel, String scoreLabel,
                                      LocalDate assessedOn, List<Factor> whyAtRisk,
                                      List<SeriesPoint> rainfallSeries, List<SeriesPoint> groundwaterSeries,
                                      List<WaterSourceDto> waterSources, SupportGapDto supportGap, List<NeedDto> needs) {}

    // ---------- rainfall / water ----------
    public record VillageRainfallRow(Long villageId, String village, String taluka, String district,
                                     double latestMm, double normalMm, double deficitPct, String riskLevel) {}
    public record RainfallSummaryDto(List<SeriesPoint> series, List<VillageRainfallRow> villages) {}
    public record GroundwaterRow(Long villageId, String village, String district, double depthM) {}
    public record WaterSummaryDto(List<WaterSourceDto> sources, List<GroundwaterRow> groundwater) {}

    // ---------- advisory ----------
    public record AdvisoryRequest(@NotBlank String crop, @NotBlank String stage,
                                  @NotNull @PositiveOrZero Double rainfallMm, @NotBlank String weather,
                                  @NotNull @Min(0) @Max(100) Double soilMoisturePct,
                                  @NotNull @Min(0) @Max(100) Double waterAvailabilityPct, @NotBlank String soilType) {}
    public record AdvisoryResult(String irrigationAdvice, String rainfallAdvice, String cropStressLevel,
                                 double cropStressScore, String fertilizerAdvice, String conservationAdvice,
                                 List<String> reasons, String ruleSet) {}
    public record FarmerAdvisoryDto(AdvisoryRequest inputs, AdvisoryResult result) {}
    public record AdvisoryOptions(List<String> crops, List<String> stages, List<String> weather, List<String> soilTypes) {}

    // ---------- farmer ----------
    public record FarmerProfileDto(Long id, String fullName, String email, String phone, double landAcres,
                                   Long villageId, String village, Long talukaId, String taluka,
                                   Long districtId, String district) {}
    public record ProfileUpdateRequest(@NotBlank @Size(max = 100) String fullName,
                                       @Pattern(regexp = "^$|^[0-9]{10}$", message = "Phone must be 10 digits") String phone,
                                       @NotNull @PositiveOrZero Double landAcres, @NotNull Long villageId) {}
    public record CropRequest(@NotBlank String cropName, @NotBlank String season, @NotBlank String stage,
                              @NotNull @Positive Double areaAcres, LocalDate sowingDate,
                              @NotBlank String soilType, @NotBlank String irrigationType) {}
    public record CropDto(Long id, String cropName, String season, String stage, double areaAcres,
                          LocalDate sowingDate, String soilType, String irrigationType) {}
    public record DamageRequest(Long cropId, @NotBlank String cause, @NotNull @Min(1) @Max(100) Integer damagePercent,
                                @NotNull @Positive Double areaAffectedAcres, @Size(max = 1000) String description) {}
    public record DamageDto(Long id, String farmer, String village, String district, String crop, String cause,
                            int damagePercent, double areaAffectedAcres, String description, String status,
                            String remarks, LocalDateTime createdAt) {}
    public record TankerReq(@NotNull @Min(1) Integer peopleCount, @NotNull @Min(0) Integer livestockCount,
                            @NotNull @Min(500) Integer litersRequired, @NotBlank String urgency,
                            @Size(max = 500) String remarks) {}
    public record TankerDto(Long id, String farmer, String village, String district, int peopleCount,
                            int livestockCount, int litersRequired, String urgency, String remarks,
                            String status, LocalDateTime createdAt) {}
    public record SosRequest(@NotBlank String category, @NotBlank @Size(max = 1000) String message,
                             Double latitude, Double longitude) {}
    public record SosDto(Long id, String farmer, String phone, String village, String district, String category,
                         String message, Double latitude, Double longitude, String status, LocalDateTime createdAt) {}
    public record StatusUpdate(@NotBlank String status, @Size(max = 500) String remarks) {}
    public record NotificationDto(Long id, String title, String message, String type, boolean seen, LocalDateTime createdAt) {}
    public record FarmerDashboardDto(FarmerProfileDto profile, int cropCount, double totalAcres, long damageReports,
                                     long tankerRequests, long sosReports, long unreadNotifications,
                                     VillageMapDto villageRisk, List<Factor> whyAtRisk) {}

    // ---------- government ----------
    public record NameValue(String name, long value) {}
    public record VillageRow(Long id, String name, String taluka, String district, int population, int farmers,
                             double rainfallDeficitPct, double groundwaterDepthM, double waterAvailabilityPct,
                             double cropStressIndex, double riskScore, String riskLevel, long totalNeed,
                             long governmentSupport, long ngoSupport, long csrSupport, long remainingGap) {}
    public record FarmerRow(Long id, String fullName, String phone, double landAcres, String village,
                            String taluka, String district, int crops) {}
    public record DistrictRow(Long id, String name, int villages, int criticalVillages, Double avgRiskScore, String riskLevel) {}
    public record GovDashboardDto(long totalDistricts, long villagesAssessed, long criticalVillages, long highRiskVillages,
                                  long affectedFarmers, long sosRequests, long tankerRequests,
                                  List<NameValue> riskDistribution, List<VillageMapDto> topVillages,
                                  List<DistrictMapDto> districtRisk) {}
    public record ScatterPoint(String village, double deficitPct, double groundwaterDepthM, double riskScore) {}
    public record AnalyticsDto(List<DistrictMapDto> districtRisk, List<ScatterPoint> scatter,
                               List<NameValue> riskDistribution, List<NameValue> damageByStatus,
                               List<NameValue> sosByCategory, List<NameValue> tankerByStatus) {}
    public record ObservationRequest(@NotNull Long villageId, @NotNull LocalDate month,
                                     @PositiveOrZero Double actualMm, @PositiveOrZero Double normalMm,
                                     @PositiveOrZero Double groundwaterDepthM) {}

    // ---------- NGO / CSR ----------
    public record SupportRequest(@NotNull Long villageId, Long needId, @NotBlank @Size(max = 100) String supportType,
                                 @NotNull @Positive Long amountInr, @Size(max = 500) String description) {}
    public record SupportDto(Long id, String organization, Long villageId, String village, String district,
                             String supportType, long amountInr, String description, String status,
                             LocalDateTime createdAt, boolean demo) {}
}
