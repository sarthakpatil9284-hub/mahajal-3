package com.mahajal.controller;

import com.mahajal.dto.ApiResponse;
import com.mahajal.dto.Dtos.*;
import com.mahajal.security.AppUserDetails;
import com.mahajal.service.PartnerService;
import com.mahajal.service.VillageService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class PartnerController {
    private final PartnerService partners;
    private final VillageService villages;

    public PartnerController(PartnerService partners, VillageService villages) { this.partners = partners; this.villages = villages; }

    @GetMapping("/partner/villages")
    public ApiResponse<List<VillageRow>> villageNeeds(@RequestParam(required = false) Long districtId) { return ApiResponse.ok(villages.villageRows(districtId)); }

    @GetMapping("/partner/villages/{id}/needs")
    public ApiResponse<List<NeedDto>> needs(@PathVariable Long id) { return ApiResponse.ok(villages.needsOf(id)); }

    @GetMapping("/ngo/support")
    public ApiResponse<List<SupportDto>> ngoList(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(partners.ngoList(me.getUser().getId())); }

    @PostMapping("/ngo/support") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<SupportDto> ngoOffer(@AuthenticationPrincipal AppUserDetails me, @Valid @RequestBody SupportRequest r) {
        return ApiResponse.ok("Support offer recorded", partners.offerNgo(me.getUser().getId(), r));
    }

    @GetMapping("/csr/support")
    public ApiResponse<List<SupportDto>> csrList(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(partners.csrList(me.getUser().getId())); }

    @PostMapping("/csr/support") @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<SupportDto> csrCommit(@AuthenticationPrincipal AppUserDetails me, @Valid @RequestBody SupportRequest r) {
        return ApiResponse.ok("Support commitment recorded", partners.commitCsr(me.getUser().getId(), r));
    }
}
