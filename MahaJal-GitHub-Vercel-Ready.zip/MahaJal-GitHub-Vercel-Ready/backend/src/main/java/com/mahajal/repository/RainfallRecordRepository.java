package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface RainfallRecordRepository extends JpaRepository<RainfallRecord, Long> {
    List<RainfallRecord> findByVillageIdOrderByRecordMonthAsc(Long villageId);
    Optional<RainfallRecord> findTopByVillageIdOrderByRecordMonthDesc(Long villageId);
    @Query("select r.recordMonth, avg(r.actualMm), avg(r.normalMm) from RainfallRecord r group by r.recordMonth order by r.recordMonth")
    List<Object[]> seriesAll();
    @Query("select r.recordMonth, avg(r.actualMm), avg(r.normalMm) from RainfallRecord r where r.village.taluka.district.id = :districtId group by r.recordMonth order by r.recordMonth")
    List<Object[]> seriesByDistrict(@Param("districtId") Long districtId);
}
