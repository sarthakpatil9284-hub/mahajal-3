package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface FarmerRepository extends JpaRepository<Farmer, Long> {
    Optional<Farmer> findByUserId(Long userId);
    List<Farmer> findByVillageId(Long villageId);
}
