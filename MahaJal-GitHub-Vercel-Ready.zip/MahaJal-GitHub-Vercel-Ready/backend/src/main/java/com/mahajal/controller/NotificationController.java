package com.mahajal.controller;

import com.mahajal.dto.ApiResponse;
import com.mahajal.dto.Dtos.NotificationDto;
import com.mahajal.security.AppUserDetails;
import com.mahajal.service.NotificationService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationService svc;
    public NotificationController(NotificationService svc) { this.svc = svc; }

    @GetMapping
    public ApiResponse<List<NotificationDto>> list(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.list(me.getUser().getId())); }

    @GetMapping("/unread-count")
    public ApiResponse<Long> unread(@AuthenticationPrincipal AppUserDetails me) { return ApiResponse.ok(svc.unread(me.getUser().getId())); }

    @PostMapping("/{id}/read")
    public ApiResponse<Void> read(@AuthenticationPrincipal AppUserDetails me, @PathVariable Long id) {
        svc.markSeen(me.getUser().getId(), id);
        return ApiResponse.ok("Marked as read", null);
    }

    @PostMapping("/read-all")
    public ApiResponse<Void> readAll(@AuthenticationPrincipal AppUserDetails me) {
        svc.markAllSeen(me.getUser().getId());
        return ApiResponse.ok("All notifications marked as read", null);
    }
}
