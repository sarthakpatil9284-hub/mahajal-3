package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface GroundwaterRecordRepository extends JpaRepository<GroundwaterRecord, Long> {
    List<GroundwaterRecord> findByVillageIdOrderByRecordMonthAsc(Long villageId);
    Optional<GroundwaterRecord> findTopByVillageIdOrderByRecordMonthDesc(Long villageId);
}
