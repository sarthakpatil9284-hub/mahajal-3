package com.mahajal.service;

import com.mahajal.entity.*;
import com.mahajal.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class DroughtService {
    private final RainfallRecordRepository rainfall;
    private final GroundwaterRecordRepository groundwater;
    private final WaterSourceRepository waterSources;
    private final DroughtAssessmentRepository assessments;
    private final VillageRepository villages;
    private final DroughtScoring scoring;

    public DroughtService(RainfallRecordRepository rainfall, GroundwaterRecordRepository groundwater,
                          WaterSourceRepository waterSources, DroughtAssessmentRepository assessments,
                          VillageRepository villages, DroughtScoring scoring) {
        this.rainfall = rainfall; this.groundwater = groundwater; this.waterSources = waterSources;
        this.assessments = assessments; this.villages = villages; this.scoring = scoring;
    }

    /** Computes (or refreshes) the single assessment row of a village from the stored records. */
    @Transactional
    public DroughtAssessment assess(Village v, double soilMoisturePct, boolean demo) {
        List<RainfallRecord> all = rainfall.findByVillageIdOrderByRecordMonthAsc(v.getId());
        List<RainfallRecord> window = all.size() > 6 ? all.subList(all.size() - 6, all.size()) : all;
        double actual = window.stream().mapToDouble(RainfallRecord::getActualMm).sum();
        double normal = window.stream().mapToDouble(RainfallRecord::getNormalMm).sum();
        double deficit = normal > 0 ? (normal - actual) / normal * 100.0 : 0;
        double gw = groundwater.findTopByVillageIdOrderByRecordMonthDesc(v.getId()).map(GroundwaterRecord::getDepthM).orElse(15.0);
        double water = waterSources.findByVillageId(v.getId()).stream().mapToDouble(WaterSource::getStoragePct).average().orElse(50.0);
        double stress = scoring.cropStress(deficit, soilMoisturePct);
        double score = scoring.score(deficit, gw, water, stress);

        DroughtAssessment a = assessments.findByVillageId(v.getId())
                .orElseGet(() -> DroughtAssessment.builder().village(v).demoData(demo).build());
        a.setAssessedOn(LocalDate.now());
        a.setRainfallDeficitPct(Mappers.round1(deficit));
        a.setGroundwaterDepthM(Mappers.round1(gw));
        a.setWaterAvailabilityPct(Mappers.round1(water));
        a.setSoilMoisturePct(Mappers.round1(soilMoisturePct));
        a.setCropStressIndex(stress);
        a.setRiskScore(score);
        a.setRiskLevel(scoring.level(score));
        return assessments.save(a);
    }

    @Transactional
    public DroughtAssessment reassess(Village v) {
        double soil = assessments.findByVillageId(v.getId()).map(DroughtAssessment::getSoilMoisturePct).orElse(50.0);
        return assess(v, soil, false);
    }

    @Transactional
    public int reassessAll() {
        List<Village> all = villages.findAll();
        all.forEach(this::reassess);
        return all.size();
    }
}
