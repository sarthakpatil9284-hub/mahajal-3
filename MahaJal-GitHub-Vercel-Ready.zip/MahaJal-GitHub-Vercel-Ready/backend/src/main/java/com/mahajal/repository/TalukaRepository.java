package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface TalukaRepository extends JpaRepository<Taluka, Long> {
    List<Taluka> findByDistrictIdOrderByNameAsc(Long districtId);
}
