package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "water_sources")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class WaterSource {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id") private Village village;
    @Column(nullable = false, length = 120) private String name;
    @Enumerated(EnumType.STRING) @Column(length = 20) private WaterSourceType type;
    private double storagePct;
    private boolean functional;
}
