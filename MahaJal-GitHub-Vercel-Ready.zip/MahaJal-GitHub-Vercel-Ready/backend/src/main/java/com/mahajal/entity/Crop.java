package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "crops")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Crop {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "farmer_id") private Farmer farmer;
    @Column(nullable = false, length = 60) private String cropName;
    @Column(length = 20) private String season;
    @Column(length = 20) private String stage;
    private double areaAcres;
    private LocalDate sowingDate;
    @Column(length = 20) private String soilType;
    @Column(length = 20) private String irrigationType;
    @Builder.Default private boolean demoData = false;
}
