package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "user_id") private User user;
    @Column(length = 150) private String title;
    @Column(length = 600) private String message;
    @Column(length = 20) private String type;
    @Column(name = "is_seen") private boolean seen;
    @Builder.Default private LocalDateTime createdAt = LocalDateTime.now();
}
