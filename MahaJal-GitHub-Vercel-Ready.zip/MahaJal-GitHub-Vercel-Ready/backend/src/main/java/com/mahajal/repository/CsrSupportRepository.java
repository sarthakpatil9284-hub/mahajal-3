package com.mahajal.repository;

import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface CsrSupportRepository extends JpaRepository<CsrSupport, Long> {
    List<CsrSupport> findByCsrUserIdOrderByCreatedAtDesc(Long userId);
    List<CsrSupport> findByVillageId(Long villageId);
}
