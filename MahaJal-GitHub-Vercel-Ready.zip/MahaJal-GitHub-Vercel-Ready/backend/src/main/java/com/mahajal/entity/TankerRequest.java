package com.mahajal.entity;

import com.mahajal.entity.Enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;

@Entity @Table(name = "tanker_requests")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TankerRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "farmer_id") private Farmer farmer;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "village_id") private Village village;
    private int peopleCount;
    private int livestockCount;
    private int litersRequired;
    @Column(length = 20) private String urgency;
    @Column(length = 500) private String remarks;
    @Enumerated(EnumType.STRING) @Column(length = 20) @Builder.Default private TankerStatus status = TankerStatus.REQUESTED;
    @Builder.Default private LocalDateTime createdAt = LocalDateTime.now();
}
