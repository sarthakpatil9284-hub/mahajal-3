package com.mahajal.service;

import com.mahajal.dto.Dtos.*;
import com.mahajal.entity.*;
import com.mahajal.exception.ApiException;
import com.mahajal.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PartnerService {
    private final UserRepository users;
    private final VillageRepository villages;
    private final VillageNeedRepository needs;
    private final NgoSupportRepository ngo;
    private final CsrSupportRepository csr;
    private final VillageService villageService;
    private final NotificationService notifications;

    public PartnerService(UserRepository users, VillageRepository villages, VillageNeedRepository needs,
                          NgoSupportRepository ngo, CsrSupportRepository csr, VillageService villageService,
                          NotificationService notifications) {
        this.users = users; this.villages = villages; this.needs = needs; this.ngo = ngo; this.csr = csr;
        this.villageService = villageService; this.notifications = notifications;
    }

    private Village village(Long id) { return villages.findById(id).orElseThrow(() -> ApiException.notFound("Village not found")); }

    private VillageNeed need(Long needId, Village v) {
        if (needId == null) return null;
        VillageNeed n = needs.findById(needId).orElseThrow(() -> ApiException.badRequest("Need not found"));
        if (!n.getVillage().getId().equals(v.getId())) throw ApiException.badRequest("Need does not belong to the selected village");
        return n;
    }

    @Transactional(readOnly = true)
    public List<SupportDto> ngoList(Long userId) {
        return ngo.findByNgoUserIdOrderByCreatedAtDesc(userId).stream().map(Mappers::ngo).toList();
    }

    public SupportDto offerNgo(Long userId, SupportRequest r) {
        Village v = village(r.villageId());
        User u = users.findById(userId).orElseThrow();
        NgoSupport s = ngo.save(NgoSupport.builder().ngoUser(u).village(v).need(need(r.needId(), v)).supportType(r.supportType())
                .amountInr(r.amountInr()).description(r.description()).build());
        villageService.recalcGap(v);
        notifications.notifyGovernment("NGO support offered", u.getOrganization() + " offered INR " + r.amountInr() + " to " + v.getName() + ".", "INFO");
        return Mappers.ngo(s);
    }

    @Transactional(readOnly = true)
    public List<SupportDto> csrList(Long userId) {
        return csr.findByCsrUserIdOrderByCreatedAtDesc(userId).stream().map(Mappers::csr).toList();
    }

    public SupportDto commitCsr(Long userId, SupportRequest r) {
        Village v = village(r.villageId());
        User u = users.findById(userId).orElseThrow();
        CsrSupport s = csr.save(CsrSupport.builder().csrUser(u).village(v).need(need(r.needId(), v)).programName(r.supportType())
                .amountInr(r.amountInr()).description(r.description()).build());
        villageService.recalcGap(v);
        notifications.notifyGovernment("CSR commitment recorded", u.getOrganization() + " committed INR " + r.amountInr() + " to " + v.getName() + ".", "INFO");
        return Mappers.csr(s);
    }
}
