package com.mahajal.service;

import com.mahajal.dto.Dtos.*;
import com.mahajal.entity.*;
import com.mahajal.exception.ApiException;
import com.mahajal.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class FarmerService {
    private final FarmerRepository farmers;
    private final CropRepository crops;
    private final VillageRepository villages;
    private final CropDamageReportRepository damage;
    private final TankerRequestRepository tankers;
    private final SosReportRepository sosReports;
    private final DroughtAssessmentRepository assessments;
    private final RainfallRecordRepository rainfall;
    private final NotificationRepository notificationRepo;
    private final NotificationService notifications;
    private final AdvisoryService advisory;
    private final DroughtScoring scoring;
    private final UserRepository users;

    public FarmerService(FarmerRepository farmers, CropRepository crops, VillageRepository villages,
                         CropDamageReportRepository damage, TankerRequestRepository tankers, SosReportRepository sosReports,
                         DroughtAssessmentRepository assessments, RainfallRecordRepository rainfall,
                         NotificationRepository notificationRepo, NotificationService notifications,
                         AdvisoryService advisory, DroughtScoring scoring, UserRepository users) {
        this.farmers = farmers; this.crops = crops; this.villages = villages; this.damage = damage; this.tankers = tankers;
        this.sosReports = sosReports; this.assessments = assessments; this.rainfall = rainfall;
        this.notificationRepo = notificationRepo; this.notifications = notifications; this.advisory = advisory;
        this.scoring = scoring; this.users = users;
    }

    private Farmer farmer(Long userId) {
        return farmers.findByUserId(userId).orElseThrow(() -> ApiException.notFound("Farmer profile not found for this account"));
    }

    @Transactional(readOnly = true)
    public FarmerProfileDto profile(Long userId) { return Mappers.farmer(farmer(userId)); }

    public FarmerProfileDto updateProfile(Long userId, ProfileUpdateRequest r) {
        Farmer f = farmer(userId);
        Village v = villages.findById(r.villageId()).orElseThrow(() -> ApiException.badRequest("Selected village does not exist"));
        f.setFullName(r.fullName().trim());
        f.setPhone(r.phone() == null || r.phone().isBlank() ? null : r.phone());
        f.setLandAcres(r.landAcres());
        f.setVillage(v);
        farmers.save(f);
        User u = f.getUser();
        u.setFullName(f.getFullName());
        u.setPhone(f.getPhone());
        users.save(u);
        return Mappers.farmer(f);
    }

    @Transactional(readOnly = true)
    public FarmerDashboardDto dashboard(Long userId) {
        Farmer f = farmer(userId);
        List<Crop> myCrops = crops.findByFarmerIdOrderByIdDesc(f.getId());
        Optional<DroughtAssessment> a = assessments.findByVillageId(f.getVillage().getId());
        return new FarmerDashboardDto(Mappers.farmer(f), myCrops.size(), myCrops.stream().mapToDouble(Crop::getAreaAcres).sum(),
                damage.findByFarmerIdOrderByCreatedAtDesc(f.getId()).size(), tankers.findByFarmerIdOrderByCreatedAtDesc(f.getId()).size(),
                sosReports.findByFarmerIdOrderByCreatedAtDesc(f.getId()).size(), notificationRepo.countByUserIdAndSeenFalse(userId),
                a.map(Mappers::mapPoint).orElse(null),
                a.map(x -> scoring.explain(x.getRainfallDeficitPct(), x.getGroundwaterDepthM(), x.getWaterAvailabilityPct(), x.getCropStressIndex())).orElse(List.of()));
    }

    // ---------- crops ----------
    @Transactional(readOnly = true)
    public List<CropDto> crops(Long userId) {
        return crops.findByFarmerIdOrderByIdDesc(farmer(userId).getId()).stream().map(Mappers::crop).toList();
    }

    @Transactional(readOnly = true)
    public CropDto crop(Long userId, Long id) { return Mappers.crop(ownedCrop(userId, id)); }

    private Crop ownedCrop(Long userId, Long id) {
        return crops.findByIdAndFarmerId(id, farmer(userId).getId()).orElseThrow(() -> ApiException.notFound("Crop not found"));
    }

    public CropDto addCrop(Long userId, CropRequest r) {
        Crop c = crops.save(Crop.builder().farmer(farmer(userId)).cropName(r.cropName()).season(r.season()).stage(r.stage())
                .areaAcres(r.areaAcres()).sowingDate(r.sowingDate()).soilType(r.soilType()).irrigationType(r.irrigationType()).build());
        return Mappers.crop(c);
    }

    public void deleteCrop(Long userId, Long id) {
        Crop c = ownedCrop(userId, id);
        try {
            crops.delete(c);
            crops.flush();
        } catch (Exception e) {
            throw ApiException.conflict("This crop is referenced by a damage report and cannot be deleted");
        }
    }

    @Transactional(readOnly = true)
    public FarmerAdvisoryDto cropAdvisory(Long userId, Long cropId, String weather) {
        Crop c = ownedCrop(userId, cropId);
        Long vid = c.getFarmer().getVillage().getId();
        Optional<DroughtAssessment> a = assessments.findByVillageId(vid);
        double soil = a.map(DroughtAssessment::getSoilMoisturePct).orElse(50.0);
        double water = a.map(DroughtAssessment::getWaterAvailabilityPct).orElse(50.0);
        double rain7 = rainfall.findTopByVillageIdOrderByRecordMonthDesc(vid).map(r -> r.getActualMm() / 4.3).orElse(0.0);
        AdvisoryRequest req = new AdvisoryRequest(c.getCropName(), c.getStage() == null ? "VEGETATIVE" : c.getStage(),
                Mappers.round1(rain7), weather == null || weather.isBlank() ? "CLEAR" : weather, soil, water,
                c.getSoilType() == null ? "LOAMY" : c.getSoilType());
        return new FarmerAdvisoryDto(req, advisory.generate(req));
    }

    // ---------- damage / tanker / SOS ----------
    public DamageDto reportDamage(Long userId, DamageRequest r) {
        Farmer f = farmer(userId);
        Crop crop = r.cropId() == null ? null : ownedCrop(userId, r.cropId());
        CropDamageReport saved = damage.save(CropDamageReport.builder().farmer(f).crop(crop).village(f.getVillage())
                .cause(r.cause()).damagePercent(r.damagePercent()).areaAffectedAcres(r.areaAffectedAcres()).description(r.description()).build());
        notifications.notify(f.getUser(), "Crop damage report received", "Your report #" + saved.getId() + " was submitted and is awaiting review.", "SUCCESS");
        notifications.notifyGovernment("New crop damage report", f.getFullName() + " reported " + r.damagePercent() + "% damage in " + f.getVillage().getName() + ".", "INFO");
        return Mappers.damage(saved);
    }

    @Transactional(readOnly = true)
    public List<DamageDto> myDamage(Long userId) {
        return damage.findByFarmerIdOrderByCreatedAtDesc(farmer(userId).getId()).stream().map(Mappers::damage).toList();
    }

    public TankerDto requestTanker(Long userId, TankerReq r) {
        Farmer f = farmer(userId);
        TankerRequest saved = tankers.save(TankerRequest.builder().farmer(f).village(f.getVillage()).peopleCount(r.peopleCount())
                .livestockCount(r.livestockCount()).litersRequired(r.litersRequired()).urgency(r.urgency()).remarks(r.remarks()).build());
        notifications.notify(f.getUser(), "Tanker request received", "Request #" + saved.getId() + " for " + r.litersRequired() + " L has been registered.", "SUCCESS");
        notifications.notifyGovernment("New tanker request", f.getVillage().getName() + ": " + r.litersRequired() + " L (" + r.urgency() + ").", "INFO");
        return Mappers.tanker(saved);
    }

    @Transactional(readOnly = true)
    public List<TankerDto> myTankers(Long userId) {
        return tankers.findByFarmerIdOrderByCreatedAtDesc(farmer(userId).getId()).stream().map(Mappers::tanker).toList();
    }

    public SosDto sos(Long userId, SosRequest r) {
        Farmer f = farmer(userId);
        SosReport saved = sosReports.save(SosReport.builder().farmer(f).village(f.getVillage()).category(r.category())
                .message(r.message()).latitude(r.latitude()).longitude(r.longitude()).build());
        notifications.notify(f.getUser(), "SOS received", "Your SOS #" + saved.getId() + " has been sent to the authorities.", "ALERT");
        notifications.notifyGovernment("SOS alert", f.getFullName() + " (" + f.getVillage().getName() + "): " + r.category(), "ALERT");
        return Mappers.sos(saved);
    }

    @Transactional(readOnly = true)
    public List<SosDto> mySos(Long userId) {
        return sosReports.findByFarmerIdOrderByCreatedAtDesc(farmer(userId).getId()).stream().map(Mappers::sos).toList();
    }
}
