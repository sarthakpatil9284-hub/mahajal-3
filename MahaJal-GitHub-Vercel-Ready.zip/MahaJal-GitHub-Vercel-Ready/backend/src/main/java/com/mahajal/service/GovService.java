package com.mahajal.service;

import com.mahajal.dto.Dtos.*;
import com.mahajal.entity.*;
import com.mahajal.entity.Enums.*;
import com.mahajal.exception.ApiException;
import com.mahajal.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Transactional
public class GovService {
    private final DistrictRepository districts;
    private final VillageRepository villages;
    private final DroughtAssessmentRepository assessments;
    private final FarmerRepository farmers;
    private final CropRepository crops;
    private final CropDamageReportRepository damage;
    private final TankerRequestRepository tankers;
    private final SosReportRepository sos;
    private final RainfallRecordRepository rainfall;
    private final GroundwaterRecordRepository groundwater;
    private final DroughtService droughtService;
    private final VillageService villageService;
    private final NotificationService notifications;

    public GovService(DistrictRepository districts, VillageRepository villages, DroughtAssessmentRepository assessments,
                      FarmerRepository farmers, CropRepository crops, CropDamageReportRepository damage,
                      TankerRequestRepository tankers, SosReportRepository sos, RainfallRecordRepository rainfall,
                      GroundwaterRecordRepository groundwater, DroughtService droughtService,
                      VillageService villageService, NotificationService notifications) {
        this.districts = districts; this.villages = villages; this.assessments = assessments; this.farmers = farmers;
        this.crops = crops; this.damage = damage; this.tankers = tankers; this.sos = sos; this.rainfall = rainfall;
        this.groundwater = groundwater; this.droughtService = droughtService; this.villageService = villageService;
        this.notifications = notifications;
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String s) {
        try { return Enum.valueOf(type, s.trim().toUpperCase(Locale.ROOT)); }
        catch (Exception e) { throw ApiException.badRequest("Invalid status: " + s); }
    }

    private List<NameValue> riskDistribution(List<DroughtAssessment> all) {
        return Arrays.stream(RiskLevel.values()).map(l -> new NameValue(l.name(),
                all.stream().filter(a -> a.getRiskLevel() == l).count())).toList();
    }

    @Transactional(readOnly = true)
    public GovDashboardDto dashboard() {
        List<DroughtAssessment> all = assessments.findAll();
        long critical = all.stream().filter(a -> a.getRiskLevel() == RiskLevel.CRITICAL).count();
        long high = all.stream().filter(a -> a.getRiskLevel() == RiskLevel.HIGH).count();
        long affected = all.stream().filter(a -> a.getRiskLevel() == RiskLevel.HIGH || a.getRiskLevel() == RiskLevel.CRITICAL)
                .mapToLong(a -> a.getVillage().getFarmerCount()).sum();
        long openSos = sos.findAll().stream().filter(s -> s.getStatus() != SosStatus.RESOLVED).count();
        long openTankers = tankers.findAll().stream()
                .filter(t -> t.getStatus() == TankerStatus.REQUESTED || t.getStatus() == TankerStatus.APPROVED || t.getStatus() == TankerStatus.DISPATCHED).count();
        List<VillageMapDto> top = all.stream().sorted(Comparator.comparingDouble(DroughtAssessment::getRiskScore).reversed())
                .limit(8).map(Mappers::mapPoint).toList();
        return new GovDashboardDto(districts.count(), all.size(), critical, high, affected, openSos, openTankers,
                riskDistribution(all), top, villageService.mapDistricts());
    }

    @Transactional(readOnly = true)
    public List<DistrictRow> districtRows() {
        Map<Long, List<DroughtAssessment>> by = assessments.findAll().stream()
                .collect(Collectors.groupingBy(a -> a.getVillage().getTaluka().getDistrict().getId()));
        return districts.findAllByOrderByNameAsc().stream().map(d -> {
            List<DroughtAssessment> l = by.getOrDefault(d.getId(), List.of());
            Double avg = l.isEmpty() ? null : Mappers.round1(l.stream().mapToDouble(DroughtAssessment::getRiskScore).average().orElse(0));
            long crit = l.stream().filter(a -> a.getRiskLevel() == RiskLevel.CRITICAL).count();
            return new DistrictRow(d.getId(), d.getName(), l.size(), (int) crit, avg, avg == null ? null : DroughtScoring.level(avg).name());
        }).toList();
    }

    @Transactional(readOnly = true)
    public List<FarmerRow> farmerRows() {
        return farmers.findAll().stream().map(f -> new FarmerRow(f.getId(), f.getFullName(), f.getPhone(), f.getLandAcres(),
                f.getVillage().getName(), f.getVillage().getTaluka().getName(), f.getVillage().getTaluka().getDistrict().getName(),
                (int) crops.countByFarmerId(f.getId()))).toList();
    }

    // ---------- case lists + status updates ----------
    @Transactional(readOnly = true)
    public List<DamageDto> damageReports() { return damage.findAllByOrderByCreatedAtDesc().stream().map(Mappers::damage).toList(); }
    @Transactional(readOnly = true)
    public List<SosDto> sosReports() { return sos.findAllByOrderByCreatedAtDesc().stream().map(Mappers::sos).toList(); }
    @Transactional(readOnly = true)
    public List<TankerDto> tankerRequests() { return tankers.findAllByOrderByCreatedAtDesc().stream().map(Mappers::tanker).toList(); }

    public DamageDto updateDamage(Long id, StatusUpdate u) {
        CropDamageReport r = damage.findById(id).orElseThrow(() -> ApiException.notFound("Report not found"));
        r.setStatus(parse(ReportStatus.class, u.status()));
        r.setRemarks(u.remarks());
        damage.save(r);
        notifications.notify(r.getFarmer().getUser(), "Damage report update", "Report #" + id + " is now " + r.getStatus() + ".", "INFO");
        return Mappers.damage(r);
    }

    public SosDto updateSos(Long id, StatusUpdate u) {
        SosReport r = sos.findById(id).orElseThrow(() -> ApiException.notFound("SOS report not found"));
        r.setStatus(parse(SosStatus.class, u.status()));
        sos.save(r);
        notifications.notify(r.getFarmer().getUser(), "SOS update", "Your SOS #" + id + " is now " + r.getStatus() + ".", "INFO");
        return Mappers.sos(r);
    }

    public TankerDto updateTanker(Long id, StatusUpdate u) {
        TankerRequest r = tankers.findById(id).orElseThrow(() -> ApiException.notFound("Tanker request not found"));
        r.setStatus(parse(TankerStatus.class, u.status()));
        r.setRemarks(u.remarks() != null && !u.remarks().isBlank() ? u.remarks() : r.getRemarks());
        tankers.save(r);
        notifications.notify(r.getFarmer().getUser(), "Tanker request update", "Request #" + id + " is now " + r.getStatus() + ".", "INFO");
        return Mappers.tanker(r);
    }

    // ---------- analytics ----------
    @Transactional(readOnly = true)
    public AnalyticsDto analytics() {
        List<DroughtAssessment> all = assessments.findAll();
        List<ScatterPoint> scatter = all.stream().map(a -> new ScatterPoint(a.getVillage().getName(), a.getRainfallDeficitPct(),
                a.getGroundwaterDepthM(), a.getRiskScore())).toList();
        return new AnalyticsDto(villageService.mapDistricts().stream().filter(d -> d.avgRiskScore() != null).toList(), scatter,
                riskDistribution(all),
                countBy(damage.findAll(), r -> r.getStatus().name()),
                countBy(sos.findAll(), s -> s.getCategory()),
                countBy(tankers.findAll(), t -> t.getStatus().name()));
    }

    private static <T> List<NameValue> countBy(List<T> list, Function<T, String> key) {
        return list.stream().collect(Collectors.groupingBy(key, TreeMap::new, Collectors.counting()))
                .entrySet().stream().map(e -> new NameValue(e.getKey(), e.getValue())).toList();
    }

    // ---------- observations + recalculation ----------
    public String addObservation(ObservationRequest r) {
        Village v = villages.findById(r.villageId()).orElseThrow(() -> ApiException.notFound("Village not found"));
        boolean any = false;
        LocalDate month = r.month().withDayOfMonth(1);
        if (r.actualMm() != null && r.normalMm() != null) {
            rainfall.save(RainfallRecord.builder().village(v).recordMonth(month).actualMm(r.actualMm()).normalMm(r.normalMm()).build());
            any = true;
        }
        if (r.groundwaterDepthM() != null) {
            groundwater.save(GroundwaterRecord.builder().village(v).recordMonth(month).depthM(r.groundwaterDepthM()).build());
            any = true;
        }
        if (!any) throw ApiException.badRequest("Provide rainfall (actual and normal) and/or groundwater depth");
        DroughtAssessment a = droughtService.reassess(v);
        return "Observation saved. " + v.getName() + " is now " + a.getRiskLevel() + " (score " + a.getRiskScore() + ").";
    }

    public int recalculateAll() { return droughtService.reassessAll(); }
}
