package com.mahajal.service;

import com.mahajal.dto.Dtos.*;
import com.mahajal.entity.*;

public final class Mappers {
    private Mappers() {}

    public static UserDto user(User u) {
        return new UserDto(u.getId(), u.getFullName(), u.getEmail(), u.getRole().getName().name(), u.getPhone(), u.getOrganization());
    }

    public static VillageMapDto mapPoint(DroughtAssessment a) {
        Village v = a.getVillage();
        return new VillageMapDto(v.getId(), v.getName(), v.getTaluka().getName(), v.getTaluka().getDistrict().getName(),
                v.getLatitude(), v.getLongitude(), a.getRiskScore(), a.getRiskLevel().name());
    }

    public static CropDto crop(Crop c) {
        return new CropDto(c.getId(), c.getCropName(), c.getSeason(), c.getStage(), c.getAreaAcres(),
                c.getSowingDate(), c.getSoilType(), c.getIrrigationType());
    }

    public static FarmerProfileDto farmer(Farmer f) {
        Village v = f.getVillage();
        Taluka t = v.getTaluka();
        District d = t.getDistrict();
        return new FarmerProfileDto(f.getId(), f.getFullName(), f.getUser() != null ? f.getUser().getEmail() : null,
                f.getPhone(), f.getLandAcres(), v.getId(), v.getName(), t.getId(), t.getName(), d.getId(), d.getName());
    }

    public static DamageDto damage(CropDamageReport r) {
        Village v = r.getVillage();
        return new DamageDto(r.getId(), r.getFarmer().getFullName(), v.getName(), v.getTaluka().getDistrict().getName(),
                r.getCrop() != null ? r.getCrop().getCropName() : null, r.getCause(), r.getDamagePercent(),
                r.getAreaAffectedAcres(), r.getDescription(), r.getStatus().name(), r.getRemarks(), r.getCreatedAt());
    }

    public static TankerDto tanker(TankerRequest t) {
        Village v = t.getVillage();
        return new TankerDto(t.getId(), t.getFarmer().getFullName(), v.getName(), v.getTaluka().getDistrict().getName(),
                t.getPeopleCount(), t.getLivestockCount(), t.getLitersRequired(), t.getUrgency(), t.getRemarks(),
                t.getStatus().name(), t.getCreatedAt());
    }

    public static SosDto sos(SosReport s) {
        Village v = s.getVillage();
        return new SosDto(s.getId(), s.getFarmer().getFullName(), s.getFarmer().getPhone(), v.getName(),
                v.getTaluka().getDistrict().getName(), s.getCategory(), s.getMessage(), s.getLatitude(),
                s.getLongitude(), s.getStatus().name(), s.getCreatedAt());
    }

    public static NotificationDto notification(Notification n) {
        return new NotificationDto(n.getId(), n.getTitle(), n.getMessage(), n.getType(), n.isSeen(), n.getCreatedAt());
    }

    public static WaterSourceDto water(WaterSource w) {
        Village v = w.getVillage();
        return new WaterSourceDto(w.getId(), v.getName(), v.getTaluka().getDistrict().getName(), w.getName(),
                w.getType().name(), w.getStoragePct(), w.isFunctional());
    }

    public static NeedDto need(VillageNeed n) {
        return new NeedDto(n.getId(), n.getVillage().getId(), n.getVillage().getName(), n.getNeedType().name(),
                n.getDescription(), n.getEstimatedCostInr(), n.getPriority().name());
    }

    public static SupportDto ngo(NgoSupport s) {
        Village v = s.getVillage();
        return new SupportDto(s.getId(), s.getNgoUser().getOrganization() != null ? s.getNgoUser().getOrganization() : s.getNgoUser().getFullName(),
                v.getId(), v.getName(), v.getTaluka().getDistrict().getName(), s.getSupportType(), s.getAmountInr(),
                s.getDescription(), s.getStatus().name(), s.getCreatedAt(), s.isDemoData());
    }

    public static SupportDto csr(CsrSupport s) {
        Village v = s.getVillage();
        return new SupportDto(s.getId(), s.getCsrUser().getOrganization() != null ? s.getCsrUser().getOrganization() : s.getCsrUser().getFullName(),
                v.getId(), v.getName(), v.getTaluka().getDistrict().getName(), s.getProgramName(), s.getAmountInr(),
                s.getDescription(), s.getStatus().name(), s.getCreatedAt(), s.isDemoData());
    }

    public static double round1(double v) { return Math.round(v * 10.0) / 10.0; }
}
