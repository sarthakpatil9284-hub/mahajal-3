# API Reference

Base URL: `/api`. Responses: `{ "success": true, "message": "...", "data": ..., "timestamp": "..." }`.
Authenticated routes need `Authorization: Bearer <JWT>`.

## Auth
POST `/auth/register` · POST `/auth/login` · POST `/auth/forgot-password` · POST `/auth/reset-password` · GET `/auth/me`
(GOVERNMENT self-registration returns 403.)

## Public
GET `/locations/districts` · `/locations/districts/{id}/talukas` · `/locations/talukas/{id}/villages`
GET `/map/villages?districtId=` · `/map/districts` · `/villages/{id}/dashboard`
GET `/rainfall?districtId=` · `/water?districtId=` · `/advisory/options` · POST `/advisory`

## Farmer (role FARMER) `/farmer`
GET `/dashboard` · GET/PUT `/profile` · GET/POST `/crops` · GET/DELETE `/crops/{id}` · GET `/crops/{id}/advisory?weather=`
GET/POST `/damage-reports` · `/tanker-requests` · `/sos`

## Notifications (any authenticated) `/notifications`
GET `/` · GET `/unread-count` · POST `/{id}/read` · POST `/read-all`

## Government (role GOVERNMENT) `/gov`
GET `/dashboard` `/districts` `/villages?districtId=` `/farmers` `/damage-reports` `/sos` `/tanker-requests` `/analytics`
PATCH `/damage-reports/{id}/status` · `/sos/{id}/status` · `/tanker-requests/{id}/status`
POST `/observations` · `/recalculate` · `/users`

## NGO / CSR
GET `/partner/villages?districtId=` · GET `/partner/villages/{id}/needs` (NGO or CSR)
GET/POST `/ngo/support` (NGO) · GET/POST `/csr/support` (CSR)
