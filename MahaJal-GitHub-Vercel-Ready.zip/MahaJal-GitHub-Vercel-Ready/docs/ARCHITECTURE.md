# MahaJal Architecture

```
React (Vite) ──HTTP/JSON + JWT──▶ Spring Boot REST API ──JPA/Hibernate──▶ MySQL 8
```

## Backend (`backend/src/main/java/com/mahajal`)
- `controller` – REST endpoints (Auth, Public, Farmer, Notification, Gov, Partner)
- `service` – business logic: `DroughtScoring` (weighted score + "why at risk" factors), `AdvisoryService` (rule-based advisory), `GovService`, `FarmerService`, `PartnerService`, `VillageService`
- `repository` – Spring Data JPA
- `entity` – JPA entities (users, roles, districts, talukas, villages, farmers, crops, rainfall_records, groundwater_records, water_sources, drought_assessments, crop_damage_reports, tanker_requests, sos_reports, ngo_support, csr_support, village_needs, support_gap, notifications)
- `dto` – request/response records; entities are not exposed
- `security` / `config` – JWT filter, BCrypt, role-based rules, CORS, `DemoDataSeeder`
- `exception` – `GlobalExceptionHandler`; all responses use `{success, message, data, timestamp}`

## Drought score
Weights: rainfall deficit 35%, groundwater 25%, water availability 20%, crop stress 20%.
Levels: <30 Low, <55 Moderate, <75 High, otherwise Critical.
Label: "MahaJal Analytical Drought Risk Score – Demo/Decision Support". Not an official declaration.

## Support gap
`Total Need − Government − NGO − CSR = Remaining Gap` (demo data).

## Frontend (`frontend/src`)
`components`, `pages` (public/farmer/gov/partner/shared), `layouts` (Public, Farmer, Government, NGO, CSR), `services` (Axios), `context` (Auth), `routes` (ProtectedRoute), `hooks`, `utils`, `styles`.

## Future-ready extension points
- Drought/crop-loss/water-demand prediction: a Python FastAPI service can write into `drought_assessments` or be called from `DroughtService`.
- NDVI/satellite and GIS: add layers to `RiskMap`; add tables alongside `rainfall_records`.
- GPS tanker tracking: extend `tanker_requests` with location/status events.
- Marathi: move UI strings to i18n files.
- PDF/Excel reports: replace CSV export in `Reports.jsx` with server endpoints.
- Government API integrations: replace `DemoDataSeeder` data with scheduled ingestion jobs.
